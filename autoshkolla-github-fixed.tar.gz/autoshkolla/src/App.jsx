import React, { useState } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { AppProvider } from './context/AppContext'
import { ToastProvider } from './components/ui/Toast'
import Layout from './components/layout/Layout'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Students from './pages/Students'
import Instructors from './pages/Instructors'
import Vehicles from './pages/Vehicles'
import Schedule from './pages/Schedule'
import Exams from './pages/Exams'
import Tests from './pages/Tests'
import Payments from './pages/Payments'
import Notifications from './pages/Notifications'
import Documents from './pages/Documents'
import Reports from './pages/Reports'
import Branches from './pages/Branches'
import CMS from './pages/CMS'
import Settings from './pages/Settings'

const META={
  '/'           :['Dashboard','Pasqyrë e plotë e sistemit'],
  '/students'   :['Kandidatët','Menaxhim i plotë i kandidatëve'],
  '/students/new':['Kandidat i ri','Regjistro kandidat'],
  '/instructors':['Instruktorët','Menaxhim i instruktorëve'],
  '/instructors/new':['Instruktor i ri','Shto instruktor'],
  '/vehicles'   :['Veturat — Fleet','Menaxhim i flotës'],
  '/vehicles/new':['Veturë e re','Shto veturë'],
  '/schedule'   :['Oraret','Planifikimi i orëve të vozitjes'],
  '/exams'      :['Provime','Menaxhim i provimeve'],
  '/exams/new'  :['Provim i ri','Cakto provim'],
  '/tests'      :['Testet Online','Simulim i provimit teorik'],
  '/payments'   :['Pagesat','Transaksione dhe financat'],
  '/payments/debts':['Borxhet','Borxhet aktive'],
  '/notifications':['Njoftime','Njoftime dhe paralajmërime'],
  '/documents'  :['Dokumentet','Arkivi i dokumenteve'],
  '/reports'    :['Raporte & Analitika','Statistika dhe performancë'],
  '/branches'   :['Degët','Menaxhim i rrjetit të degëve'],
  '/cms'        :['Webfaqja','CMS dhe menaxhim i faqeve'],
  '/settings'   :['Cilësimet','Konfigurim i sistemit'],
}

function P({path,children}){const[t,s]=META[path]||['AutoShkolla Pro',''];return<Layout title={t} subtitle={s}>{children}</Layout>}

export default function App(){
  const[loggedIn,setLoggedIn]=useState(()=>{try{return localStorage.getItem('asp_auth')==='1'}catch{return false}})
  const login=()=>{try{localStorage.setItem('asp_auth','1')}catch{};setLoggedIn(true)}
  if(!loggedIn)return<ToastProvider><Login onLogin={login}/></ToastProvider>
  return(
    <ToastProvider><AppProvider>
      <Routes>
        <Route path="/" element={<P path="/"><Dashboard/></P>}/>
        <Route path="/students" element={<P path="/students"><Students/></P>}/>
        <Route path="/students/new" element={<P path="/students/new"><Students/></P>}/>
        <Route path="/instructors" element={<P path="/instructors"><Instructors/></P>}/>
        <Route path="/instructors/new" element={<P path="/instructors/new"><Instructors/></P>}/>
        <Route path="/vehicles" element={<P path="/vehicles"><Vehicles/></P>}/>
        <Route path="/vehicles/new" element={<P path="/vehicles/new"><Vehicles/></P>}/>
        <Route path="/schedule" element={<P path="/schedule"><Schedule/></P>}/>
        <Route path="/exams" element={<P path="/exams"><Exams/></P>}/>
        <Route path="/exams/new" element={<P path="/exams/new"><Exams/></P>}/>
        <Route path="/tests" element={<P path="/tests"><Tests/></P>}/>
        <Route path="/payments" element={<P path="/payments"><Payments/></P>}/>
        <Route path="/payments/debts" element={<P path="/payments/debts"><Payments/></P>}/>
        <Route path="/notifications" element={<P path="/notifications"><Notifications/></P>}/>
        <Route path="/documents" element={<P path="/documents"><Documents/></P>}/>
        <Route path="/reports" element={<P path="/reports"><Reports/></P>}/>
        <Route path="/branches" element={<P path="/branches"><Branches/></P>}/>
        <Route path="/cms" element={<P path="/cms"><CMS/></P>}/>
        <Route path="/settings" element={<P path="/settings"><Settings/></P>}/>
        <Route path="*" element={<Navigate to="/" replace/>}/>
      </Routes>
    </AppProvider></ToastProvider>
  )
}
