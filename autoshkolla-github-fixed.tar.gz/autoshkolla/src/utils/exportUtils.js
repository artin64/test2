import * as XLSX from 'xlsx'

// ─── EXCEL EXPORT ────────────────────────────────────────────────────────────
export function exportToExcel(data, filename, sheetName = 'Të dhënat') {
  const ws = XLSX.utils.json_to_sheet(data)
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, sheetName)
  XLSX.writeFile(wb, `${filename}_${new Date().toISOString().split('T')[0]}.xlsx`)
}

export function exportStudentsExcel(students) {
  const rows = students.map(s => ({
    'Emri i plotë': s.name,
    'Nr. Personal': s.personal,
    'Data e lindjes': s.dob,
    'Gjinia': s.gender === 'M' ? 'Mashkull' : 'Femër',
    'Telefoni': s.phone,
    'Email': s.email,
    'Adresa': s.address,
    'Kategoria': s.category,
    'Statusi': s.status === 'active' ? 'Aktiv' : s.status === 'completed' ? 'Diplomuar' : s.status === 'pending' ? 'Në pritje' : 'Pezulluar',
    'Orë përfunduara': s.hoursCompleted,
    'Orë totale': s.hoursTotal,
    'Instruktori': s.instructor,
    'Paguar (€)': s.payments,
    'Borxhi (€)': s.debt,
    'Data regjistrimit': s.enrolled,
  }))
  exportToExcel(rows, 'kandidatat', 'Kandidatët')
}

export function exportPaymentsExcel(payments) {
  const rows = payments.map(p => ({
    'Fatura': p.invoice,
    'Kandidati': p.student,
    'Shuma (€)': p.amount,
    'Metoda': p.method === 'cash' ? 'Cash' : p.method === 'transfer' ? 'Transfer' : p.method === 'card' ? 'Kartë' : 'Online',
    'Lloji': p.type,
    'Data': p.date,
    'Statusi': 'Paguar',
    'Shënim': p.note || '',
  }))
  exportToExcel(rows, 'pagesat', 'Pagesat')
}

export function exportInstructorsExcel(instructors) {
  const rows = instructors.map(i => ({
    'Emri': i.name,
    'Telefoni': i.phone,
    'Email': i.email,
    'Licensa': i.license,
    'Skadon': i.licenseExpiry,
    'Eksperienca (vite)': i.experience,
    'Statusi': i.status === 'active' ? 'Aktiv' : i.status === 'leave' ? 'Pushim' : 'Joaktiv',
    'Kandidatë': i.students,
    'Orë ky muaj': i.hoursThisMonth,
    'Vlerësimi': i.rating,
    'Paga (€)': i.salary,
    'Kategorite': i.categories?.join(', '),
  }))
  exportToExcel(rows, 'instruktoret', 'Instruktorët')
}

export function exportVehiclesExcel(vehicles) {
  const rows = vehicles.map(v => ({
    'Marka': v.brand,
    'Modeli': v.model,
    'Viti': v.year,
    'Targa': v.plate,
    'VIN': v.vin,
    'Kategoria': v.category,
    'Transmisioni': v.transmission,
    'Statusi': v.status === 'active' ? 'Aktiv' : v.status === 'maintenance' ? 'Mirëmbajtje' : 'Joaktiv',
    'Instruktori': v.instructor,
    'Sigurimi skadon': v.insurance,
    'Regjistrimi skadon': v.registration,
    'Servisi i fundit': v.lastService,
    'Kilometrazha': v.km,
  }))
  exportToExcel(rows, 'veturat', 'Veturat')
}

export function exportScheduleExcel(schedules) {
  const rows = schedules.map(s => ({
    'Kandidati': s.student,
    'Instruktori': s.instructor || '—',
    'Vetura': s.vehicle || '—',
    'Data': s.date,
    'Ora': s.time,
    'Kohëzgjatja (min)': s.duration,
    'Lokacioni': s.location,
    'Lloji': s.type === 'practical' ? 'Praktike' : s.type === 'exam-theory' ? 'Provim teorik' : 'Provim praktik',
    'Statusi': s.status === 'confirmed' ? 'Konfirmuar' : s.status === 'pending' ? 'Në pritje' : 'Anuluar',
  }))
  exportToExcel(rows, 'oraret', 'Oraret')
}

export function exportReportExcel(students, payments, instructors) {
  const wb = XLSX.utils.book_new()

  // Summary sheet
  const summary = [
    { 'Kategoria': 'Kandidatë total', 'Vlera': students.length },
    { 'Kategoria': 'Kandidatë aktiv', 'Vlera': students.filter(s => s.status === 'active').length },
    { 'Kategoria': 'Kandidatë diplomuar', 'Vlera': students.filter(s => s.status === 'completed').length },
    { 'Kategoria': 'Instruktorë', 'Vlera': instructors.length },
    { 'Kategoria': 'Të ardhura totale (€)', 'Vlera': payments.reduce((a, p) => a + +p.amount, 0) },
    { 'Kategoria': 'Borxhe totale (€)', 'Vlera': students.reduce((a, s) => a + (s.debt || 0), 0) },
  ]
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(summary), 'Përmbledhje')

  const stuRows = students.map(s => ({ 'Emri': s.name, 'Kategoria': s.category, 'Statusi': s.status, 'Orë': `${s.hoursCompleted}/${s.hoursTotal}`, 'Paguar €': s.payments, 'Borxh €': s.debt }))
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(stuRows), 'Kandidatët')

  const payRows = payments.map(p => ({ 'Fatura': p.invoice, 'Kandidati': p.student, 'Shuma €': p.amount, 'Metoda': p.method, 'Data': p.date }))
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(payRows), 'Pagesat')

  XLSX.writeFile(wb, `raporti_${new Date().toISOString().split('T')[0]}.xlsx`)
}

// ─── INVOICE PRINT ────────────────────────────────────────────────────────────
export function printInvoice(payment, settings = {}) {
  const schoolName = settings.schoolName || 'AutoShkolla Pro'
  const schoolAddress = settings.address || 'Prishtinë'
  const schoolPhone = settings.phone || ''
  const schoolEmail = settings.email || ''

  const html = `<!DOCTYPE html>
<html lang="sq">
<head>
<meta charset="UTF-8"/>
<title>Fatura ${payment.invoice}</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: 'Segoe UI', Arial, sans-serif; color: #1a1a2e; background: #fff; padding: 40px; max-width: 700px; margin: 0 auto; }
  .header { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:40px; padding-bottom:24px; border-bottom:2px solid #2563EB; }
  .logo { font-size:22px; font-weight:800; color:#2563EB; letter-spacing:-0.5px; }
  .logo span { color:#06B6D4; }
  .school-info { text-align:right; font-size:12px; color:#64748b; line-height:1.6; }
  .invoice-title { font-size:32px; font-weight:800; color:#0f172a; margin-bottom:4px; }
  .invoice-num { font-size:14px; color:#64748b; }
  .invoice-meta { display:grid; grid-template-columns:1fr 1fr; gap:24px; margin-bottom:32px; }
  .meta-box { background:#f8fafc; border-radius:12px; padding:16px; }
  .meta-label { font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:0.1em; color:#94a3b8; margin-bottom:8px; }
  .meta-value { font-size:14px; font-weight:600; color:#1e293b; }
  .meta-value.large { font-size:18px; }
  .table { width:100%; border-collapse:collapse; margin-bottom:32px; }
  .table th { background:#1e293b; color:#fff; padding:12px 16px; text-align:left; font-size:12px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em; }
  .table th:last-child { text-align:right; }
  .table td { padding:14px 16px; border-bottom:1px solid #e2e8f0; font-size:14px; }
  .table td:last-child { text-align:right; font-weight:600; }
  .table tr:last-child td { border-bottom:none; }
  .totals { display:flex; justify-content:flex-end; margin-bottom:32px; }
  .totals-box { width:260px; }
  .totals-row { display:flex; justify-content:space-between; padding:8px 0; font-size:14px; border-bottom:1px solid #e2e8f0; }
  .totals-row.total { font-size:18px; font-weight:800; color:#2563EB; border-bottom:none; padding-top:12px; }
  .status-box { display:inline-flex; align-items:center; gap:8px; background:#dcfce7; border:1px solid #86efac; border-radius:24px; padding:8px 16px; margin-bottom:32px; }
  .status-dot { width:8px; height:8px; background:#22c55e; border-radius:50%; }
  .status-text { font-size:13px; font-weight:600; color:#15803d; }
  .footer { border-top:1px solid #e2e8f0; padding-top:20px; display:flex; justify-content:space-between; font-size:11px; color:#94a3b8; }
  .method-badge { display:inline-block; background:#eff6ff; color:#2563EB; border-radius:6px; padding:2px 8px; font-size:12px; font-weight:600; }
  @media print { body { padding:20px; } @page { margin:1cm; } }
</style>
</head>
<body>
  <div class="header">
    <div>
      <div class="logo">${schoolName.split(' ').slice(0, -1).join(' ')} <span>${schoolName.split(' ').slice(-1)}</span></div>
      <div style="font-size:11px;color:#94a3b8;margin-top:4px;">Sistem Profesional për Autoshkollë</div>
    </div>
    <div class="school-info">
      <div>${schoolAddress}</div>
      ${schoolPhone ? `<div>${schoolPhone}</div>` : ''}
      ${schoolEmail ? `<div>${schoolEmail}</div>` : ''}
    </div>
  </div>

  <div class="invoice-title">FATURË</div>
  <div class="invoice-num"># ${payment.invoice}</div>

  <br/>

  <div class="invoice-meta">
    <div class="meta-box">
      <div class="meta-label">Lëshuar për</div>
      <div class="meta-value large">${payment.student}</div>
    </div>
    <div class="meta-box">
      <div class="meta-label">Data e faturës</div>
      <div class="meta-value large">${payment.date}</div>
    </div>
    <div class="meta-box">
      <div class="meta-label">Metoda e pagesës</div>
      <div class="meta-value"><span class="method-badge">${payment.method === 'cash' ? 'Cash' : payment.method === 'transfer' ? 'Transfer bankar' : payment.method === 'card' ? 'Kartë' : 'Online'}</span></div>
    </div>
    <div class="meta-box">
      <div class="meta-label">Lloji i shërbimit</div>
      <div class="meta-value">${payment.type === 'registration' ? 'Regjistrim' : payment.type === 'lessons' ? 'Orë vozitjeje' : payment.type === 'package' ? 'Paketë e plotë' : 'Provim'}</div>
    </div>
  </div>

  <table class="table">
    <thead>
      <tr>
        <th>Përshkrimi</th>
        <th>Njësia</th>
        <th>Sasia</th>
        <th>Shuma</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>${payment.type === 'registration' ? 'Tarifë regjistrimi — Kursi i vozitjes' : payment.type === 'lessons' ? 'Orë praktike vozitjeje' : payment.type === 'package' ? 'Paketë e plotë e kursit' : 'Tarifë provimi'} ${payment.note ? `<br/><small style="color:#94a3b8">${payment.note}</small>` : ''}</td>
        <td>Shërbim</td>
        <td>1</td>
        <td>€${payment.amount.toFixed ? payment.amount.toFixed(2) : payment.amount}.00</td>
      </tr>
    </tbody>
  </table>

  <div class="totals">
    <div class="totals-box">
      <div class="totals-row"><span>Nëntotali</span><span>€${payment.amount}.00</span></div>
      <div class="totals-row"><span>TVSH (0%)</span><span>€0.00</span></div>
      <div class="totals-row total"><span>TOTALI</span><span>€${payment.amount}.00</span></div>
    </div>
  </div>

  <div class="status-box">
    <div class="status-dot"></div>
    <div class="status-text">PAGUAR</div>
  </div>

  <div class="footer">
    <div>Gjeneruar: ${new Date().toLocaleDateString('sq-AL', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</div>
    <div>${schoolName} · ${schoolAddress}</div>
  </div>

  <script>window.onload = () => { window.print(); window.onafterprint = () => window.close(); }</script>
</body></html>`

  const w = window.open('', '_blank', 'width=800,height=700')
  w.document.write(html)
  w.document.close()
}

// ─── STUDENT CARD PRINT ───────────────────────────────────────────────────────
export function printStudentCard(student) {
  const progress = Math.round((student.hoursCompleted / student.hoursTotal) * 100)
  const statusMap = { active: ['Aktiv', '#10B981'], completed: ['Diplomuar', '#2563EB'], pending: ['Në pritje', '#F59E0B'], suspended: ['Pezulluar', '#EF4444'] }
  const [statusLabel, statusColor] = statusMap[student.status] || ['—', '#94a3b8']

  const html = `<!DOCTYPE html>
<html lang="sq"><head><meta charset="UTF-8"/><title>Karta — ${student.name}</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Segoe UI',Arial,sans-serif; background:#f8fafc; display:flex; justify-content:center; padding:40px; }
.card { background:#fff; border-radius:16px; padding:32px; width:500px; box-shadow:0 4px 24px rgba(0,0,0,0.08); }
.header { display:flex; align-items:center; gap:16px; margin-bottom:24px; padding-bottom:20px; border-bottom:2px solid #e2e8f0; }
.avatar { width:56px; height:56px; border-radius:12px; background:linear-gradient(135deg,#2563EB,#06B6D4); display:flex; align-items:center; justify-content:center; color:#fff; font-size:20px; font-weight:700; }
.name { font-size:20px; font-weight:700; color:#0f172a; }
.category { display:inline-block; background:#eff6ff; color:#2563EB; border-radius:6px; padding:2px 10px; font-size:12px; font-weight:600; margin-top:4px; }
.badge { display:inline-block; border-radius:20px; padding:2px 12px; font-size:11px; font-weight:700; color:#fff; background:${statusColor}; margin-left:8px; }
.grid { display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:20px; }
.field { background:#f8fafc; border-radius:8px; padding:12px; }
.field-label { font-size:10px; text-transform:uppercase; letter-spacing:0.08em; color:#94a3b8; font-weight:600; margin-bottom:4px; }
.field-value { font-size:13px; font-weight:600; color:#1e293b; }
.progress-bar { height:8px; background:#e2e8f0; border-radius:4px; overflow:hidden; margin-bottom:4px; }
.progress-fill { height:100%; border-radius:4px; background:linear-gradient(90deg,#2563EB,#06B6D4); width:${progress}%; }
.progress-text { font-size:12px; color:#64748b; }
.footer { font-size:10px; color:#94a3b8; text-align:center; margin-top:20px; padding-top:16px; border-top:1px solid #e2e8f0; }
@media print { body { background:#fff; padding:0; } .card { box-shadow:none; } }
</style></head><body>
<div class="card">
  <div class="header">
    <div class="avatar">${student.avatar}</div>
    <div>
      <div class="name">${student.name} <span class="badge">${statusLabel}</span></div>
      <span class="category">Kategoria ${student.category}</span>
    </div>
  </div>
  <div class="grid">
    <div class="field"><div class="field-label">Nr. Personal</div><div class="field-value">${student.personal || '—'}</div></div>
    <div class="field"><div class="field-label">Data e lindjes</div><div class="field-value">${student.dob || '—'}</div></div>
    <div class="field"><div class="field-label">Telefoni</div><div class="field-value">${student.phone}</div></div>
    <div class="field"><div class="field-label">Email</div><div class="field-value">${student.email || '—'}</div></div>
    <div class="field"><div class="field-label">Instruktori</div><div class="field-value">${student.instructor || '—'}</div></div>
    <div class="field"><div class="field-label">Data regjistrimit</div><div class="field-value">${student.enrolled}</div></div>
    <div class="field"><div class="field-label">Paguar</div><div class="field-value" style="color:#10B981">€${student.payments}</div></div>
    <div class="field"><div class="field-label">Borxhi</div><div class="field-value" style="color:${student.debt > 0 ? '#EF4444' : '#10B981'}">€${student.debt}</div></div>
  </div>
  <div class="field-label" style="margin-bottom:6px">Progresi i orëve</div>
  <div class="progress-bar"><div class="progress-fill"></div></div>
  <div class="progress-text">${student.hoursCompleted} / ${student.hoursTotal} orë (${progress}%)</div>
  ${student.notes ? `<div style="margin-top:16px;padding:12px;background:#fef9c3;border-radius:8px;font-size:13px;color:#854d0e">Shënim: ${student.notes}</div>` : ''}
  <div class="footer">AutoShkolla Pro · Gjeneruar: ${new Date().toLocaleDateString('sq-AL')}</div>
</div>
<script>window.onload = () => { window.print(); window.onafterprint = () => window.close(); }</script>
</body></html>`

  const w = window.open('', '_blank', 'width=640,height=700')
  w.document.write(html)
  w.document.close()
}

// ─── REPORT PRINT ─────────────────────────────────────────────────────────────
export function printReport(students, payments, instructors, settings = {}) {
  const total = payments.reduce((a, p) => a + +p.amount, 0)
  const debts = students.reduce((a, s) => a + (s.debt || 0), 0)
  const passRate = 84

  const html = `<!DOCTYPE html>
<html lang="sq"><head><meta charset="UTF-8"/><title>Raport — ${new Date().toLocaleDateString('sq-AL')}</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:'Segoe UI',Arial,sans-serif; color:#1a1a2e; padding:40px; max-width:800px; margin:0 auto; }
h1 { font-size:28px; font-weight:800; color:#0f172a; margin-bottom:4px; }
.subtitle { color:#64748b; font-size:14px; margin-bottom:32px; }
.grid { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:32px; }
.stat { background:#f8fafc; border-radius:12px; padding:16px; }
.stat-val { font-size:24px; font-weight:800; color:#1e293b; }
.stat-label { font-size:11px; color:#94a3b8; text-transform:uppercase; letter-spacing:0.08em; margin-top:4px; }
table { width:100%; border-collapse:collapse; margin-bottom:24px; font-size:13px; }
th { background:#1e293b; color:#fff; padding:10px 12px; text-align:left; font-size:11px; text-transform:uppercase; letter-spacing:0.05em; }
td { padding:10px 12px; border-bottom:1px solid #e2e8f0; }
h2 { font-size:16px; font-weight:700; color:#0f172a; margin:24px 0 12px; }
.footer { font-size:11px; color:#94a3b8; text-align:center; margin-top:32px; border-top:1px solid #e2e8f0; padding-top:16px; }
@media print { body { padding:20px; } @page { margin:1cm; } }
</style></head><body>
<h1>Raport i Autoshkollës</h1>
<div class="subtitle">${settings.schoolName || 'AutoShkolla Pro'} · ${new Date().toLocaleDateString('sq-AL', { day:'2-digit', month:'long', year:'numeric' })}</div>
<div class="grid">
  <div class="stat"><div class="stat-val">${students.length}</div><div class="stat-label">Kandidatë total</div></div>
  <div class="stat"><div class="stat-val" style="color:#10B981">€${total.toLocaleString()}</div><div class="stat-label">Të ardhura</div></div>
  <div class="stat"><div class="stat-val" style="color:#EF4444">€${debts}</div><div class="stat-label">Borxhe</div></div>
  <div class="stat"><div class="stat-val">${passRate}%</div><div class="stat-label">Norma kalimi</div></div>
</div>
<h2>Kandidatët</h2>
<table>
  <thead><tr><th>Emri</th><th>Kategoria</th><th>Orë</th><th>Paguar</th><th>Borxh</th><th>Statusi</th></tr></thead>
  <tbody>
    ${students.map(s => `<tr>
      <td>${s.name}</td><td>Kat. ${s.category}</td>
      <td>${s.hoursCompleted}/${s.hoursTotal}</td>
      <td style="color:#10B981">€${s.payments}</td>
      <td style="color:${s.debt > 0 ? '#EF4444' : '#10B981'}">€${s.debt}</td>
      <td>${s.status === 'active' ? 'Aktiv' : s.status === 'completed' ? 'Diplomuar' : s.status === 'pending' ? 'Në pritje' : 'Pezulluar'}</td>
    </tr>`).join('')}
  </tbody>
</table>
<h2>Pagesat e fundit</h2>
<table>
  <thead><tr><th>Fatura</th><th>Kandidati</th><th>Shuma</th><th>Metoda</th><th>Data</th></tr></thead>
  <tbody>
    ${payments.slice(0, 10).map(p => `<tr>
      <td>${p.invoice}</td><td>${p.student}</td>
      <td style="color:#10B981">€${p.amount}</td>
      <td>${p.method}</td><td>${p.date}</td>
    </tr>`).join('')}
  </tbody>
</table>
<div class="footer">${settings.schoolName || 'AutoShkolla Pro'} · Gjeneruar automatikisht · ${new Date().toLocaleString('sq-AL')}</div>
<script>window.onload = () => { window.print(); window.onafterprint = () => window.close(); }</script>
</body></html>`

  const w = window.open('', '_blank', 'width=900,height=700')
  w.document.write(html)
  w.document.close()
}

// ─── BACKUP EXPORT ────────────────────────────────────────────────────────────
export function exportBackup(data) {
  const json = JSON.stringify(data, null, 2)
  const blob = new Blob([json], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `backup_autoshkolla_${new Date().toISOString().split('T')[0]}.json`
  a.click()
  URL.revokeObjectURL(url)
}
