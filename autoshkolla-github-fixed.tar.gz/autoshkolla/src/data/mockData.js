// ─── MOCK DATA ───────────────────────────────────────────────────────────────

export const students = [
  { id: 1, name: 'Arben Krasniqi', personal: '1234567890', dob: '2000-03-15', gender: 'M', phone: '+383 44 123 456', email: 'arben.k@email.com', address: 'Prishtinë, Rruga Nëna Terezë 12', category: 'B', status: 'active', hoursCompleted: 18, hoursTotal: 30, payments: 280, debt: 70, instructor: 'Besnik Gashi', enrolled: '2024-01-10', avatar: 'AK' },
  { id: 2, name: 'Vjollca Berisha', personal: '9876543210', dob: '2001-07-22', gender: 'F', phone: '+383 45 654 321', email: 'vjollca.b@email.com', address: 'Mitrovicë, Rruga Skënderbeu 5', category: 'B', status: 'active', hoursCompleted: 25, hoursTotal: 30, payments: 320, debt: 30, instructor: 'Driton Morina', enrolled: '2024-01-15', avatar: 'VB' },
  { id: 3, name: 'Genc Halili', personal: '5432109876', dob: '1999-11-05', gender: 'M', phone: '+383 49 789 012', email: 'genc.h@email.com', address: 'Ferizaj, Rruga Lidhja e Prizrenit 3', category: 'C', status: 'pending', hoursCompleted: 8, hoursTotal: 40, payments: 150, debt: 250, instructor: 'Besnik Gashi', enrolled: '2024-02-01', avatar: 'GH' },
  { id: 4, name: 'Leonora Ahmeti', personal: '1111222333', dob: '2002-05-18', gender: 'F', phone: '+383 44 321 987', email: 'leonora.a@email.com', address: 'Pejë, Rruga Jakova 8', category: 'A', status: 'active', hoursCompleted: 12, hoursTotal: 20, payments: 180, debt: 20, instructor: 'Flaka Rexhepi', enrolled: '2024-02-10', avatar: 'LA' },
  { id: 5, name: 'Mentor Zejnullahu', personal: '4444555666', dob: '1998-09-30', gender: 'M', phone: '+383 45 456 123', email: 'mentor.z@email.com', address: 'Gjilan, Rruga Çerçiz Topulli 15', category: 'B', status: 'completed', hoursCompleted: 30, hoursTotal: 30, payments: 350, debt: 0, instructor: 'Driton Morina', enrolled: '2023-11-01', avatar: 'MZ' },
  { id: 6, name: 'Diellza Mustafa', personal: '7778889990', dob: '2003-01-12', gender: 'F', phone: '+383 49 111 222', email: 'diellza.m@email.com', address: 'Prizren, Rruga Shadervan 2', category: 'B', status: 'active', hoursCompleted: 5, hoursTotal: 30, payments: 100, debt: 250, instructor: 'Flaka Rexhepi', enrolled: '2024-03-01', avatar: 'DM' },
  { id: 7, name: 'Kushtrim Gërvalla', personal: '3336669990', dob: '2001-08-25', gender: 'M', phone: '+383 44 777 888', email: 'kushtrim.g@email.com', address: 'Vushtrri, Rruga Adem Jashari 7', category: 'B', status: 'suspended', hoursCompleted: 10, hoursTotal: 30, payments: 120, debt: 230, instructor: 'Besnik Gashi', enrolled: '2024-01-20', avatar: 'KG' },
  { id: 8, name: 'Rina Sadiku', personal: '2225558880', dob: '2000-06-14', gender: 'F', phone: '+383 45 999 000', email: 'rina.s@email.com', address: 'Lipjan, Rruga Dëshmorët e Kombit 1', category: 'A1', status: 'active', hoursCompleted: 15, hoursTotal: 20, payments: 210, debt: 40, instructor: 'Flaka Rexhepi', enrolled: '2024-02-20', avatar: 'RS' },
]

export const instructors = [
  { id: 1, name: 'Besnik Gashi', phone: '+383 44 100 200', email: 'besnik.g@autoshkolla.com', license: 'INS-2019-001', licenseExpiry: '2025-06-30', experience: 8, status: 'active', students: 24, hoursThisMonth: 68, rating: 4.9, avatar: 'BG', salary: 650, categories: ['B', 'BE', 'C'] },
  { id: 2, name: 'Driton Morina', phone: '+383 45 300 400', email: 'driton.m@autoshkolla.com', license: 'INS-2020-002', licenseExpiry: '2025-12-15', experience: 6, status: 'active', students: 19, hoursThisMonth: 54, rating: 4.7, avatar: 'DM', salary: 600, categories: ['B', 'BE'] },
  { id: 3, name: 'Flaka Rexhepi', phone: '+383 49 500 600', email: 'flaka.r@autoshkolla.com', license: 'INS-2021-003', licenseExpiry: '2026-03-20', experience: 4, status: 'active', students: 16, hoursThisMonth: 48, rating: 4.8, avatar: 'FR', salary: 580, categories: ['A', 'A1', 'B'] },
  { id: 4, name: 'Agim Hyseni', phone: '+383 44 700 800', email: 'agim.h@autoshkolla.com', license: 'INS-2018-004', licenseExpiry: '2024-09-10', experience: 10, status: 'leave', students: 0, hoursThisMonth: 0, rating: 4.6, avatar: 'AH', salary: 700, categories: ['B', 'C', 'CE', 'D'] },
]

export const vehicles = [
  { id: 1, brand: 'Volkswagen', model: 'Golf 8', year: 2022, plate: 'PRI-123-AA', vin: 'WVWZZZ1KZ..', category: 'B', transmission: 'Manual', status: 'active', instructor: 'Besnik Gashi', insurance: '2024-12-31', registration: '2024-08-15', lastService: '2024-02-01', km: 45200, color: '#2563EB' },
  { id: 2, brand: 'Škoda', model: 'Fabia', year: 2021, plate: 'PRI-456-BB', vin: 'TMBJB7NEXM..', category: 'B', transmission: 'Manual', status: 'active', instructor: 'Driton Morina', insurance: '2024-11-20', registration: '2024-06-30', lastService: '2024-01-15', km: 38900, color: '#10B981' },
  { id: 3, brand: 'Honda', model: 'CB500F', year: 2023, plate: 'PRI-789-CC', vin: 'JH2PC5401..', category: 'A', transmission: 'Manual', status: 'active', instructor: 'Flaka Rexhepi', insurance: '2025-01-15', registration: '2024-10-01', lastService: '2023-12-10', km: 12300, color: '#EF4444' },
  { id: 4, brand: 'Mercedes-Benz', model: 'Actros', year: 2020, plate: 'PRI-101-DD', vin: 'WDB96302..', category: 'CE', transmission: 'Automatic', status: 'maintenance', instructor: 'Agim Hyseni', insurance: '2024-10-05', registration: '2024-05-20', lastService: '2024-03-01', km: 128000, color: '#F59E0B' },
]

export const scheduleData = [
  { id: 1, student: 'Arben Krasniqi', instructor: 'Besnik Gashi', vehicle: 'VW Golf 8', date: '2024-03-15', time: '09:00', duration: 90, location: 'Parku Industrial', status: 'confirmed', type: 'practical' },
  { id: 2, student: 'Vjollca Berisha', instructor: 'Driton Morina', vehicle: 'Škoda Fabia', date: '2024-03-15', time: '10:30', duration: 90, location: 'Rrethrrotullimi Xhelal Gashi', status: 'confirmed', type: 'practical' },
  { id: 3, student: 'Leonora Ahmeti', instructor: 'Flaka Rexhepi', vehicle: 'Honda CB500F', date: '2024-03-15', time: '11:00', duration: 60, location: 'Sheshi Nëna Terezë', status: 'pending', type: 'practical' },
  { id: 4, student: 'Rina Sadiku', instructor: 'Flaka Rexhepi', vehicle: 'Honda CB500F', date: '2024-03-15', time: '14:00', duration: 60, location: 'Zona Industriale', status: 'confirmed', type: 'practical' },
  { id: 5, student: 'Genc Halili', instructor: 'Besnik Gashi', vehicle: 'VW Golf 8', date: '2024-03-16', time: '09:00', duration: 90, location: 'Rruga Pristina-Ferizaj', status: 'confirmed', type: 'practical' },
  { id: 6, student: 'Mentor Zejnullahu', instructor: null, vehicle: null, date: '2024-03-18', time: '10:00', duration: 60, location: 'DPKSH', status: 'confirmed', type: 'exam-theory' },
]

export const payments = [
  { id: 1, student: 'Arben Krasniqi', amount: 150, method: 'cash', date: '2024-03-10', type: 'registration', status: 'paid', invoice: 'INV-2024-001' },
  { id: 2, student: 'Vjollca Berisha', amount: 200, method: 'transfer', date: '2024-03-08', type: 'lessons', status: 'paid', invoice: 'INV-2024-002' },
  { id: 3, student: 'Genc Halili', amount: 150, method: 'cash', date: '2024-03-05', type: 'registration', status: 'paid', invoice: 'INV-2024-003' },
  { id: 4, student: 'Leonora Ahmeti', amount: 180, method: 'card', date: '2024-03-12', type: 'lessons', status: 'paid', invoice: 'INV-2024-004' },
  { id: 5, student: 'Diellza Mustafa', amount: 100, method: 'cash', date: '2024-03-01', type: 'registration', status: 'paid', invoice: 'INV-2024-005' },
  { id: 6, student: 'Kushtrim Gërvalla', amount: 120, method: 'cash', date: '2024-02-20', type: 'lessons', status: 'paid', invoice: 'INV-2024-006' },
  { id: 7, student: 'Rina Sadiku', amount: 210, method: 'transfer', date: '2024-03-14', type: 'package', status: 'paid', invoice: 'INV-2024-007' },
]

export const monthlyRevenue = [
  { month: 'Tet', revenue: 4200, expenses: 1800, students: 12 },
  { month: 'Nën', revenue: 5100, expenses: 2100, students: 15 },
  { month: 'Dhj', revenue: 4800, expenses: 1900, students: 14 },
  { month: 'Jan', revenue: 6200, expenses: 2400, students: 18 },
  { month: 'Shk', revenue: 7100, expenses: 2600, students: 22 },
  { month: 'Mar', revenue: 6800, expenses: 2500, students: 20 },
]

export const examResults = [
  { id: 1, student: 'Mentor Zejnullahu', type: 'theory', date: '2024-02-20', result: 'passed', score: 87, examiner: 'DPKSH', attempts: 1 },
  { id: 2, student: 'Mentor Zejnullahu', type: 'practical', date: '2024-03-05', result: 'passed', score: null, examiner: 'Driton Morina', attempts: 1 },
  { id: 3, student: 'Vjollca Berisha', type: 'theory', date: '2024-03-10', result: 'passed', score: 92, examiner: 'DPKSH', attempts: 1 },
  { id: 4, student: 'Genc Halili', type: 'theory', date: '2024-02-15', result: 'failed', score: 58, examiner: 'DPKSH', attempts: 1 },
  { id: 5, student: 'Rina Sadiku', type: 'theory', date: '2024-03-18', result: 'scheduled', score: null, examiner: 'DPKSH', attempts: 0 },
]

export const notifications = [
  { id: 1, type: 'warning', title: 'Licensa afër skadimit', message: 'Licensa e Agim Hysenit skadon pas 30 ditësh', time: '2 orë', read: false },
  { id: 2, type: 'info', title: 'Orë e re rezervuar', message: 'Arben Krasniqi rezervoi orë për 15 Mars 09:00', time: '3 orë', read: false },
  { id: 3, type: 'success', title: 'Pagesa e pranuar', message: 'Rina Sadiku kreu pagesën prej 210€', time: '5 orë', read: true },
  { id: 4, type: 'error', title: 'Borxh i vonuar', message: 'Diellza Mustafa ka borxh prej 250€ mbi 30 ditë', time: '1 ditë', read: true },
  { id: 5, type: 'info', title: 'Provim i planifikuar', message: 'Mentor Zejnullahu ka provim teorik nesër', time: '1 ditë', read: true },
]

export const dashboardStats = {
  totalStudents: 148,
  activeStudents: 89,
  newToday: 3,
  drivingHoursToday: 24,
  totalRevenue: 34200,
  activeDebts: 1840,
  activeInstructors: 3,
  activeVehicles: 3,
  upcomingExams: 5,
  passRate: 84,
}

export const categoryStats = [
  { name: 'Kategoria B', value: 68, color: '#2563EB' },
  { name: 'Kategoria A', value: 15, color: '#06B6D4' },
  { name: 'Kategoria C', value: 10, color: '#10B981' },
  { name: 'Tjera', value: 7, color: '#F59E0B' },
]

export const weeklyHours = [
  { day: 'Hën', hours: 18 },
  { day: 'Mar', hours: 22 },
  { day: 'Mër', hours: 16 },
  { day: 'Enj', hours: 24 },
  { day: 'Pre', hours: 20 },
  { day: 'Sht', hours: 14 },
  { day: 'Die', hours: 0 },
]

export const testQuestions = [
  { id: 1, category: 'Shenjat', question: 'Çfarë tregon kjo shenjë?', options: ['Ndalim parkimi', 'Ndalim qëndrimi', 'Rrugë njëkahëshe', 'Ndalim kalimi'], correct: 0, image: null },
  { id: 2, category: 'Rregullat', question: 'Sa është shpejtësia maksimale në zonë urbane?', options: ['40 km/h', '50 km/h', '60 km/h', '80 km/h'], correct: 1, image: null },
  { id: 3, category: 'Përparësia', question: 'Kush ka përparësi në kryqëzim të parregulluar?', options: ['Kush vjen nga e majta', 'Kush vjen nga e djathta', 'Kush ka shpejtësi më të madhe', 'Kush vjen i pari'], correct: 1, image: null },
  { id: 4, category: 'Siguria', question: 'Sa metra para kthesës duhet të jepni sinjal?', options: ['10 metra', '20 metra', '30 metra', '50 metra'], correct: 2, image: null },
  { id: 5, category: 'Rregullat', question: 'Kur lejohet kalimi me dritë të verdhë të ndezur?', options: ['Kurrë', 'Vetëm nëse rruga është e lirë', 'Gjithmonë', 'Vetëm gjatë natës'], correct: 1, image: null },
]
