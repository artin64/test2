// ─── CENTRAL DATA STORE WITH LOCALSTORAGE PERSISTENCE ───────────────────────
import { useState, useEffect, useCallback } from 'react'

// Default seed data
const DEFAULT_DATA = {
  students: [
    { id: 1, name: 'Arben Krasniqi', personal: '1234567890', dob: '2000-03-15', gender: 'M', phone: '+383 44 123 456', email: 'arben.k@email.com', address: 'Prishtinë, Rruga Nëna Terezë 12', category: 'B', status: 'active', hoursCompleted: 18, hoursTotal: 30, payments: 280, debt: 70, instructor: 'Besnik Gashi', enrolled: '2024-01-10', avatar: 'AK', notes: '' },
    { id: 2, name: 'Vjollca Berisha', personal: '9876543210', dob: '2001-07-22', gender: 'F', phone: '+383 45 654 321', email: 'vjollca.b@email.com', address: 'Mitrovicë, Rruga Skënderbeu 5', category: 'B', status: 'active', hoursCompleted: 25, hoursTotal: 30, payments: 320, debt: 30, instructor: 'Driton Morina', enrolled: '2024-01-15', avatar: 'VB', notes: '' },
    { id: 3, name: 'Genc Halili', personal: '5432109876', dob: '1999-11-05', gender: 'M', phone: '+383 49 789 012', email: 'genc.h@email.com', address: 'Ferizaj, Rruga Lidhja e Prizrenit 3', category: 'C', status: 'pending', hoursCompleted: 8, hoursTotal: 40, payments: 150, debt: 250, instructor: 'Besnik Gashi', enrolled: '2024-02-01', avatar: 'GH', notes: '' },
    { id: 4, name: 'Leonora Ahmeti', personal: '1111222333', dob: '2002-05-18', gender: 'F', phone: '+383 44 321 987', email: 'leonora.a@email.com', address: 'Pejë, Rruga Jakova 8', category: 'A', status: 'active', hoursCompleted: 12, hoursTotal: 20, payments: 180, debt: 20, instructor: 'Flaka Rexhepi', enrolled: '2024-02-10', avatar: 'LA', notes: '' },
    { id: 5, name: 'Mentor Zejnullahu', personal: '4444555666', dob: '1998-09-30', gender: 'M', phone: '+383 45 456 123', email: 'mentor.z@email.com', address: 'Gjilan, Rruga Çerçiz Topulli 15', category: 'B', status: 'completed', hoursCompleted: 30, hoursTotal: 30, payments: 350, debt: 0, instructor: 'Driton Morina', enrolled: '2023-11-01', avatar: 'MZ', notes: 'Diplomuar me sukses' },
    { id: 6, name: 'Diellza Mustafa', personal: '7778889990', dob: '2003-01-12', gender: 'F', phone: '+383 49 111 222', email: 'diellza.m@email.com', address: 'Prizren, Rruga Shadervan 2', category: 'B', status: 'active', hoursCompleted: 5, hoursTotal: 30, payments: 100, debt: 250, instructor: 'Flaka Rexhepi', enrolled: '2024-03-01', avatar: 'DM', notes: '' },
    { id: 7, name: 'Kushtrim Gërvalla', personal: '3336669990', dob: '2001-08-25', gender: 'M', phone: '+383 44 777 888', email: 'kushtrim.g@email.com', address: 'Vushtrri, Rruga Adem Jashari 7', category: 'B', status: 'suspended', hoursCompleted: 10, hoursTotal: 30, payments: 120, debt: 230, instructor: 'Besnik Gashi', enrolled: '2024-01-20', avatar: 'KG', notes: 'Pezulluar — mosparaqitje' },
    { id: 8, name: 'Rina Sadiku', personal: '2225558880', dob: '2000-06-14', gender: 'F', phone: '+383 45 999 000', email: 'rina.s@email.com', address: 'Lipjan, Rruga Dëshmorët e Kombit 1', category: 'A1', status: 'active', hoursCompleted: 15, hoursTotal: 20, payments: 210, debt: 40, instructor: 'Flaka Rexhepi', enrolled: '2024-02-20', avatar: 'RS', notes: '' },
  ],
  instructors: [
    { id: 1, name: 'Besnik Gashi', phone: '+383 44 100 200', email: 'besnik.g@autoshkolla.com', license: 'INS-2019-001', licenseExpiry: '2025-06-30', experience: 8, status: 'active', students: 24, hoursThisMonth: 68, rating: 4.9, avatar: 'BG', salary: 650, categories: ['B', 'BE', 'C'] },
    { id: 2, name: 'Driton Morina', phone: '+383 45 300 400', email: 'driton.m@autoshkolla.com', license: 'INS-2020-002', licenseExpiry: '2025-12-15', experience: 6, status: 'active', students: 19, hoursThisMonth: 54, rating: 4.7, avatar: 'DM', salary: 600, categories: ['B', 'BE'] },
    { id: 3, name: 'Flaka Rexhepi', phone: '+383 49 500 600', email: 'flaka.r@autoshkolla.com', license: 'INS-2021-003', licenseExpiry: '2026-03-20', experience: 4, status: 'active', students: 16, hoursThisMonth: 48, rating: 4.8, avatar: 'FR', salary: 580, categories: ['A', 'A1', 'B'] },
    { id: 4, name: 'Agim Hyseni', phone: '+383 44 700 800', email: 'agim.h@autoshkolla.com', license: 'INS-2018-004', licenseExpiry: '2024-09-10', experience: 10, status: 'leave', students: 0, hoursThisMonth: 0, rating: 4.6, avatar: 'AH', salary: 700, categories: ['B', 'C', 'CE', 'D'] },
  ],
  vehicles: [
    { id: 1, brand: 'Volkswagen', model: 'Golf 8', year: 2022, plate: 'PRI-123-AA', vin: 'WVWZZZ1KZ3M123456', category: 'B', transmission: 'Manual', status: 'active', instructor: 'Besnik Gashi', insurance: '2024-12-31', registration: '2024-08-15', lastService: '2024-02-01', km: 45200, color: '#2563EB' },
    { id: 2, brand: 'Škoda', model: 'Fabia', year: 2021, plate: 'PRI-456-BB', vin: 'TMBJB7NEXM456789', category: 'B', transmission: 'Manual', status: 'active', instructor: 'Driton Morina', insurance: '2024-11-20', registration: '2024-06-30', lastService: '2024-01-15', km: 38900, color: '#10B981' },
    { id: 3, name: 'Honda CB500F', brand: 'Honda', model: 'CB500F', year: 2023, plate: 'PRI-789-CC', vin: 'JH2PC5401P789012', category: 'A', transmission: 'Manual', status: 'active', instructor: 'Flaka Rexhepi', insurance: '2025-01-15', registration: '2024-10-01', lastService: '2023-12-10', km: 12300, color: '#EF4444' },
    { id: 4, brand: 'Mercedes-Benz', model: 'Actros', year: 2020, plate: 'PRI-101-DD', vin: 'WDB96302X1L234567', category: 'CE', transmission: 'Automatic', status: 'maintenance', instructor: 'Agim Hyseni', insurance: '2024-10-05', registration: '2024-05-20', lastService: '2024-03-01', km: 128000, color: '#F59E0B' },
  ],
  schedules: [
    { id: 1, student: 'Arben Krasniqi', instructor: 'Besnik Gashi', vehicle: 'VW Golf 8', date: '2024-03-15', time: '09:00', duration: 90, location: 'Parku Industrial', status: 'confirmed', type: 'practical' },
    { id: 2, student: 'Vjollca Berisha', instructor: 'Driton Morina', vehicle: 'Škoda Fabia', date: '2024-03-15', time: '10:30', duration: 90, location: 'Rrethrrotullimi Xhelal Gashi', status: 'confirmed', type: 'practical' },
    { id: 3, student: 'Leonora Ahmeti', instructor: 'Flaka Rexhepi', vehicle: 'Honda CB500F', date: '2024-03-15', time: '11:00', duration: 60, location: 'Sheshi Nëna Terezë', status: 'pending', type: 'practical' },
    { id: 4, student: 'Rina Sadiku', instructor: 'Flaka Rexhepi', vehicle: 'Honda CB500F', date: '2024-03-15', time: '14:00', duration: 60, location: 'Zona Industriale', status: 'confirmed', type: 'practical' },
    { id: 5, student: 'Genc Halili', instructor: 'Besnik Gashi', vehicle: 'VW Golf 8', date: '2024-03-16', time: '09:00', duration: 90, location: 'Rruga Pristina-Ferizaj', status: 'confirmed', type: 'practical' },
    { id: 6, student: 'Mentor Zejnullahu', instructor: null, vehicle: null, date: '2024-03-18', time: '10:00', duration: 60, location: 'DPKSH Prishtinë', status: 'confirmed', type: 'exam-theory' },
  ],
  payments: [
    { id: 1, student: 'Arben Krasniqi', amount: 150, method: 'cash', date: '2024-03-10', type: 'registration', status: 'paid', invoice: 'INV-2024-001', note: '' },
    { id: 2, student: 'Vjollca Berisha', amount: 200, method: 'transfer', date: '2024-03-08', type: 'lessons', status: 'paid', invoice: 'INV-2024-002', note: '' },
    { id: 3, student: 'Genc Halili', amount: 150, method: 'cash', date: '2024-03-05', type: 'registration', status: 'paid', invoice: 'INV-2024-003', note: '' },
    { id: 4, student: 'Leonora Ahmeti', amount: 180, method: 'card', date: '2024-03-12', type: 'lessons', status: 'paid', invoice: 'INV-2024-004', note: '' },
    { id: 5, student: 'Diellza Mustafa', amount: 100, method: 'cash', date: '2024-03-01', type: 'registration', status: 'paid', invoice: 'INV-2024-005', note: '' },
    { id: 6, student: 'Kushtrim Gërvalla', amount: 120, method: 'cash', date: '2024-02-20', type: 'lessons', status: 'paid', invoice: 'INV-2024-006', note: '' },
    { id: 7, student: 'Rina Sadiku', amount: 210, method: 'transfer', date: '2024-03-14', type: 'package', status: 'paid', invoice: 'INV-2024-007', note: 'Paketë e plotë' },
  ],
  exams: [
    { id: 1, student: 'Mentor Zejnullahu', type: 'theory', date: '2024-02-20', result: 'passed', score: 87, examiner: 'DPKSH', attempts: 1 },
    { id: 2, student: 'Mentor Zejnullahu', type: 'practical', date: '2024-03-05', result: 'passed', score: null, examiner: 'Driton Morina', attempts: 1 },
    { id: 3, student: 'Vjollca Berisha', type: 'theory', date: '2024-03-10', result: 'passed', score: 92, examiner: 'DPKSH', attempts: 1 },
    { id: 4, student: 'Genc Halili', type: 'theory', date: '2024-02-15', result: 'failed', score: 58, examiner: 'DPKSH', attempts: 1 },
    { id: 5, student: 'Rina Sadiku', type: 'theory', date: '2024-03-18', result: 'scheduled', score: null, examiner: 'DPKSH', attempts: 0 },
  ],
  notifications: [
    { id: 1, type: 'warning', title: 'Licensa afër skadimit', message: 'Licensa e Agim Hysenit skadon pas 30 ditësh', time: '2 orë', read: false, category: 'system' },
    { id: 2, type: 'info', title: 'Orë e re rezervuar', message: 'Arben Krasniqi rezervoi orë për 15 Mars 09:00', time: '3 orë', read: false, category: 'schedule' },
    { id: 3, type: 'success', title: 'Pagesa e pranuar', message: 'Rina Sadiku kreu pagesën prej 210€', time: '5 orë', read: true, category: 'payment' },
    { id: 4, type: 'error', title: 'Borxh i vonuar', message: 'Diellza Mustafa ka borxh prej 250€ mbi 15 ditë', time: '1 ditë', read: true, category: 'payment' },
    { id: 5, type: 'info', title: 'Provim i planifikuar', message: 'Mentor Zejnullahu ka provim teorik nesër', time: '1 ditë', read: true, category: 'exam' },
  ],
  documents: [
    { id: 1, name: 'Kontrata — Arben Krasniqi.pdf', student: 'Arben Krasniqi', type: 'contract', size: '245 KB', date: '2024-01-10', category: 'Kontratë' },
    { id: 2, name: 'Letërnjoftim — Vjollca Berisha.jpg', student: 'Vjollca Berisha', type: 'id', size: '1.2 MB', date: '2024-01-15', category: 'Letërnjoftim' },
    { id: 3, name: 'Raport mjekësor — Genc Halili.pdf', student: 'Genc Halili', type: 'medical', size: '380 KB', date: '2024-02-01', category: 'Mjekësor' },
    { id: 4, name: 'Certifikatë kalimi — Mentor Zejnullahu.pdf', student: 'Mentor Zejnullahu', type: 'certificate', size: '180 KB', date: '2024-03-05', category: 'Certifikatë' },
    { id: 5, name: 'Kontrata — Leonora Ahmeti.pdf', student: 'Leonora Ahmeti', type: 'contract', size: '245 KB', date: '2024-02-10', category: 'Kontratë' },
  ],
  branches: [
    { id: 1, name: 'Dega Prishtinë (Kryesore)', city: 'Prishtinë', address: 'Rruga Nëna Terezë 45', phone: '+383 38 100 200', email: 'prishtine@autoshkolla.com', manager: 'Admin Krasniqi', students: 89, instructors: 3, vehicles: 3, revenue: 24200, status: 'active' },
    { id: 2, name: 'Dega Mitrovicë', city: 'Mitrovicë', address: 'Rruga Skënderbeu 12', phone: '+383 28 300 400', email: 'mitrovice@autoshkolla.com', manager: 'Faton Berisha', students: 34, instructors: 2, vehicles: 2, revenue: 8400, status: 'active' },
    { id: 3, name: 'Dega Prizren', city: 'Prizren', address: 'Rruga Shadervan 8', phone: '+383 29 500 600', email: 'prizren@autoshkolla.com', manager: 'Lule Hasani', students: 25, instructors: 1, vehicles: 1, revenue: 6200, status: 'active' },
  ],
  settings: {
    schoolName: 'AutoShkolla Pro',
    city: 'Prishtinë',
    address: 'Rruga Nëna Terezë 45',
    phone: '+383 38 100 200',
    email: 'info@autoshkolla.com',
    currency: 'EUR',
    language: 'sq',
    timezone: 'Europe/Sarajevo',
    hoursPerLesson: 90,
    minHoursB: 30, minHoursA: 20, minHoursC: 40,
    emailEnabled: true, smsEnabled: true, whatsappEnabled: false, pushEnabled: true,
    debtReminderDays: 7, examReminderHours: 24, documentExpiryDays: 90, licenseExpiryDays: 30,
    twoFactor: false, sessionTimeout: 60, auditLogs: true, forcePasswordChange: false, loginAttempts: 5,
    smtpHost: '', smtpPort: 587, smtpUser: '', smtpPass: '', smsApiKey: '',
    siteTitle: 'AutoShkolla Pro — Prishtinë', siteDesc: '', gaId: '', fbPixel: '', whatsappNum: '', mapsUrl: '',
    liveChat: true, onlineReg: true, googleReviews: false,
    backupAuto: true, backupWeekly: true, cloudSync: false,
  },
  nextInvoiceNum: 8,
}

const STORAGE_KEY = 'autoshkolla_data'

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return { ...DEFAULT_DATA, ...JSON.parse(raw) }
  } catch {}
  return DEFAULT_DATA
}

function saveData(data) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)) } catch {}
}

// ─── HOOK ────────────────────────────────────────────────────────────────────
export function useStore() {
  const [data, setData] = useState(loadData)

  const update = useCallback((updater) => {
    setData(prev => {
      const next = typeof updater === 'function' ? updater(prev) : { ...prev, ...updater }
      saveData(next)
      return next
    })
  }, [])

  // ── STUDENTS ──────────────────────────────────────────────────────────────
  const addStudent = (s) => {
    const id = Date.now()
    const avatar = s.name.trim().split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
    update(d => ({ ...d, students: [{ ...s, id, avatar, hoursCompleted: 0, payments: 0, debt: +s.initialPayment || 0 }, ...d.students] }))
    return id
  }
  const updateStudent = (id, changes) =>
    update(d => ({ ...d, students: d.students.map(s => s.id === id ? { ...s, ...changes } : s) }))
  const deleteStudent = (id) =>
    update(d => ({ ...d, students: d.students.filter(s => s.id !== id) }))

  // ── INSTRUCTORS ───────────────────────────────────────────────────────────
  const addInstructor = (ins) => {
    const id = Date.now()
    const avatar = ins.name.trim().split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
    update(d => ({ ...d, instructors: [{ ...ins, id, avatar, students: 0, hoursThisMonth: 0, rating: 0 }, ...d.instructors] }))
  }
  const updateInstructor = (id, changes) =>
    update(d => ({ ...d, instructors: d.instructors.map(i => i.id === id ? { ...i, ...changes } : i) }))
  const deleteInstructor = (id) =>
    update(d => ({ ...d, instructors: d.instructors.filter(i => i.id !== id) }))

  // ── VEHICLES ──────────────────────────────────────────────────────────────
  const addVehicle = (v) => {
    const id = Date.now()
    update(d => ({ ...d, vehicles: [{ ...v, id, color: '#2563EB' }, ...d.vehicles] }))
  }
  const updateVehicle = (id, changes) =>
    update(d => ({ ...d, vehicles: d.vehicles.map(v => v.id === id ? { ...v, ...changes } : v) }))
  const deleteVehicle = (id) =>
    update(d => ({ ...d, vehicles: d.vehicles.filter(v => v.id !== id) }))

  // ── SCHEDULES ─────────────────────────────────────────────────────────────
  const addSchedule = (s) => {
    const id = Date.now()
    update(d => ({ ...d, schedules: [...d.schedules, { ...s, id }] }))
  }
  const updateSchedule = (id, changes) =>
    update(d => ({ ...d, schedules: d.schedules.map(s => s.id === id ? { ...s, ...changes } : s) }))
  const deleteSchedule = (id) =>
    update(d => ({ ...d, schedules: d.schedules.filter(s => s.id !== id) }))

  // ── PAYMENTS ──────────────────────────────────────────────────────────────
  const addPayment = (p) => {
    const id = Date.now()
    const num = data.nextInvoiceNum
    const invoice = `INV-${new Date().getFullYear()}-${String(num).padStart(3, '0')}`
    const payment = { ...p, id, date: new Date().toISOString().split('T')[0], status: 'paid', invoice }
    update(d => {
      const newStudents = d.students.map(s => {
        if (s.name === p.student) {
          const newDebt = Math.max(0, (s.debt || 0) - +p.amount)
          return { ...s, payments: (s.payments || 0) + +p.amount, debt: newDebt }
        }
        return s
      })
      return { ...d, payments: [payment, ...d.payments], students: newStudents, nextInvoiceNum: num + 1 }
    })
    return invoice
  }
  const deletePayment = (id) =>
    update(d => ({ ...d, payments: d.payments.filter(p => p.id !== id) }))

  // ── EXAMS ─────────────────────────────────────────────────────────────────
  const addExam = (e) => {
    const id = Date.now()
    update(d => ({ ...d, exams: [...d.exams, { ...e, id, attempts: 0 }] }))
  }
  const updateExam = (id, changes) =>
    update(d => ({ ...d, exams: d.exams.map(e => e.id === id ? { ...e, ...changes } : e) }))
  const deleteExam = (id) =>
    update(d => ({ ...d, exams: d.exams.filter(e => e.id !== id) }))

  // ── NOTIFICATIONS ─────────────────────────────────────────────────────────
  const addNotification = (n) => {
    const id = Date.now()
    update(d => ({ ...d, notifications: [{ ...n, id, time: 'Tani', read: false }, ...d.notifications] }))
  }
  const markRead = (id) =>
    update(d => ({ ...d, notifications: d.notifications.map(n => n.id === id ? { ...n, read: true } : n) }))
  const markAllRead = () =>
    update(d => ({ ...d, notifications: d.notifications.map(n => ({ ...n, read: true })) }))
  const deleteNotification = (id) =>
    update(d => ({ ...d, notifications: d.notifications.filter(n => n.id !== id) }))

  // ── DOCUMENTS ─────────────────────────────────────────────────────────────
  const addDocument = (doc) => {
    const id = Date.now()
    update(d => ({ ...d, documents: [{ ...doc, id, date: new Date().toISOString().split('T')[0] }, ...d.documents] }))
  }
  const deleteDocument = (id) =>
    update(d => ({ ...d, documents: d.documents.filter(doc => doc.id !== id) }))

  // ── BRANCHES ──────────────────────────────────────────────────────────────
  const addBranch = (b) => {
    const id = Date.now()
    update(d => ({ ...d, branches: [...d.branches, { ...b, id, students: 0, instructors: 0, vehicles: 0, revenue: 0 }] }))
  }
  const updateBranch = (id, changes) =>
    update(d => ({ ...d, branches: d.branches.map(b => b.id === id ? { ...b, ...changes } : b) }))
  const deleteBranch = (id) =>
    update(d => ({ ...d, branches: d.branches.filter(b => b.id !== id) }))

  // ── SETTINGS ──────────────────────────────────────────────────────────────
  const saveSettings = (changes) =>
    update(d => ({ ...d, settings: { ...d.settings, ...changes } }))

  // ── RESET ─────────────────────────────────────────────────────────────────
  const resetAllData = () => {
    localStorage.removeItem(STORAGE_KEY)
    setData(DEFAULT_DATA)
  }

  return {
    ...data,
    // students
    addStudent, updateStudent, deleteStudent,
    // instructors
    addInstructor, updateInstructor, deleteInstructor,
    // vehicles
    addVehicle, updateVehicle, deleteVehicle,
    // schedules
    addSchedule, updateSchedule, deleteSchedule,
    // payments
    addPayment, deletePayment,
    // exams
    addExam, updateExam, deleteExam,
    // notifications
    addNotification, markRead, markAllRead, deleteNotification,
    // documents
    addDocument, deleteDocument,
    // branches
    addBranch, updateBranch, deleteBranch,
    // settings
    saveSettings,
    // utils
    resetAllData,
  }
}
