import React, { useState } from 'react'
import { Settings, Save, Bell, Shield, Database, Mail, Palette, CheckCircle } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import { exportBackup } from '../utils/exportUtils'
import clsx from 'clsx'

const TABS=[{id:'general',label:'Gjenerali',icon:Settings},{id:'notifications',label:'Njoftime',icon:Bell},{id:'security',label:'Siguria',icon:Shield},{id:'email',label:'Email/SMS',icon:Mail},{id:'appearance',label:'Pamja',icon:Palette},{id:'backup',label:'Backup',icon:Database}]

function Toggle({value,onChange}){return(
  <button type="button" onClick={()=>onChange(!value)} className={clsx('w-10 h-5 rounded-full relative transition-all flex-shrink-0',value?'bg-blue-600':'bg-white/10')}>
    <div className={clsx('absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all',value?'right-0.5':'left-0.5')}/>
  </button>
)}
function Row({label,desc,children}){return(
  <div className="flex items-center justify-between p-3 rounded-xl" style={{background:'rgba(255,255,255,0.02)'}}>
    <div><div className="text-sm font-medium text-white">{label}</div>{desc&&<div className="text-xs text-white/30 mt-0.5">{desc}</div>}</div>
    <div className="ml-4 flex-shrink-0">{children}</div>
  </div>
)}
function FInput({label,k,val,onChange,type='text',placeholder=''}){return(
  <div className="flex flex-col gap-1.5">
    <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">{label}</label>
    <input type={type} className="input" value={val||''} onChange={e=>onChange(k,type==='number'?+e.target.value:e.target.value)} placeholder={placeholder}/>
  </div>
)}

export default function SettingsPage() {
  const { store } = useApp(); const toast = useToast()
  const { settings, saveSettings, students, payments, instructors } = store
  const [tab, setTab] = useState('general')
  const [s, setS] = useState(settings)
  const h = (k,v) => setS(p=>({...p,[k]:v}))
  const handleSave = () => { saveSettings(s); toast('Cilësimet u ruajtën me sukses','success') }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Cilësimet</h1><p className="text-sm text-white/40 mt-0.5">Konfigurim i sistemit</p></div>
        <button onClick={handleSave} className="btn-primary"><Save size={15}/>Ruaj ndryshimet</button>
      </div>

      <div className="flex gap-5 flex-col lg:flex-row">
        {/* Tab list */}
        <div className="flex-shrink-0 lg:w-44 flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible">
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} className={clsx('nav-item flex-shrink-0 lg:w-full justify-start',tab===t.id&&'active')}>
              <t.icon size={16}/><span className="text-sm whitespace-nowrap">{t.label}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          {tab==='general'&&(
            <div className="card">
              <h3 className="font-display font-700 text-white mb-4">Informacionet e Autoshkollës</h3>
              <div className="flex flex-col gap-3">
                <div className="grid grid-cols-2 gap-3">
                  <FInput label="Emri i autoshkollës *" k="schoolName" val={s.schoolName} onChange={h} placeholder="AutoShkolla Pro"/>
                  <FInput label="Qyteti" k="city" val={s.city} onChange={h} placeholder="Prishtinë"/>
                  <div className="col-span-2"><FInput label="Adresa" k="address" val={s.address} onChange={h} placeholder="Rruga Nëna Terezë 45"/></div>
                  <FInput label="Telefoni" k="phone" val={s.phone} onChange={h} placeholder="+383 38 100 200"/>
                  <FInput label="Email" k="email" val={s.email} onChange={h} type="email" placeholder="info@autoshkolla.com"/>
                </div>
                <div className="divider"/>
                <h4 className="text-xs font-semibold text-white/30 uppercase tracking-widest">Lokalizimi</h4>
                <div className="grid grid-cols-2 gap-3">
                  <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Gjuha</label><select className="select" value={s.language||'sq'} onChange={e=>h('language',e.target.value)}><option value="sq">Shqip</option><option value="en">English</option></select></div>
                  <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Monedha</label><select className="select" value={s.currency||'EUR'} onChange={e=>h('currency',e.target.value)}><option value="EUR">EUR (€)</option><option value="USD">USD ($)</option></select></div>
                </div>
                <div className="divider"/>
                <h4 className="text-xs font-semibold text-white/30 uppercase tracking-widest">Konfigurimi i orëve</h4>
                <div className="grid grid-cols-2 gap-3">
                  <FInput label="Orë min. Kat. B" k="minHoursB" val={s.minHoursB} onChange={h} type="number"/>
                  <FInput label="Orë min. Kat. A" k="minHoursA" val={s.minHoursA} onChange={h} type="number"/>
                  <FInput label="Orë min. Kat. C" k="minHoursC" val={s.minHoursC} onChange={h} type="number"/>
                  <FInput label="Kohëzgjatja orës (min)" k="hoursPerLesson" val={s.hoursPerLesson} onChange={h} type="number"/>
                </div>
              </div>
            </div>
          )}

          {tab==='notifications'&&(
            <div className="card">
              <h3 className="font-display font-700 text-white mb-4">Kanalet e Njoftimeve</h3>
              <div className="flex flex-col gap-2 mb-4">
                <Row label="Email njoftime" desc="Dërgo njoftime nëpërmjet email-it"><Toggle value={s.emailEnabled} onChange={v=>h('emailEnabled',v)}/></Row>
                <Row label="SMS njoftime" desc="Njoftime direkte në telefon"><Toggle value={s.smsEnabled} onChange={v=>h('smsEnabled',v)}/></Row>
                <Row label="WhatsApp API" desc="Kërkon WhatsApp Business API"><Toggle value={s.whatsappEnabled} onChange={v=>h('whatsappEnabled',v)}/></Row>
                <Row label="Push notifications" desc="Njoftime në browser"><Toggle value={s.pushEnabled} onChange={v=>h('pushEnabled',v)}/></Row>
              </div>
              <div className="divider"/>
              <h4 className="text-xs font-semibold text-white/30 uppercase tracking-widest mb-3">Kujtesa automatike</h4>
              <div className="grid grid-cols-2 gap-3">
                <FInput label="Kujtesë borxhi (ditë pas)" k="debtReminderDays" val={s.debtReminderDays} onChange={h} type="number"/>
                <FInput label="Kujtesë provimi (orë para)" k="examReminderHours" val={s.examReminderHours} onChange={h} type="number"/>
                <FInput label="Alarm skadim dok. (ditë)" k="documentExpiryDays" val={s.documentExpiryDays} onChange={h} type="number"/>
                <FInput label="Alarm licencë (ditë)" k="licenseExpiryDays" val={s.licenseExpiryDays} onChange={h} type="number"/>
              </div>
            </div>
          )}

          {tab==='security'&&(
            <div className="card">
              <h3 className="font-display font-700 text-white mb-4">Siguria e Sistemit</h3>
              <div className="flex flex-col gap-2 mb-4">
                <Row label="Autentifikim 2FA" desc="Kërkon kod shtesë gjatë hyrjes"><Toggle value={s.twoFactor} onChange={v=>h('twoFactor',v)}/></Row>
                <Row label="Audit logs" desc="Regjistro të gjitha veprimet"><Toggle value={s.auditLogs} onChange={v=>h('auditLogs',v)}/></Row>
                <Row label="Ndryshim i detyrueshëm i fjalëkalimit" desc="Çdo 90 ditë"><Toggle value={s.forcePasswordChange} onChange={v=>h('forcePasswordChange',v)}/></Row>
              </div>
              <div className="divider"/>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <FInput label="Skadim sesioni (min)" k="sessionTimeout" val={s.sessionTimeout} onChange={h} type="number"/>
                <FInput label="Max tentativa hyrje" k="loginAttempts" val={s.loginAttempts} onChange={h} type="number"/>
              </div>
              <div className="divider"/>
              <h4 className="text-xs font-semibold text-white/30 uppercase tracking-widest mb-3">Ndrysho fjalëkalimin</h4>
              <div className="flex flex-col gap-3">
                {['Fjalëkalimi aktual','Fjalëkalimi i ri','Konfirmo fjalëkalimin'].map(l=>(
                  <div key={l} className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-white/40 uppercase tracking-wider">{l}</label><input type="password" className="input" placeholder="••••••••"/></div>
                ))}
                <button onClick={()=>toast('Fjalëkalimi u ndryshua me sukses','success')} className="btn-primary w-fit">Ndrysho fjalëkalimin</button>
              </div>
            </div>
          )}

          {tab==='email'&&(
            <div className="card">
              <h3 className="font-display font-700 text-white mb-4">SMTP — Email</h3>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <FInput label="SMTP Host" k="smtpHost" val={s.smtpHost} onChange={h} placeholder="smtp.gmail.com"/>
                <FInput label="SMTP Port" k="smtpPort" val={s.smtpPort} onChange={h} type="number" placeholder="587"/>
                <FInput label="Username" k="smtpUser" val={s.smtpUser} onChange={h} placeholder="noreply@autoshkolla.com"/>
                <div className="flex flex-col gap-1.5"><label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Fjalëkalimi</label><input type="password" className="input" placeholder="••••••••"/></div>
              </div>
              <button onClick={()=>toast('Lidhja SMTP kërkon server real','info')} className="btn-secondary w-fit mb-5"><Mail size={14}/>Testo lidhjen</button>
              <div className="divider"/>
              <h3 className="font-display font-700 text-white mt-4 mb-4">SMS Gateway</h3>
              <FInput label="API Key" k="smsApiKey" val={s.smsApiKey} onChange={h} placeholder="sk_live_..."/>
              <button onClick={()=>toast('SMS kërkon gateway real','info')} className="btn-secondary w-fit mt-3">Testo SMS</button>
            </div>
          )}

          {tab==='appearance'&&(
            <div className="card">
              <h3 className="font-display font-700 text-white mb-4">Tema & Pamja</h3>
              <div className="grid grid-cols-3 gap-3">
                {[['dark','Dark Mode','#020617','#0F172A'],['midnight','Deep Midnight','#0B1220','#1E293B'],['slate','Slate Pro','#0F172A','#1E293B']].map(([v,l,bg,card])=>(
                  <div key={v} className="p-4 rounded-xl border-2 cursor-pointer border-blue-600" style={{background:bg}}>
                    <div className="w-full h-8 rounded-lg mb-2" style={{background:card}}/>
                    <div className="text-xs font-semibold text-white">{l}</div>
                    <CheckCircle size={14} color="#2563EB" className="mt-1"/>
                  </div>
                ))}
              </div>
            </div>
          )}

          {tab==='backup'&&(
            <div className="card">
              <h3 className="font-display font-700 text-white mb-4">Backup & Rivendosja</h3>
              <div className="flex flex-col gap-2 mb-5">
                <Row label="Backup ditor automatik" desc="Çdo ditë në 02:00"><Toggle value={s.backupAuto} onChange={v=>h('backupAuto',v)}/></Row>
                <Row label="Backup javor" desc="Çdo të Hënë"><Toggle value={s.backupWeekly} onChange={v=>h('backupWeekly',v)}/></Row>
                <Row label="Cloud sync" desc="Sinkronizim me cloud"><Toggle value={s.cloudSync} onChange={v=>h('cloudSync',v)}/></Row>
              </div>
              <div className="divider"/>
              <div className="flex gap-3 mb-5">
                <button onClick={()=>{exportBackup({students,payments,instructors,settings:s});toast('Backup u shkarkua me sukses','success')}} className="btn-primary"><Database size={15}/>Krijo backup tani</button>
              </div>
              <h4 className="text-xs font-semibold text-white/30 uppercase tracking-widest mb-3">Backup-et e fundit</h4>
              <div className="flex flex-col gap-2">
                {[`backup_${new Date().toISOString().split('T')[0]}.json`,`backup_${new Date(Date.now()-86400000).toISOString().split('T')[0]}.json`].map(name=>(
                  <div key={name} className="flex items-center justify-between p-3 rounded-xl" style={{background:'rgba(255,255,255,0.02)'}}>
                    <div className="text-sm text-white">{name}</div>
                    <button onClick={()=>{exportBackup({students,payments,instructors,settings:s});toast('Backup u shkarkua','success')}} className="btn-secondary text-xs py-1.5 px-3">Shkarko</button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
