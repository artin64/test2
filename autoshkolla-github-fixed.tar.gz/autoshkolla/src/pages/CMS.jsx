import React, { useState } from 'react'
import { Globe, Save, Plus, Edit2, Trash2, Star, X, ToggleLeft, ToggleRight } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import clsx from 'clsx'

const TABS=[{id:'pages',label:'Faqet'},{id:'pricing',label:'Çmimet'},{id:'reviews',label:'Vlerësimet'},{id:'faq',label:'FAQ'},{id:'settings',label:'Web Cilësimet'}]
const initPages=[{id:1,name:'Ballina (Home)',path:'/',status:true},{id:2,name:'Rreth nesh',path:'/about',status:true},{id:3,name:'Shërbimet',path:'/services',status:true},{id:4,name:'Çmimet',path:'/pricing',status:true},{id:5,name:'Kontakti',path:'/contact',status:true},{id:6,name:'Blog',path:'/blog',status:false}]
const initPricing=[{id:1,name:'Kategoria B — Bazike',price:320,features:['30 orë praktike','Material teorik','2 provime'],popular:false},{id:2,name:'Kategoria B — Premium',price:380,features:['35 orë praktike','Teste online të pakufizuara','Retry falas','Certifikatë'],popular:true},{id:3,name:'Kategoria A',price:220,features:['20 orë praktike','Material teorik','1 provim'],popular:false}]
const initFaq=[{id:1,q:'Sa zgjat procesi i marrjes së patentës?',a:'Zakonisht 2-3 muaj, duke përfshirë të gjitha orët praktike dhe provimet.',active:true},{id:2,q:'Çfarë dokumentesh nevojiten?',a:'Letërnjoftim, raport mjekësor, 2 foto dhe pagesa e regjistrimit.',active:true},{id:3,q:'A mund të ndërroj instruktorin?',a:'Po, mund ta bëni kërkesën pranë recepsionit.',active:true}]

export default function CMS() {
  const { store } = useApp(); const toast = useToast()
  const { settings, saveSettings } = store
  const [tab, setTab] = useState('pages')
  const [pages, setPages] = useState(initPages)
  const [pricing] = useState(initPricing)
  const [faqs, setFaqs] = useState(initFaq)
  const [webS, setWebS] = useState({ siteTitle:settings.siteTitle||'', siteDesc:settings.siteDesc||'', gaId:settings.gaId||'', fbPixel:settings.fbPixel||'', whatsappNum:settings.whatsappNum||'', mapsUrl:settings.mapsUrl||'', liveChat:settings.liveChat??true, onlineReg:settings.onlineReg??true, googleReviews:settings.googleReviews??false })

  const togglePage = id => setPages(p=>p.map(pg=>pg.id===id?{...pg,status:!pg.status}:pg))
  const toggleFaq = id => setFaqs(f=>f.map(fq=>fq.id===id?{...fq,active:!fq.active}:fq))
  const hWeb = (k,v) => setWebS(p=>({...p,[k]:v}))
  const saveWeb = () => { saveSettings(webS); toast('Cilësimet e webfaqes u ruajtën','success') }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Webfaqja Publike</h1><p className="text-sm text-white/40 mt-0.5">Menaxhim i faqeve dhe përmbajtjes</p></div>
        <div className="flex gap-2">
          <button onClick={()=>toast('Faqja publike kërkon hosting të veçantë','info')} className="btn-secondary"><Globe size={15}/>Preview</button>
          <button onClick={saveWeb} className="btn-primary"><Save size={15}/>Publiko</button>
        </div>
      </div>

      <div className="flex gap-1 border-b border-white/06 pb-0.5 overflow-x-auto">
        {TABS.map(t=><button key={t.id} onClick={()=>setTab(t.id)} className={clsx('px-4 py-2 text-sm font-semibold transition-all whitespace-nowrap',tab===t.id?'text-white border-b-2 border-blue-500':'text-white/40 hover:text-white/70')}>{t.label}</button>)}
      </div>

      {tab==='pages'&&(
        <div className="table-container">
          <table className="data-table">
            <thead><tr><th>Faqja</th><th>URL</th><th>Statusi</th><th>Veprime</th></tr></thead>
            <tbody>
              {pages.map(p=>(
                <tr key={p.id}>
                  <td className="font-medium text-white">{p.name}</td>
                  <td className="font-mono text-xs text-blue-400">autoshkolla.com{p.path}</td>
                  <td><button onClick={()=>togglePage(p.id)} className="flex items-center gap-2">{p.status?<><ToggleRight size={20} color="#10B981"/><span className="text-success text-xs font-semibold">Aktiv</span></>:<><ToggleLeft size={20} color="#6B7280"/><span className="text-white/30 text-xs">Joaktiv</span></>}</button></td>
                  <td><button onClick={()=>toast('Editori i faqeve kërkon CMS backend','info')} className="icon-btn w-7 h-7"><Edit2 size={13}/></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab==='pricing'&&(
        <div className="grid-3">
          {pricing.map(pkg=>(
            <div key={pkg.id} className={clsx('card relative',pkg.popular&&'border-blue-600/30')}>
              {pkg.popular&&<div className="absolute -top-3 left-1/2 -translate-x-1/2"><span className="bg-blue-600 text-white text-xs font-semibold px-3 py-1 rounded-full">Më e popullarizuara</span></div>}
              <div className="mb-4"><div className="font-display text-base font-700 text-white">{pkg.name}</div><div className="font-display text-3xl font-700 text-white mt-1">€{pkg.price}</div></div>
              <div className="flex flex-col gap-1.5 mb-4">
                {pkg.features.map((f,i)=><div key={i} className="flex items-center gap-2 text-xs text-white/60"><div className="w-1.5 h-1.5 rounded-full bg-blue-500 flex-shrink-0"/>{f}</div>)}
              </div>
              <button onClick={()=>toast('Çmimet u përditësuan','success')} className="btn-secondary w-full text-xs py-2"><Edit2 size={13}/>Edito çmimin</button>
            </div>
          ))}
        </div>
      )}

      {tab==='reviews'&&(
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-3 mb-1">
            <div className="flex">{[1,2,3,4,5].map(s=><Star key={s} size={16} fill="#F59E0B" color="#F59E0B"/>)}</div>
            <span className="text-white font-semibold">4.9 mesatare</span>
          </div>
          {[{name:'Ardita K.',rating:5,text:'Instruktorë shumë profesionistë! E kalova provimin herën e parë.',approved:true},{name:'Blerim H.',rating:4,text:'Sistem i mirë organizuar. Rekomandoj.',approved:true},{name:'Fatmira S.',rating:5,text:'Faleminderit! Mësova me lehtësi.',approved:false}].map((r,i)=>(
            <div key={i} className="card">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="avatar w-9 h-9 text-xs">{r.name.split(' ').map(n=>n[0]).join('')}</div>
                  <div><div className="font-semibold text-white text-sm">{r.name}</div><div className="flex mt-0.5">{[1,2,3,4,5].map(s=><Star key={s} size={11} fill={s<=r.rating?'#F59E0B':'none'} color="#F59E0B"/>)}</div></div>
                </div>
                <span className={clsx('badge',r.approved?'badge-success':'badge-warning')}>{r.approved?'Aprovuar':'Në pritje'}</span>
              </div>
              <p className="text-sm text-white/60 italic">"{r.text}"</p>
              <div className="flex gap-2 mt-3">
                {!r.approved&&<button onClick={()=>toast('Vlerësimi u aprovua','success')} className="btn-primary text-xs py-1.5 px-3">Aprovo</button>}
                <button onClick={()=>toast('Vlerësimi u fshi','warning')} className="btn-danger text-xs py-1.5 px-3"><Trash2 size={12}/>Fshi</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab==='faq'&&(
        <div className="flex flex-col gap-3">
          <div className="flex justify-end"><button onClick={()=>toast('Shto pyetje — kërkon CMS editor','info')} className="btn-primary"><Plus size={15}/>Shto pyetje</button></div>
          {faqs.map(f=>(
            <div key={f.id} className="card">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1"><div className="font-semibold text-white text-sm">{f.q}</div><div className="text-xs text-white/50 mt-1.5">{f.a}</div></div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button onClick={()=>toggleFaq(f.id)} className={clsx('badge cursor-pointer',f.active?'badge-success':'badge-default')}>{f.active?'Aktiv':'Joaktiv'}</button>
                  <button onClick={()=>setFaqs(prev=>prev.filter(x=>x.id!==f.id))} className="icon-btn w-7 h-7 hover:text-error"><Trash2 size={13}/></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab==='settings'&&(
        <div className="card">
          <h3 className="font-display font-700 text-white mb-4">Cilësimet e Webfaqes</h3>
          <div className="grid grid-cols-2 gap-3 mb-4">
            {[['siteTitle','Titulli SEO','text','AutoShkolla Pro — Prishtinë'],['siteDesc','Përshkrimi SEO','text','Autoshkolla profesionale...'],['gaId','Google Analytics ID','text','G-XXXXXXXXXX'],['fbPixel','Facebook Pixel ID','text','123456789'],['whatsappNum','WhatsApp numri','text','+383 44 000 000'],['mapsUrl','Google Maps URL','text','https://maps.google.com/...']].map(([k,l,t,ph])=>(
              <div key={k} className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">{l}</label>
                <input type={t} className="input" value={webS[k]||''} onChange={e=>hWeb(k,e.target.value)} placeholder={ph}/>
              </div>
            ))}
          </div>
          <div className="divider"/>
          <div className="flex flex-col gap-2 mt-3">
            {[['liveChat','Live chat widget'],['onlineReg','Online regjistrim i kandidatëve'],['googleReviews','Google Reviews widget']].map(([k,l])=>(
              <div key={k} className="flex items-center justify-between p-3 rounded-xl" style={{background:'rgba(255,255,255,0.02)'}}>
                <span className="text-sm font-medium text-white">{l}</span>
                <div className={clsx('w-10 h-5 rounded-full relative cursor-pointer transition-all',webS[k]?'bg-blue-600':'bg-white/10')} onClick={()=>hWeb(k,!webS[k])}>
                  <div className={clsx('absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all',webS[k]?'right-0.5':'left-0.5')}/>
                </div>
              </div>
            ))}
          </div>
          <button onClick={saveWeb} className="btn-primary mt-4"><Save size={15}/>Ruaj cilësimet</button>
        </div>
      )}
    </div>
  )
}
