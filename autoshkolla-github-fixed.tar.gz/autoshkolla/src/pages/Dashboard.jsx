import React from 'react'
import { Link } from 'react-router-dom'
import { Users, UserCheck, Car, Clock, CreditCard, AlertTriangle, TrendingUp, GraduationCap, Plus, Calendar, ArrowUpRight, CheckCircle2 } from 'lucide-react'
import { AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { useApp } from '../context/AppContext'
import clsx from 'clsx'

const monthlyRevenue = [
  { month: 'Tet', rev: 4200, exp: 1800 }, { month: 'Nën', rev: 5100, exp: 2100 },
  { month: 'Dhj', rev: 4800, exp: 1900 }, { month: 'Jan', rev: 6200, exp: 2400 },
  { month: 'Shk', rev: 7100, exp: 2600 }, { month: 'Mar', rev: 6800, exp: 2500 },
]
const catColors = ['#2563EB', '#06B6D4', '#10B981', '#F59E0B']
const TT = ({ active, payload, label }) => active && payload?.length ? (
  <div className="card p-2.5 text-xs">
    <div className="text-white/50 mb-1.5 font-medium">{label}</div>
    {payload.map((p, i) => <div key={i} className="flex justify-between gap-4"><span className="text-white/50">{p.name}</span><span className="text-white font-semibold">{typeof p.value === 'number' ? `€${p.value.toLocaleString()}` : p.value}</span></div>)}
  </div>
) : null

function StatCard({ icon: Icon, label, value, sub, trend, color = '#2563EB', to }) {
  const content = (
    <div className="stat-card h-full">
      <div className="flex items-start justify-between">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${color}18`, color }}>
          <Icon size={18} />
        </div>
        {trend !== undefined && (
          <div className={clsx('flex items-center gap-1 text-xs font-semibold', trend >= 0 ? 'text-success' : 'text-error')}>
            <ArrowUpRight size={12} />{Math.abs(trend)}%
          </div>
        )}
      </div>
      <div>
        <div className="font-display text-2xl font-700 text-white">{value}</div>
        <div className="text-sm text-white/50 mt-0.5">{label}</div>
        {sub && <div className="text-xs text-white/25 mt-0.5">{sub}</div>}
      </div>
    </div>
  )
  return to ? <Link to={to} className="block">{content}</Link> : content
}

export default function Dashboard() {
  const { store } = useApp()
  const { students, instructors, vehicles, schedules, payments, notifications, exams } = store

  const activeStudents = students.filter(s => s.status === 'active').length
  const totalRevenue = payments.reduce((a, p) => a + +p.amount, 0)
  const totalDebt = students.reduce((a, s) => a + (s.debt || 0), 0)
  const todaySchedules = schedules.filter(s => s.date === schedules[0]?.date || s.date === new Date().toISOString().split('T')[0]).slice(0, 5)
  const unreadNotifs = notifications.filter(n => !n.read)
  const catStats = ['B', 'A', 'C', 'D'].map((c, i) => ({ name: `Kat. ${c}`, value: students.filter(s => s.category.startsWith(c)).length || 0, color: catColors[i] })).filter(c => c.value > 0)
  const upcomingExams = exams.filter(e => e.result === 'scheduled').length
  const passRate = exams.length ? Math.round((exams.filter(e => e.result === 'passed').length / exams.filter(e => e.result !== 'scheduled').length || 0) * 100) : 0

  return (
    <div className="flex flex-col gap-5">
      {/* Welcome */}
      <div className="card relative overflow-hidden py-5" style={{ background: 'linear-gradient(135deg,#0B1220,#1E293B)' }}>
        <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at 80% 50%, rgba(37,99,235,0.12) 0%, transparent 60%)' }} />
        <div className="relative flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="text-white/40 text-xs uppercase tracking-widest mb-1">Paneli kryesor</div>
            <h2 className="font-display text-2xl font-700 text-white">AutoShkolla Pro</h2>
            <p className="text-white/40 text-sm mt-1">{new Date().toLocaleDateString('sq-AL', { weekday:'long', day:'numeric', month:'long', year:'numeric' })}</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Link to="/students/new" className="btn-primary"><Plus size={15} />Kandidat i ri</Link>
            <Link to="/schedule" className="btn-secondary"><Calendar size={15} />Rezervo orë</Link>
          </div>
        </div>
      </div>

      {/* KPI grid */}
      <div className="stats-grid">
        <StatCard icon={Users} label="Kandidatë total" value={students.length} trend={12} color="#2563EB" to="/students" />
        <StatCard icon={UserCheck} label="Aktiv tani" value={activeStudents} sub={`nga ${students.length} total`} trend={8} color="#10B981" to="/students" />
        <StatCard icon={Clock} label="Orë sot" value={todaySchedules.length} sub={`${instructors.filter(i=>i.status==='active').length} instruktorë aktiv`} color="#06B6D4" to="/schedule" />
        <StatCard icon={CreditCard} label="Të ardhura" value={`€${totalRevenue.toLocaleString()}`} trend={18} color="#F59E0B" to="/payments" />
        <StatCard icon={AlertTriangle} label="Borxhe aktive" value={`€${totalDebt}`} sub="Nevojiten kujtesa" trend={-5} color="#EF4444" to="/payments/debts" />
        <StatCard icon={Car} label="Vetura aktive" value={vehicles.filter(v=>v.status==='active').length} sub={`${vehicles.filter(v=>v.status==='maintenance').length} në servis`} color="#8B5CF6" to="/vehicles" />
        <StatCard icon={GraduationCap} label="Provime radhazi" value={upcomingExams} sub="të planifikuara" color="#06B6D4" to="/exams" />
        <StatCard icon={TrendingUp} label="Norma kalimi" value={`${passRate}%`} trend={3} color="#10B981" to="/reports" />
      </div>

      {/* Charts */}
      <div className="grid-2">
        <div className="card">
          <h3 className="font-display font-700 text-white mb-1">Të ardhurat 6 muajt e fundit</h3>
          <p className="text-xs text-white/30 mb-4">Të ardhura vs shpenzime</p>
          <ResponsiveContainer width="100%" height={190}>
            <AreaChart data={monthlyRevenue} margin={{ left: -20, right: 0, top: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#2563EB" stopOpacity={0.3} /><stop offset="95%" stopColor="#2563EB" stopOpacity={0} /></linearGradient>
                <linearGradient id="g2" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#06B6D4" stopOpacity={0.2} /><stop offset="95%" stopColor="#06B6D4" stopOpacity={0} /></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="month" tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'rgba(255,255,255,0.3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip content={<TT />} />
              <Area type="monotone" dataKey="rev" name="Të ardhura" stroke="#2563EB" strokeWidth={2} fill="url(#g1)" />
              <Area type="monotone" dataKey="exp" name="Shpenzime" stroke="#06B6D4" strokeWidth={2} fill="url(#g2)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="flex flex-col gap-4">
          <div className="card flex-1">
            <h3 className="font-display font-700 text-white mb-3 text-sm">Kandidatët sipas kategorisë</h3>
            <div className="flex items-center gap-4">
              <ResponsiveContainer width={90} height={90}>
                <PieChart><Pie data={catStats.length ? catStats : [{ name: 'Pa të dhëna', value: 1, color: '#1E293B' }]} innerRadius={26} outerRadius={42} paddingAngle={3} dataKey="value">
                  {(catStats.length ? catStats : [{ color: '#1E293B' }]).map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie></PieChart>
              </ResponsiveContainer>
              <div className="flex flex-col gap-1.5 flex-1">
                {catStats.map((c, i) => (
                  <div key={i} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full" style={{ background: c.color }} /><span className="text-white/50">{c.name}</span></div>
                    <span className="text-white font-semibold">{c.value}</span>
                  </div>
                ))}
                {catStats.length === 0 && <div className="text-xs text-white/30">Pa kandidatë</div>}
              </div>
            </div>
          </div>
          <div className="card flex-1">
            <h3 className="font-display font-700 text-white mb-3 text-sm">Statistika të shpejta</h3>
            <div className="flex flex-col gap-2">
              {[
                ['Instruktorë aktiv', instructors.filter(i => i.status === 'active').length, '#10B981'],
                ['Kandidatë diplomuar', students.filter(s => s.status === 'completed').length, '#2563EB'],
                ['Provime kaluar', exams.filter(e => e.result === 'passed').length, '#06B6D4'],
              ].map(([l, v, c]) => (
                <div key={l} className="flex items-center justify-between">
                  <span className="text-xs text-white/50">{l}</span>
                  <span className="text-sm font-semibold" style={{ color: c }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid-2">
        {/* Today's schedule */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-700 text-white">Oraret e sotme</h3>
            <Link to="/schedule" className="text-xs text-blue-400 hover:text-blue-300">Shiko të gjitha →</Link>
          </div>
          <div className="flex flex-col gap-2">
            {schedules.slice(0, 5).map(s => (
              <div key={s.id} className="flex items-center gap-3 p-2.5 rounded-xl" style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.04)' }}>
                <div className="text-center w-12 flex-shrink-0">
                  <div className="text-white font-semibold text-sm">{s.time}</div>
                  <div className="text-white/30 text-xs">{s.duration}min</div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-white truncate">{s.student}</div>
                  <div className="text-xs text-white/40 truncate">{s.instructor} · {s.vehicle}</div>
                </div>
                <span className={clsx('badge flex-shrink-0', s.status === 'confirmed' ? 'badge-success' : s.status === 'pending' ? 'badge-warning' : 'badge-info')}>
                  {s.status === 'confirmed' ? 'Konfirmuar' : s.status === 'pending' ? 'Pritje' : 'Provim'}
                </span>
              </div>
            ))}
            {schedules.length === 0 && <div className="text-center py-6 text-white/30 text-sm">Nuk ka orare</div>}
          </div>
        </div>

        {/* Recent students */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-700 text-white">Kandidatët aktiv</h3>
            <Link to="/students" className="text-xs text-blue-400 hover:text-blue-300">Shiko të gjithë →</Link>
          </div>
          <div className="flex flex-col gap-2">
            {students.filter(s => s.status === 'active').slice(0, 5).map(s => (
              <div key={s.id} className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/02 transition-colors">
                <div className="avatar w-8 h-8 text-xs flex-shrink-0">{s.avatar}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-white truncate">{s.name}</div>
                  <div className="progress-bar mt-1"><div className="progress-fill" style={{ width: `${Math.round((s.hoursCompleted / s.hoursTotal) * 100)}%` }} /></div>
                </div>
                <span className="badge badge-info text-xs">Kat. {s.category}</span>
              </div>
            ))}
            {students.filter(s => s.status === 'active').length === 0 && <div className="text-center py-6 text-white/30 text-sm">Pa kandidatë aktiv</div>}
          </div>
        </div>
      </div>

      {/* Unread notifications */}
      {unreadNotifs.length > 0 && (
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-display font-700 text-white">Njoftime të reja</h3>
            <Link to="/notifications" className="text-xs text-blue-400 hover:text-blue-300">Shiko të gjitha →</Link>
          </div>
          <div className="flex flex-col gap-2">
            {unreadNotifs.slice(0, 3).map(n => (
              <div key={n.id} className="flex items-center gap-3 p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)' }}>
                <div className={clsx('w-2 h-2 rounded-full flex-shrink-0', n.type === 'warning' ? 'bg-warning' : n.type === 'error' ? 'bg-error' : n.type === 'success' ? 'bg-success' : 'bg-info')} />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-white">{n.title}</div>
                  <div className="text-xs text-white/40 truncate">{n.message}</div>
                </div>
                <span className="text-xs text-white/20 flex-shrink-0">{n.time}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
