import React, { useState } from 'react'
import { CreditCard, Plus, Download, Search, Printer, Trash2, X, AlertCircle } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import { exportPaymentsExcel, printInvoice } from '../utils/exportUtils'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import clsx from 'clsx'

const mRev = [{month:'Tet',rev:4200},{month:'Nën',rev:5100},{month:'Dhj',rev:4800},{month:'Jan',rev:6200},{month:'Shk',rev:7100},{month:'Mar',rev:6800}]
const METHOD = { cash:'Cash', transfer:'Transfer', card:'Kartë', online:'Online' }
const MTYPE = { cash:'badge-success', transfer:'badge-info', card:'badge-default', online:'badge-warning' }
const PTYPE = { registration:'Regjistrim', lessons:'Orë vozitjeje', package:'Paketë', exam:'Provim' }

function PayModal({ students, settings, onClose, onSave }) {
  const [f, setF] = useState({ student:'',amount:'',method:'cash',type:'lessons',note:'' })
  const [errs, setErrs] = useState({})
  const h = (k,v) => { setF(p=>({...p,[k]:v})); setErrs(e=>({...e,[k]:''})) }
  const submit = () => {
    const e = {}
    if (!f.student) e.student = 'Zgjidh kandidatin'
    if (!f.amount || +f.amount <= 0) e.amount = 'Shuma duhet të jetë pozitive'
    if (Object.keys(e).length) { setErrs(e); return }
    const inv = onSave(f); onClose()
  }
  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal p-6">
        <div className="flex items-center justify-between mb-5"><h2 className="font-display text-xl font-700 text-white">Regjistro Pagesë</h2><button onClick={onClose} className="icon-btn"><X size={16}/></button></div>
        <div className="flex flex-col gap-3">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Kandidati *</label>
            <select className={clsx('select',errs.student&&'border-error')} value={f.student} onChange={e=>h('student',e.target.value)}>
              <option value="">Zgjidh kandidatin...</option>
              {students.map(s=><option key={s.id}>{s.name}</option>)}
            </select>
            {errs.student&&<span className="text-xs text-error">{errs.student}</span>}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Shuma (€) *</label>
              <input type="number" className={clsx('input',errs.amount&&'border-error')} value={f.amount} onChange={e=>h('amount',e.target.value)} placeholder="0"/>
              {errs.amount&&<span className="text-xs text-error">{errs.amount}</span>}
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Metoda</label>
              <select className="select" value={f.method} onChange={e=>h('method',e.target.value)}>
                <option value="cash">Cash</option><option value="transfer">Transfer bankar</option><option value="card">Kartë</option><option value="online">Online</option>
              </select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Lloji</label>
              <select className="select" value={f.type} onChange={e=>h('type',e.target.value)}>
                <option value="registration">Regjistrim</option><option value="lessons">Orë vozitjeje</option><option value="package">Paketë e plotë</option><option value="exam">Provim</option>
              </select>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Shënim</label>
              <input className="input" value={f.note} onChange={e=>h('note',e.target.value)} placeholder="Opsionale..."/>
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-5"><button onClick={onClose} className="btn-secondary">Anulo</button><button onClick={submit} className="btn-primary"><CreditCard size={15}/>Regjistro pagesën</button></div>
      </div>
    </div>
  )
}

export default function Payments() {
  const { store } = useApp(); const toast = useToast()
  const { payments, students, settings, addPayment, deletePayment } = store
  const [search, setSearch] = useState(''); const [showModal, setShowModal] = useState(false)
  const debts = students.filter(s=>s.debt>0)

  const filtered = payments.filter(p=>p.student.toLowerCase().includes(search.toLowerCase())||(p.invoice||'').includes(search))
  const totalRev = payments.reduce((a,p)=>a+(+p.amount),0)
  const totalDebt = debts.reduce((a,s)=>a+(s.debt||0),0)

  const save = f => {
    const inv = addPayment(f)
    toast(`Pagesa prej €${f.amount} u regjistrua — ${inv}`,'success')
    return inv
  }

  const printInv = (p) => {
    printInvoice(p, settings)
    toast('Fatura u hap për printim','info')
  }

  const del = p => {
    if (!confirm(`Fshi faturën ${p.invoice}?`)) return
    deletePayment(p.id); toast('Pagesa u fshi','warning')
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Pagesat</h1><p className="text-sm text-white/40 mt-0.5">{payments.length} transaksione</p></div>
        <div className="flex gap-2">
          <button onClick={()=>{exportPaymentsExcel(filtered);toast(`${filtered.length} pagesa u eksportuan`,'success')}} className="btn-secondary"><Download size={15}/>Excel</button>
          <button onClick={()=>setShowModal(true)} className="btn-primary"><Plus size={15}/>Regjistro pagesë</button>
        </div>
      </div>

      <div className="stats-grid">
        {[['Të ardhura totale',`€${totalRev.toLocaleString()}`,'#10B981'],['Borxhe aktive',`€${totalDebt}`,'#EF4444'],['Transaksione',payments.length,'#2563EB'],['Ky muaj',`€${mRev[5].rev.toLocaleString()}`,'#06B6D4']].map(([l,v,c],i)=>(
          <div key={i} className="stat-card"><div className="font-display text-2xl font-700 text-white">{v}</div><div className="text-sm text-white/50">{l}</div></div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <h3 className="font-display font-700 text-white mb-4">Të ardhurat mujore</h3>
          <ResponsiveContainer width="100%" height={170}>
            <BarChart data={mRev} margin={{left:-20,right:0,top:0,bottom:0}}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)"/>
              <XAxis dataKey="month" tick={{fill:'rgba(255,255,255,0.3)',fontSize:11}} axisLine={false} tickLine={false}/>
              <YAxis tick={{fill:'rgba(255,255,255,0.3)',fontSize:11}} axisLine={false} tickLine={false}/>
              <Tooltip cursor={{fill:'rgba(255,255,255,0.03)'}} contentStyle={{background:'#0F172A',border:'1px solid rgba(255,255,255,0.08)',borderRadius:12,fontSize:12}}/>
              <Bar dataKey="rev" name="Të ardhura €" fill="#2563EB" radius={[4,4,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-display font-700 text-white">Borxhet aktive</h3>
            <span className="badge badge-error">€{totalDebt} total</span>
          </div>
          {debts.length===0?<div className="text-center py-6 text-white/30 text-sm">Nuk ka borxhe aktive 🎉</div>:
          <div className="flex flex-col gap-2">
            {debts.map(s=>(
              <div key={s.id} className="flex items-center gap-3 p-3 rounded-xl" style={{background:'rgba(239,68,68,0.05)',border:'1px solid rgba(239,68,68,0.1)'}}>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-white">{s.name}</div>
                  <div className="text-xs text-white/40">Kat. {s.category}</div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-error font-semibold">€{s.debt}</div>
                  <button onClick={()=>{navigator.clipboard?.writeText(s.phone||'');toast(`Telefoni: ${s.phone}`,'info')}} className="text-xs text-blue-400 hover:text-blue-300">Kujto</button>
                </div>
              </div>
            ))}
          </div>}
        </div>
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <h3 className="font-display font-700 text-white">Të gjitha transaksionet</h3>
          <div className="search-input w-56">
            <Search size={13}/>
            <input placeholder="Kërko kandidat, faturë..." value={search} onChange={e=>setSearch(e.target.value)}/>
            {search&&<button onClick={()=>setSearch('')} className="text-white/30"><X size={11}/></button>}
          </div>
        </div>
        <div className="table-container">
          <table className="data-table">
            <thead><tr><th>Fatura</th><th>Kandidati</th><th>Shuma</th><th>Metoda</th><th>Lloji</th><th>Data</th><th>Veprime</th></tr></thead>
            <tbody>
              {filtered.length===0&&<tr><td colSpan={7} className="text-center py-10 text-white/30">Nuk u gjetën transaksione</td></tr>}
              {filtered.map(p=>(
                <tr key={p.id}>
                  <td className="font-mono text-xs text-blue-400">{p.invoice}</td>
                  <td className="font-medium text-white">{p.student}</td>
                  <td className="text-success font-semibold">€{p.amount}</td>
                  <td><span className={`badge ${MTYPE[p.method]||'badge-default'}`}>{METHOD[p.method]||p.method}</span></td>
                  <td className="text-white/60 text-xs">{PTYPE[p.type]||p.type}</td>
                  <td className="text-white/40 text-xs">{p.date}</td>
                  <td><div className="flex gap-1">
                    <button onClick={()=>printInv(p)} className="icon-btn w-7 h-7" title="Printo faturën"><Printer size={13}/></button>
                    <button onClick={()=>del(p)} className="icon-btn w-7 h-7 hover:text-error" title="Fshi"><Trash2 size={13}/></button>
                  </div></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {showModal&&<PayModal students={students} settings={settings} onClose={()=>setShowModal(false)} onSave={save}/>}
    </div>
  )
}
