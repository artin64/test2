import React, { useState } from 'react'
import { Search, Plus, Download, Edit2, Trash2, Eye, Phone, Mail, ChevronLeft, ChevronRight, X, Printer } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import { exportStudentsExcel, printStudentCard } from '../utils/exportUtils'
import clsx from 'clsx'

const CATEGORIES = ['Të gjitha', 'A', 'A1', 'B', 'BE', 'C', 'CE', 'D']
const STATUS_LABELS = { active: ['Aktiv', 'success'], pending: ['Në pritje', 'warning'], completed: ['Diplomuar', 'info'], suspended: ['Pezulluar', 'error'] }

function validate(form) {
  const e = {}
  if (!form.name?.trim()) e.name = 'Emri është i detyrueshëm'
  if (!form.phone?.trim()) e.phone = 'Telefoni është i detyrueshëm'
  if (form.personal && form.personal.length > 0 && form.personal.length !== 10) e.personal = 'Duhet të jetë 10 shifra'
  if (form.email && !/\S+@\S+\.\S+/.test(form.email)) e.email = 'Email i pavlefshëm'
  return e
}

function StudentModal({ student, onClose, onSave, instructorNames }) {
  const [form, setForm] = useState(student || { name:'',personal:'',dob:'',gender:'M',phone:'',email:'',address:'',category:'B',status:'active',instructor:'',hoursTotal:30,notes:'' })
  const [errors, setErrors] = useState({})
  const h = (k,v) => { setForm(f=>({...f,[k]:v})); setErrors(e=>({...e,[k]:''})) }
  const submit = () => { const errs=validate(form); if(Object.keys(errs).length){setErrors(errs);return}; onSave(form); onClose() }

  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal p-6 max-w-2xl" style={{maxHeight:'90vh',overflowY:'auto'}}>
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-display text-xl font-700 text-white">{student?'Edito Kandidatin':'Regjistro Kandidat të Ri'}</h2>
          <button onClick={onClose} className="icon-btn"><X size={16}/></button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2 flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Emri i plotë *</label>
            <input className={clsx('input',errors.name&&'border-error')} value={form.name} onChange={e=>h('name',e.target.value)} placeholder="p.sh. Arben Krasniqi"/>
            {errors.name&&<span className="text-xs text-error">{errors.name}</span>}
          </div>
          {[['personal','Numri personal','text','10 shifra'],['dob','Data e lindjes','date',''],['phone','Telefoni *','text','+383 44 000 000'],['email','Email','email','kandidati@email.com'],['address','Adresa','text','Qyteti, Rruga, Numri']].map(([k,l,t,ph])=>(
            <div key={k} className={clsx('flex flex-col gap-1.5',k==='address'&&'col-span-2')}>
              <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">{l}</label>
              <input type={t} className={clsx('input',errors[k]&&'border-error')} value={form[k]||''} onChange={e=>h(k,e.target.value)} placeholder={ph}/>
              {errors[k]&&<span className="text-xs text-error">{errors[k]}</span>}
            </div>
          ))}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Gjinia</label>
            <select className="select" value={form.gender} onChange={e=>h('gender',e.target.value)}><option value="M">Mashkull</option><option value="F">Femër</option></select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Kategoria</label>
            <select className="select" value={form.category} onChange={e=>h('category',e.target.value)}>{['A','A1','B','BE','C','CE','D'].map(c=><option key={c}>{c}</option>)}</select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Statusi</label>
            <select className="select" value={form.status} onChange={e=>h('status',e.target.value)}>
              <option value="active">Aktiv</option><option value="pending">Në pritje</option><option value="completed">Diplomuar</option><option value="suspended">Pezulluar</option>
            </select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Orë totale</label>
            <input type="number" className="input" value={form.hoursTotal} onChange={e=>h('hoursTotal',+e.target.value)} min={1} max={200}/>
          </div>
          <div className="col-span-2 flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Instruktori</label>
            <select className="select" value={form.instructor||''} onChange={e=>h('instructor',e.target.value)}>
              <option value="">Pa instruktor...</option>
              {instructorNames.map(n=><option key={n}>{n}</option>)}
            </select>
          </div>
          <div className="col-span-2 flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Shënime</label>
            <textarea className="input" style={{height:72,resize:'none',paddingTop:12}} value={form.notes||''} onChange={e=>h('notes',e.target.value)} placeholder="Shënime opsionale..."/>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-6">
          <button onClick={onClose} className="btn-secondary">Anulo</button>
          <button onClick={submit} className="btn-primary">{student?'Ruaj ndryshimet':'Regjistro kandidatin'}</button>
        </div>
      </div>
    </div>
  )
}

function DetailModal({ student, onClose, onEdit }) {
  const toast = useToast()
  if(!student) return null
  const [label,type]=STATUS_LABELS[student.status]||['—','default']
  const prog=Math.round((student.hoursCompleted/student.hoursTotal)*100)
  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal p-6 max-w-lg" style={{maxHeight:'90vh',overflowY:'auto'}}>
        <div className="flex items-center justify-between mb-5">
          <h2 className="font-display text-xl font-700 text-white">Profili</h2>
          <button onClick={onClose} className="icon-btn"><X size={16}/></button>
        </div>
        <div className="flex items-center gap-4 mb-5">
          <div className="avatar w-14 h-14 text-base">{student.avatar}</div>
          <div>
            <div className="text-lg font-semibold text-white">{student.name}</div>
            <div className="text-sm text-white/40">Kat. {student.category} · {student.instructor||'Pa instruktor'}</div>
            <span className={`badge badge-${type} mt-1`}>{label}</span>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 mb-4">
          {[['Nr. Personal',student.personal||'—'],['Lindur',student.dob||'—'],['Gjinia',student.gender==='M'?'Mashkull':'Femër'],['Regjistruar',student.enrolled||'—']].map(([k,v])=>(
            <div key={k} className="p-3 rounded-xl" style={{background:'rgba(255,255,255,0.03)'}}><div className="text-xs text-white/30 mb-1">{k}</div><div className="text-sm font-medium text-white">{v}</div></div>
          ))}
        </div>
        <div className="flex flex-col gap-1.5 mb-4">
          <div className="flex items-center gap-2 text-sm text-white/60"><Phone size={13}/>{student.phone}</div>
          {student.email&&<div className="flex items-center gap-2 text-sm text-white/60"><Mail size={13}/>{student.email}</div>}
        </div>
        <div className="mb-4">
          <div className="flex justify-between text-sm mb-1.5"><span className="text-white/50">Progresi</span><span className="text-white font-semibold">{student.hoursCompleted}/{student.hoursTotal}h ({prog}%)</span></div>
          <div className="progress-bar"><div className="progress-fill" style={{width:`${prog}%`}}/></div>
        </div>
        <div className="grid grid-cols-2 gap-2 mb-4">
          <div className="p-3 rounded-xl text-center" style={{background:'rgba(16,185,129,0.08)'}}><div className="text-success font-semibold text-lg">€{student.payments}</div><div className="text-xs text-white/40">Paguar</div></div>
          <div className="p-3 rounded-xl text-center" style={{background:student.debt>0?'rgba(239,68,68,0.08)':'rgba(16,185,129,0.05)'}}><div className={clsx('font-semibold text-lg',student.debt>0?'text-error':'text-success')}>€{student.debt}</div><div className="text-xs text-white/40">Borxhi</div></div>
        </div>
        {student.notes&&<div className="mb-4 p-3 rounded-xl text-sm text-warning/80" style={{background:'rgba(245,158,11,0.08)'}}>{student.notes}</div>}
        <div className="flex gap-2 mt-4">
          <button onClick={()=>{printStudentCard(student);toast('Karta u dërgua për printim','success')}} className="btn-secondary flex-1 text-xs py-2"><Printer size={13}/>Printo</button>
          <button onClick={onClose} className="btn-secondary flex-1 text-xs py-2">Mbyll</button>
          <button onClick={()=>{onClose();onEdit(student)}} className="btn-primary flex-1 text-xs py-2"><Edit2 size={13}/>Edito</button>
        </div>
      </div>
    </div>
  )
}

export default function Students() {
  const {store}=useApp(); const toast=useToast()
  const {students,instructors,addStudent,updateStudent,deleteStudent}=store
  const [search,setSearch]=useState('')
  const [catF,setCatF]=useState('Të gjitha')
  const [statF,setStatF]=useState('Të gjitha')
  const [modal,setModal]=useState(null)
  const [sel,setSel]=useState(null)
  const [page,setPage]=useState(1)
  const PER=8
  const inames=instructors.filter(i=>i.status==='active').map(i=>i.name)
  const filtered=students.filter(s=>{
    const ms=s.name.toLowerCase().includes(search.toLowerCase())||(s.phone||'').includes(search)||(s.personal||'').includes(search)||(s.email||'').toLowerCase().includes(search.toLowerCase())
    return ms&&(catF==='Të gjitha'||s.category===catF)&&(statF==='Të gjitha'||s.status===statF)
  })
  const totalP=Math.max(1,Math.ceil(filtered.length/PER))
  const paged=filtered.slice((page-1)*PER,page*PER)

  const save=(form)=>{
    if(sel){updateStudent(sel.id,form);toast(`${form.name} u përditësua`,'success')}
    else{addStudent({...form,enrolled:new Date().toISOString().split('T')[0]});toast(`${form.name} u regjistrua`,'success')}
    setModal(null);setSel(null)
  }
  const del=(s)=>{
    if(!confirm(`Fshi ${s.name}?`))return
    deleteStudent(s.id);toast(`${s.name} u fshi`,'warning')
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Kandidatët</h1><p className="text-sm text-white/40 mt-0.5">{filtered.length} rezultate · {students.length} gjithsej</p></div>
        <div className="flex gap-2">
          <button onClick={()=>{exportStudentsExcel(filtered);toast(`${filtered.length} kandidatë u eksportuan`,'success')}} className="btn-secondary"><Download size={15}/>Excel</button>
          <button onClick={()=>{setSel(null);setModal('add')}} className="btn-primary"><Plus size={15}/>Kandidat i ri</button>
        </div>
      </div>
      <div className="grid grid-cols-4 gap-4">
        {[['Gjithsej',students.length,'#2563EB'],['Aktiv',students.filter(s=>s.status==='active').length,'#10B981'],['Diplomuar',students.filter(s=>s.status==='completed').length,'#06B6D4'],['Borxhe total',`€${students.reduce((a,s)=>a+(s.debt||0),0)}`,'#EF4444']].map(([l,v,c],i)=>(
          <div key={i} className="stat-card"><div className="font-display text-2xl font-700 text-white">{v}</div><div className="text-sm text-white/50">{l}</div></div>
        ))}
      </div>
      <div className="card p-4 flex flex-wrap items-center gap-3">
        <div className="search-input flex-1 min-w-48"><Search size={14}/><input placeholder="Kërko emër, telefon, email..." value={search} onChange={e=>{setSearch(e.target.value);setPage(1)}}/>{search&&<button onClick={()=>setSearch('')} className="text-white/30"><X size={12}/></button>}</div>
        <select className="select text-xs" style={{height:40,width:'auto',padding:'0 12px'}} value={catF} onChange={e=>{setCatF(e.target.value);setPage(1)}}>{CATEGORIES.map(c=><option key={c}>{c}</option>)}</select>
        <select className="select text-xs" style={{height:40,width:'auto',padding:'0 12px'}} value={statF} onChange={e=>{setStatF(e.target.value);setPage(1)}}>
          <option value="Të gjitha">Të gjitha</option><option value="active">Aktiv</option><option value="pending">Në pritje</option><option value="completed">Diplomuar</option><option value="suspended">Pezulluar</option>
        </select>
      </div>
      <div className="table-container">
        <table className="data-table">
          <thead><tr><th>Kandidati</th><th>Kontakti</th><th>Kat.</th><th>Progresi</th><th>Instruktori</th><th>Financat</th><th>Statusi</th><th></th></tr></thead>
          <tbody>
            {paged.length===0&&<tr><td colSpan={8} className="text-center py-10 text-white/30">Nuk u gjet asnjë kandidat</td></tr>}
            {paged.map(s=>{
              const [lbl,typ]=STATUS_LABELS[s.status]||['—','default']
              const prog=Math.round((s.hoursCompleted/s.hoursTotal)*100)
              return (
                <tr key={s.id} className="cursor-pointer" onClick={()=>{setSel(s);setModal('view')}}>
                  <td><div className="flex items-center gap-3"><div className="avatar w-8 h-8 text-xs flex-shrink-0">{s.avatar}</div><div><div className="font-semibold text-white">{s.name}</div><div className="text-xs text-white/30">{s.personal||'—'}</div></div></div></td>
                  <td onClick={e=>e.stopPropagation()}><div className="text-xs"><div className="text-white/70">{s.phone}</div><div className="text-white/30">{s.email}</div></div></td>
                  <td><span className="badge badge-info">Kat. {s.category}</span></td>
                  <td><div className="w-24"><div className="flex justify-between text-xs mb-1"><span className="text-white/40">{s.hoursCompleted}h</span><span className="text-white/40">{prog}%</span></div><div className="progress-bar"><div className="progress-fill" style={{width:`${prog}%`}}/></div></div></td>
                  <td className="text-white/60 text-xs">{s.instructor||'—'}</td>
                  <td><div className="text-xs"><div className="text-success font-semibold">€{s.payments}</div>{s.debt>0&&<div className="text-error">€{s.debt} borxh</div>}</div></td>
                  <td><span className={`badge badge-${typ}`}>{lbl}</span></td>
                  <td onClick={e=>e.stopPropagation()}><div className="flex items-center gap-1">
                    <button onClick={()=>{setSel(s);setModal('view')}} className="icon-btn w-7 h-7"><Eye size={13}/></button>
                    <button onClick={()=>{setSel(s);setModal('edit')}} className="icon-btn w-7 h-7"><Edit2 size={13}/></button>
                    <button onClick={()=>del(s)} className="icon-btn w-7 h-7 hover:text-error"><Trash2 size={13}/></button>
                  </div></td>
                </tr>
              )
            })}
          </tbody>
        </table>
        <div className="flex items-center justify-between px-4 py-3 border-t border-white/05">
          <span className="text-xs text-white/30">{filtered.length} total · faqja {page}/{totalP}</span>
          <div className="flex items-center gap-1">
            <button onClick={()=>setPage(p=>Math.max(1,p-1))} disabled={page===1} className="icon-btn w-7 h-7 disabled:opacity-30"><ChevronLeft size={14}/></button>
            {Array.from({length:Math.min(totalP,5)},(_,i)=>i+1).map(p=>(
              <button key={p} onClick={()=>setPage(p)} className={clsx('w-7 h-7 rounded-lg text-xs font-semibold transition-all',p===page?'bg-blue-600 text-white':'icon-btn')}>{p}</button>
            ))}
            <button onClick={()=>setPage(p=>Math.min(totalP,p+1))} disabled={page===totalP} className="icon-btn w-7 h-7 disabled:opacity-30"><ChevronRight size={14}/></button>
          </div>
        </div>
      </div>
      {(modal==='add'||modal==='edit')&&<StudentModal student={modal==='edit'?sel:null} instructorNames={inames} onClose={()=>{setModal(null);setSel(null)}} onSave={save}/>}
      {modal==='view'&&<DetailModal student={sel} onClose={()=>{setModal(null);setSel(null)}} onEdit={s=>{setSel(s);setModal('edit')}}/>}
    </div>
  )
}
