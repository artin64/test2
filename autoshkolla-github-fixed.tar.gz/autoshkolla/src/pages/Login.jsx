import React, { useState } from 'react'
import { Car, Eye, EyeOff, Lock, Mail, AlertCircle } from 'lucide-react'

export default function Login({ onLogin }) {
  const [email, setEmail] = useState('admin@autoshkolla.com')
  const [password, setPassword] = useState('admin123')
  const [showPass, setShowPass] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    setTimeout(() => {
      if (email === 'admin@autoshkolla.com' && password === 'admin123') {
        onLogin()
      } else {
        setError('Email ose fjalëkalimi është i gabuar.')
        setLoading(false)
      }
    }, 800)
  }

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden" style={{ background: '#020617' }}>
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #2563EB 0%, transparent 70%)' }} />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full opacity-10" style={{ background: 'radial-gradient(circle, #06B6D4 0%, transparent 70%)' }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full opacity-5" style={{ background: 'radial-gradient(circle, #2563EB 0%, transparent 60%)' }} />
      </div>

      <div className="relative w-full max-w-md px-6">
        {/* Logo */}
        <div className="flex flex-col items-center mb-10">
          <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4" style={{ background: 'linear-gradient(135deg, #2563EB, #06B6D4)', boxShadow: '0 0 40px rgba(37,99,235,0.3)' }}>
            <Car size={26} color="white" />
          </div>
          <div className="font-display text-3xl font-700 text-white">AutoShkolla Pro</div>
          <div className="text-white/30 text-sm mt-1 uppercase tracking-widest">Sistem Profesional</div>
        </div>

        {/* Card */}
        <div className="card p-8">
          <h2 className="font-display text-xl font-700 text-white mb-1">Mirë se vini</h2>
          <p className="text-sm text-white/40 mb-6">Hyni në panelin e menaxhimit</p>

          {error && (
            <div className="flex items-center gap-2 p-3 rounded-xl mb-4 text-sm text-error" style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)' }}>
              <AlertCircle size={15} />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Email</label>
              <div className="relative">
                <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/25" />
                <input
                  type="email"
                  className="input pl-10"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="email@autoshkolla.com"
                  required
                />
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Fjalëkalimi</label>
                <button type="button" className="text-xs text-blue-400 hover:text-blue-300 transition-colors">Harruat fjalëkalimin?</button>
              </div>
              <div className="relative">
                <Lock size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/25" />
                <input
                  type={showPass ? 'text' : 'password'}
                  className="input pl-10 pr-10"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Fjalëkalimi"
                  required
                />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-white/25 hover:text-white/60 transition-colors">
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading}
              className="btn-primary w-full justify-center py-3 text-base mt-2 disabled:opacity-70"
            >
              {loading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Duke hyrë...
                </div>
              ) : 'Hyr në sistem'}
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-white/05 text-center">
            <p className="text-xs text-white/20">Demo: admin@autoshkolla.com / admin123</p>
          </div>
        </div>

        <div className="text-center mt-6 text-xs text-white/20">
          AutoShkolla Pro v1.0.0 · © 2024 Të gjitha të drejtat e rezervuara
        </div>
      </div>
    </div>
  )
}
