import React, { useState } from 'react'
import { Building2, Plus, Users, Car, UserCheck, TrendingUp, MapPin, Phone, Mail, Edit2, Trash2, X } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import clsx from 'clsx'

function Modal({ b, onClose, onSave }) {
  const [f, setF] = useState(b||{name:'',city:'',address:'',phone:'',email:'',manager:'',status:'active'})
  const [errs, setErrs] = useState({})
  const h=(k,v)=>{setF(p=>({...p,[k]:v}));setErrs(e=>({...e,[k]:''})) }
  const submit=()=>{
    const e={}; if(!f.name?.trim())e.name='Emri është i detyrueshëm'
    if(Object.keys(e).length){setErrs(e);return}; onSave(f); onClose()
  }
  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal p-6">
        <div className="flex items-center justify-between mb-5"><h2 className="font-display text-xl font-700 text-white">{b?'Edito Degën':'Shto Degë të Re'}</h2><button onClick={onClose} className="icon-btn"><X size={16}/></button></div>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2 flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Emri i degës *</label>
            <input className={clsx('input',errs.name&&'border-error')} value={f.name} onChange={e=>h('name',e.target.value)} placeholder="p.sh. Dega Ferizaj"/>
            {errs.name&&<span className="text-xs text-error">{errs.name}</span>}
          </div>
          {[['city','Qyteti','text','Ferizaj'],['address','Adresa','text','Rruga, Numri'],['phone','Telefoni','text','+383 29 000 000'],['email','Email','email','dega@autoshkolla.com'],['manager','Menaxheri','text','Emri Mbiemri']].map(([k,l,t,ph])=>(
            <div key={k} className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">{l}</label>
              <input type={t} className="input" value={f[k]||''} onChange={e=>h(k,e.target.value)} placeholder={ph}/>
            </div>
          ))}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Statusi</label>
            <select className="select" value={f.status} onChange={e=>h('status',e.target.value)}><option value="active">Aktiv</option><option value="inactive">Joaktiv</option></select>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-5"><button onClick={onClose} className="btn-secondary">Anulo</button><button onClick={submit} className="btn-primary">{b?'Ruaj':'Shto degën'}</button></div>
      </div>
    </div>
  )
}

export default function Branches() {
  const { store } = useApp(); const toast = useToast()
  const { branches, addBranch, updateBranch, deleteBranch } = store
  const [modal, setModal] = useState(null); const [sel, setSel] = useState(null)
  const totals = { students:branches.reduce((a,b)=>a+b.students,0), instructors:branches.reduce((a,b)=>a+b.instructors,0), vehicles:branches.reduce((a,b)=>a+b.vehicles,0), revenue:branches.reduce((a,b)=>a+b.revenue,0) }

  const save=f=>{
    if(sel){updateBranch(sel.id,f);toast(`${f.name} u përditësua`,'success')}
    else{addBranch(f);toast(`${f.name} u shtua me sukses`,'success')}
    setModal(null);setSel(null)
  }
  const del=b=>{
    if(!confirm(`Fshi degën "${b.name}"?`))return
    deleteBranch(b.id);toast('Dega u fshi','warning')
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Menaxhimi i Degëve</h1><p className="text-sm text-white/40 mt-0.5">{branches.length} degë · {branches.filter(b=>b.status==='active').length} aktive</p></div>
        <button onClick={()=>{setSel(null);setModal('form')}} className="btn-primary"><Plus size={15}/>Shto degë të re</button>
      </div>

      <div className="card" style={{background:'linear-gradient(135deg,#0B1220,#1E293B)'}}>
        <h3 className="font-display font-700 text-white mb-4">Rrjeti total — të gjitha degët</h3>
        <div className="grid grid-cols-4 gap-4">
          {[['Kandidatë',totals.students,Users,'#2563EB'],['Instruktorë',totals.instructors,UserCheck,'#10B981'],['Vetura',totals.vehicles,Car,'#06B6D4'],['Të ardhura',`€${totals.revenue.toLocaleString()}`,TrendingUp,'#F59E0B']].map(([l,v,Icon,c])=>(
            <div key={l} className="text-center">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center mx-auto mb-2" style={{background:`${c}20`,color:c}}><Icon size={18}/></div>
              <div className="font-display text-xl font-700 text-white">{v}</div>
              <div className="text-xs text-white/40 mt-0.5">{l}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex flex-col gap-4">
        {branches.map(b=>(
          <div key={b.id} className="card">
            <div className="flex items-start justify-between flex-wrap gap-4 mb-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-600/15 flex items-center justify-center flex-shrink-0"><Building2 size={22} color="#2563EB"/></div>
                <div>
                  <div className="font-display text-lg font-700 text-white">{b.name}</div>
                  <div className="flex items-center gap-1.5 text-xs text-white/40 mt-1"><MapPin size={10}/>{b.address}, {b.city}</div>
                  <div className="flex items-center gap-3 text-xs text-white/30 mt-1">
                    {b.phone&&<span className="flex items-center gap-1"><Phone size={10}/>{b.phone}</span>}
                    {b.email&&<span className="flex items-center gap-1"><Mail size={10}/>{b.email}</span>}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={clsx('badge',b.status==='active'?'badge-success':'badge-error')}>{b.status==='active'?'Aktiv':'Joaktiv'}</span>
                <button onClick={()=>{setSel(b);setModal('form')}} className="btn-secondary text-xs py-2 px-3"><Edit2 size={13}/>Edito</button>
                <button onClick={()=>del(b)} className="btn-danger text-xs py-2 px-3"><Trash2 size={13}/></button>
              </div>
            </div>
            <div className="grid grid-cols-4 gap-3 mb-3">
              {[['Kandidatë',b.students,Users,'#2563EB'],['Instruktorë',b.instructors,UserCheck,'#10B981'],['Vetura',b.vehicles,Car,'#06B6D4'],['Të ardhura',`€${b.revenue.toLocaleString()}`,TrendingUp,'#F59E0B']].map(([l,v,Icon,c])=>(
                <div key={l} className="p-3 rounded-xl text-center" style={{background:'rgba(255,255,255,0.03)'}}>
                  <Icon size={14} className="mx-auto mb-1" style={{color:c}}/>
                  <div className="font-display text-lg font-700 text-white">{v}</div>
                  <div className="text-xs text-white/30">{l}</div>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between pt-3 border-t border-white/05">
              <div className="text-xs text-white/30">Menaxher: <span className="text-white/60 font-medium">{b.manager||'—'}</span></div>
            </div>
          </div>
        ))}
        {branches.length===0&&<div className="card text-center py-12 text-white/30">Nuk ka degë. Shto degën e parë.</div>}
      </div>
      {modal==='form'&&<Modal b={sel} onClose={()=>{setModal(null);setSel(null)}} onSave={save}/>}
    </div>
  )
}
