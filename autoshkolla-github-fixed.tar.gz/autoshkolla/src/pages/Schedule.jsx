import React, { useState } from 'react'
import { Plus, ChevronLeft, ChevronRight, Clock, MapPin, User, Car, Trash2, X, Download } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import { exportScheduleExcel } from '../utils/exportUtils'
import clsx from 'clsx'

const HOURS = ['08:00','09:00','10:00','10:30','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00']
const DAYS_SQ = ['E Hënë','E Martë','E Mërkurë','E Enjte','E Premte','E Shtunë','E Diel']
const STYPE = { confirmed:{bg:'rgba(37,99,235,0.15)',border:'rgba(37,99,235,0.3)',text:'#93C5FD',lbl:'Konfirmuar'}, pending:{bg:'rgba(245,158,11,0.12)',border:'rgba(245,158,11,0.3)',text:'#FCD34D',lbl:'Në pritje'}, 'exam-theory':{bg:'rgba(139,92,246,0.15)',border:'rgba(139,92,246,0.3)',text:'#C4B5FD',lbl:'Provim teorik'}, cancelled:{bg:'rgba(239,68,68,0.1)',border:'rgba(239,68,68,0.2)',text:'#FCA5A5',lbl:'Anuluar'} }

function BookingModal({ onClose, onSave, students, instructors, vehicles }) {
  const [f, setF] = useState({ student:'',instructor:'',vehicle:'',date:'',time:'09:00',duration:90,location:'',type:'practical',status:'confirmed' })
  const [errs, setErrs] = useState({})
  const h = (k,v) => { setF(p=>({...p,[k]:v})); setErrs(e=>({...e,[k]:''})) }
  const submit = () => {
    const e = {}
    if (!f.student) e.student = 'Zgjedh kandidatin'
    if (!f.date) e.date = 'Data është e detyrueshme'
    if (Object.keys(e).length) { setErrs(e); return }
    onSave(f); onClose()
  }
  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal p-6" style={{maxHeight:'90vh',overflowY:'auto'}}>
        <div className="flex items-center justify-between mb-5"><h2 className="font-display text-xl font-700 text-white">Rezervo Orë Vozitjeje</h2><button onClick={onClose} className="icon-btn"><X size={16}/></button></div>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2 flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Kandidati *</label>
            <select className={clsx('select',errs.student&&'border-error')} value={f.student} onChange={e=>h('student',e.target.value)}>
              <option value="">Zgjidh kandidatin...</option>
              {students.map(s=><option key={s.id}>{s.name}</option>)}
            </select>
            {errs.student&&<span className="text-xs text-error">{errs.student}</span>}
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Instruktori</label>
            <select className="select" value={f.instructor||''} onChange={e=>h('instructor',e.target.value)}>
              <option value="">Zgjidh instruktorin...</option>
              {instructors.filter(i=>i.status==='active').map(i=><option key={i.id}>{i.name}</option>)}
            </select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Vetura</label>
            <select className="select" value={f.vehicle||''} onChange={e=>h('vehicle',e.target.value)}>
              <option value="">Zgjidh veturën...</option>
              {vehicles.filter(v=>v.status==='active').map(v=><option key={v.id}>{v.brand} {v.model}</option>)}
            </select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Data *</label>
            <input type="date" className={clsx('input',errs.date&&'border-error')} value={f.date} onChange={e=>h('date',e.target.value)} min={new Date().toISOString().split('T')[0]}/>
            {errs.date&&<span className="text-xs text-error">{errs.date}</span>}
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Ora</label>
            <select className="select" value={f.time} onChange={e=>h('time',e.target.value)}>{HOURS.map(h=><option key={h}>{h}</option>)}</select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Kohëzgjatja</label>
            <select className="select" value={f.duration} onChange={e=>h('duration',+e.target.value)}>{[45,60,90,120].map(d=><option key={d} value={d}>{d} minuta</option>)}</select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Lloji</label>
            <select className="select" value={f.type} onChange={e=>h('type',e.target.value)}>
              <option value="practical">Orë praktike</option>
              <option value="exam-theory">Provim teorik</option>
              <option value="exam-practical">Provim praktik</option>
            </select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Statusi</label>
            <select className="select" value={f.status} onChange={e=>h('status',e.target.value)}>
              <option value="confirmed">Konfirmuar</option>
              <option value="pending">Në pritje</option>
            </select>
          </div>
          <div className="col-span-2 flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Lokacioni</label>
            <input className="input" value={f.location} onChange={e=>h('location',e.target.value)} placeholder="p.sh. Parku Industrial, Prishtinë"/>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-5"><button onClick={onClose} className="btn-secondary">Anulo</button><button onClick={submit} className="btn-primary">Rezervo orën</button></div>
      </div>
    </div>
  )
}

export default function Schedule() {
  const { store } = useApp(); const toast = useToast()
  const { schedules, students, instructors, vehicles, addSchedule, updateSchedule, deleteSchedule } = store
  const [view, setView] = useState('list')
  const [showModal, setShowModal] = useState(false)
  const [filterDate, setFilterDate] = useState('')

  const displayed = filterDate ? schedules.filter(s=>s.date===filterDate) : [...schedules].sort((a,b)=>a.date.localeCompare(b.date)||a.time.localeCompare(b.time))

  const save = f => { addSchedule(f); toast(`Ora u rezervua për ${f.student}`,'success') }
  const cancel = s => { if (!confirm('Anulo orën?')) return; deleteSchedule(s.id); toast('Ora u anulua','warning') }
  const toggleStatus = s => {
    const next = s.status==='confirmed'?'pending':'confirmed'
    updateSchedule(s.id,{status:next})
    toast(`Statusi u ndryshua: ${next==='confirmed'?'Konfirmuar':'Në pritje'}`,'info')
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Oraret e Vozitjes</h1><p className="text-sm text-white/40 mt-0.5">{schedules.length} orë gjithsej</p></div>
        <div className="flex items-center gap-2 flex-wrap">
          <input type="date" className="input text-xs" style={{height:38,width:'auto',padding:'0 12px'}} value={filterDate} onChange={e=>setFilterDate(e.target.value)} title="Filtro sipas datës"/>
          {filterDate&&<button onClick={()=>setFilterDate('')} className="text-xs text-white/40 hover:text-white/70">✕ Pastro</button>}
          <div className="flex rounded-xl overflow-hidden border border-white/08">
            {[['list','Listë'],['today','Sot']].map(([v,l])=>(
              <button key={v} onClick={()=>setView(v)} className={clsx('px-4 py-2 text-xs font-semibold transition-all',view===v?'bg-blue-600 text-white':'text-white/40 hover:text-white/70')}>{l}</button>
            ))}
          </div>
          <button onClick={()=>{exportScheduleExcel(displayed);toast('Oraret u eksportuan','success')}} className="btn-secondary text-xs py-2"><Download size={14}/>Excel</button>
          <button onClick={()=>setShowModal(true)} className="btn-primary"><Plus size={15}/>Rezervo orë</button>
        </div>
      </div>

      {/* Today summary */}
      {view==='today'&&(
        <div className="flex gap-3 overflow-x-auto pb-1">
          {schedules.filter(s=>s.date===new Date().toISOString().split('T')[0]).map(s=>{
            const st=STYPE[s.status]||STYPE.confirmed
            return <div key={s.id} className="flex-shrink-0 p-4 rounded-xl w-52" style={{background:st.bg,border:`1px solid ${st.border}`}}>
              <div className="text-lg font-display font-700" style={{color:st.text}}>{s.time}</div>
              <div className="text-white font-semibold text-sm mt-1">{s.student}</div>
              <div className="text-white/50 text-xs mt-0.5">{s.instructor||'—'}</div>
              <div className="text-white/30 text-xs mt-2">{s.duration}min · {s.location||'—'}</div>
            </div>
          })}
          {schedules.filter(s=>s.date===new Date().toISOString().split('T')[0]).length===0&&<div className="card py-8 text-center text-white/30 text-sm w-full">Nuk ka orare sot</div>}
        </div>
      )}

      {/* Table */}
      <div className="table-container">
        <table className="data-table">
          <thead><tr><th>Data & Ora</th><th>Kandidati</th><th>Instruktori</th><th>Vetura</th><th>Lokacioni</th><th>Lloji</th><th>Statusi</th><th></th></tr></thead>
          <tbody>
            {displayed.length===0&&<tr><td colSpan={8} className="text-center py-10 text-white/30">Nuk ka orare</td></tr>}
            {displayed.map(s=>{
              const st=STYPE[s.status]||STYPE.confirmed
              const typeLbl={practical:'Praktike','exam-theory':'Provim teorik','exam-practical':'Provim praktik'}[s.type]||s.type
              return (
                <tr key={s.id}>
                  <td><div className="font-semibold text-white">{s.date}</div><div className="text-xs text-white/40 flex items-center gap-1 mt-0.5"><Clock size={10}/>{s.time} · {s.duration}min</div></td>
                  <td><div className="flex items-center gap-2"><User size={13} className="text-white/30"/><span className="text-white text-sm">{s.student}</span></div></td>
                  <td className="text-white/60 text-sm">{s.instructor||'—'}</td>
                  <td><div className="flex items-center gap-1 text-white/50 text-xs"><Car size={11}/>{s.vehicle||'—'}</div></td>
                  <td><div className="flex items-center gap-1 text-white/40 text-xs"><MapPin size={10}/>{s.location||'—'}</div></td>
                  <td><span className="badge badge-default text-xs">{typeLbl}</span></td>
                  <td><button onClick={()=>toggleStatus(s)} className="badge text-xs cursor-pointer hover:opacity-80 transition-opacity" style={{background:st.bg,color:st.text,border:`1px solid ${st.border}`}}>{st.lbl}</button></td>
                  <td><button onClick={()=>cancel(s)} className="icon-btn w-7 h-7 hover:text-error" title="Anulo orën"><Trash2 size={13}/></button></td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {showModal&&<BookingModal onClose={()=>setShowModal(false)} onSave={save} students={students} instructors={instructors} vehicles={vehicles}/>}
    </div>
  )
}
