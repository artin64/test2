import React, { useState } from 'react'
import { Download, Printer } from 'lucide-react'
import { AreaChart, Area, BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import { exportReportExcel, printReport } from '../utils/exportUtils'
import clsx from 'clsx'

const mRev=[{month:'Tet',rev:4200,exp:1800},{month:'Nën',rev:5100,exp:2100},{month:'Dhj',rev:4800,exp:1900},{month:'Jan',rev:6200,exp:2400},{month:'Shk',rev:7100,exp:2600},{month:'Mar',rev:6800,exp:2500}]
const stuGrowth=[{month:'Tet',total:80,new:12},{month:'Nën',total:90,new:15},{month:'Dhj',total:95,new:10},{month:'Jan',total:110,new:18},{month:'Shk',total:130,new:22},{month:'Mar',total:148,new:20}]
const TT=({active,payload,label})=>active&&payload?.length?(<div className="card p-2.5 text-xs"><div className="text-white/50 mb-1">{label}</div>{payload.map((p,i)=><div key={i} className="flex justify-between gap-4 mt-0.5"><span className="text-white/50">{p.name}</span><span className="text-white font-semibold">{typeof p.value==='number'?`€${p.value.toLocaleString()}`:p.value}</span></div>)}</div>):null

export default function Reports() {
  const { store } = useApp(); const toast = useToast()
  const { students, payments, instructors, settings } = store
  const totalRev = payments.reduce((a,p)=>a+(+p.amount),0)
  const totalDebt = students.reduce((a,s)=>a+(s.debt||0),0)
  const passed = Math.round(students.filter(s=>s.status==='completed').length/Math.max(1,students.length)*100)

  const catPie = ['B','A','C','D'].map((c,i)=>({name:`Kat. ${c}`,value:students.filter(s=>s.category.startsWith(c)).length||0,color:['#2563EB','#06B6D4','#10B981','#F59E0B'][i]})).filter(x=>x.value>0)
  const insPerf = instructors.map(i=>({name:i.name.split(' ')[0],rate:Math.floor(75+Math.random()*20)}))

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Raporte & Analitika</h1><p className="text-sm text-white/40 mt-0.5">Pasqyrë e plotë e performancës</p></div>
        <div className="flex gap-2">
          <button onClick={()=>{printReport(students,payments,instructors,settings);toast('Raporti u hap për printim','info')}} className="btn-secondary"><Printer size={15}/>Printo PDF</button>
          <button onClick={()=>{exportReportExcel(students,payments,instructors);toast('Raporti u eksportua si Excel','success')}} className="btn-secondary"><Download size={15}/>Excel</button>
        </div>
      </div>

      <div className="stats-grid">
        {[['Të ardhura totale',`€${totalRev.toLocaleString()}`,'#10B981','+18%'],['Kandidatë',students.length,'#2563EB','+12%'],['Borxhe',`€${totalDebt}`,'#EF4444','-5%'],['Diplomuar',`${passed}%`,'#06B6D4','+3%']].map(([l,v,c,t],i)=>(
          <div key={i} className="stat-card">
            <div className="flex items-center justify-between">
              <div className="font-display text-2xl font-700 text-white">{v}</div>
              <span className={clsx('text-xs font-semibold',t.startsWith('+')?'text-success':'text-error')}>{t}</span>
            </div>
            <div className="text-sm text-white/50">{l}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <h3 className="font-display font-700 text-white mb-1">Të ardhurat vs Shpenzimet</h3>
        <p className="text-xs text-white/30 mb-4">6 muajt e fundit · Profit neto: €{mRev.reduce((a,m)=>a+m.rev-m.exp,0).toLocaleString()}</p>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={mRev} margin={{left:-20,right:0,top:0,bottom:0}}>
            <defs>
              <linearGradient id="rg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#2563EB" stopOpacity={0.3}/><stop offset="95%" stopColor="#2563EB" stopOpacity={0}/></linearGradient>
              <linearGradient id="eg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#EF4444" stopOpacity={0.2}/><stop offset="95%" stopColor="#EF4444" stopOpacity={0}/></linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)"/>
            <XAxis dataKey="month" tick={{fill:'rgba(255,255,255,0.3)',fontSize:11}} axisLine={false} tickLine={false}/>
            <YAxis tick={{fill:'rgba(255,255,255,0.3)',fontSize:11}} axisLine={false} tickLine={false}/>
            <Tooltip content={<TT/>}/><Legend wrapperStyle={{fontSize:12,color:'rgba(255,255,255,0.4)'}}/>
            <Area type="monotone" dataKey="rev" name="Të ardhura" stroke="#2563EB" strokeWidth={2} fill="url(#rg)"/>
            <Area type="monotone" dataKey="exp" name="Shpenzime" stroke="#EF4444" strokeWidth={2} fill="url(#eg)"/>
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="grid-2">
        <div className="card">
          <h3 className="font-display font-700 text-white mb-4">Rritja e kandidatëve</h3>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={stuGrowth} margin={{left:-20,right:0,top:0,bottom:0}}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)"/>
              <XAxis dataKey="month" tick={{fill:'rgba(255,255,255,0.3)',fontSize:11}} axisLine={false} tickLine={false}/>
              <YAxis tick={{fill:'rgba(255,255,255,0.3)',fontSize:11}} axisLine={false} tickLine={false}/>
              <Tooltip content={<TT/>}/>
              <Line type="monotone" dataKey="total" name="Total" stroke="#2563EB" strokeWidth={2} dot={{fill:'#2563EB',r:3}}/>
              <Line type="monotone" dataKey="new" name="Të rinj" stroke="#06B6D4" strokeWidth={2} dot={{fill:'#06B6D4',r:3}} strokeDasharray="5 5"/>
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <h3 className="font-display font-700 text-white mb-4">Kategorite</h3>
          <div className="flex items-center gap-4">
            <ResponsiveContainer width={110} height={110}>
              <PieChart><Pie data={catPie.length?catPie:[{name:'—',value:1,color:'#1E293B'}]} innerRadius={32} outerRadius={50} paddingAngle={3} dataKey="value">
                {(catPie.length?catPie:[{color:'#1E293B'}]).map((e,i)=><Cell key={i} fill={e.color}/>)}
              </Pie></PieChart>
            </ResponsiveContainer>
            <div className="flex flex-col gap-2 flex-1">
              {catPie.map((c,i)=>(
                <div key={i} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full" style={{background:c.color}}/><span className="text-white/50">{c.name}</span></div>
                  <span className="text-white font-semibold">{c.value}</span>
                </div>
              ))}
              {catPie.length===0&&<div className="text-xs text-white/30">Pa të dhëna</div>}
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <h3 className="font-display font-700 text-white mb-4">Performanca e instruktorëve</h3>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={insPerf} layout="vertical" margin={{left:0,right:20,top:0,bottom:0}}>
            <XAxis type="number" tick={{fill:'rgba(255,255,255,0.3)',fontSize:11}} axisLine={false} tickLine={false} domain={[0,100]}/>
            <YAxis dataKey="name" type="category" tick={{fill:'rgba(255,255,255,0.5)',fontSize:12}} axisLine={false} tickLine={false} width={70}/>
            <Tooltip cursor={{fill:'rgba(255,255,255,0.03)'}} contentStyle={{background:'#0F172A',border:'1px solid rgba(255,255,255,0.08)',borderRadius:12,fontSize:12}}/>
            <Bar dataKey="rate" name="Norma kalimi %" fill="#2563EB" radius={[0,6,6,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="table-container">
        <table className="data-table">
          <thead><tr><th>Kategoria</th><th>Kandidatë</th><th>Aktiv</th><th>Diplomuar</th><th>Progresi</th><th>Të ardhura</th></tr></thead>
          <tbody>
            {[['B',Math.round(students.length*0.6),Math.round(students.length*0.4),Math.round(students.length*0.15),'84%','€22,100'],['A/A1',Math.round(students.length*0.15),Math.round(students.length*0.1),Math.round(students.length*0.04),'88%','€6,400'],['C/CE',Math.round(students.length*0.1),Math.round(students.length*0.07),Math.round(students.length*0.02),'79%','€4,200']].map(([cat,tot,act,grad,rate,rev])=>(
              <tr key={cat}>
                <td><span className="badge badge-info">Kat. {cat}</span></td>
                <td className="text-white font-semibold">{tot}</td>
                <td className="text-success">{act}</td>
                <td className="text-blue-400">{grad}</td>
                <td><div className="flex items-center gap-2"><div className="progress-bar w-16 flex-shrink-0"><div className="progress-fill" style={{width:rate}}/></div><span className="text-white/50 text-xs">{rate}</span></div></td>
                <td className="text-white font-semibold">{rev}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
