import React, { useState, useEffect, useRef } from 'react'
import { Play, RotateCcw, CheckCircle, XCircle, Clock, Trophy, ChevronRight, ChevronLeft, ClipboardList } from 'lucide-react'
import clsx from 'clsx'

const ALL_Q = [
  { id:1, cat:'Rregullat', q:'Sa është shpejtësia maksimale në zonë urbane?', opts:['40 km/h','50 km/h','60 km/h','80 km/h'], c:1 },
  { id:2, cat:'Përparësia', q:'Kush ka përparësi në kryqëzim të parregulluar?', opts:['Nga e majta','Nga e djathta','Me shpejtësi më të madhe','I pari'], c:1 },
  { id:3, cat:'Siguria', q:'Sa metra para kthesës duhet të jepni sinjal?', opts:['10m','20m','30m','50m'], c:2 },
  { id:4, cat:'Rregullat', q:'Kur lejohet kalimi me dritë të verdhë?', opts:['Kurrë','Vetëm nëse rruga është e lirë','Gjithmonë','Vetëm natën'], c:1 },
  { id:5, cat:'Distancat', q:'Cila është distanca minimale e sigurisë në rrugë të thatë me 90 km/h?', opts:['2 sekonda','3 sekonda','4 sekonda','1 sekondë'], c:1 },
  { id:6, cat:'Shenjat', q:'Çfarë tregon shenja trekëndore me kufi të kuq?', opts:['Ndalesë','Paralajmërim','Urdhërim','Informacion'], c:1 },
  { id:7, cat:'Teknike', q:'Kur bllokosen rrotat gjatë frenimit, çfarë duhet të bëni?', opts:['Shtypni plotësisht','Lëshoni pak frerin','Ndizni sinjalin','Kthehuni'], c:1 },
  { id:8, cat:'Alkooli', q:'Cili është kufiri ligjor i alkoolit në gjak (shoferë rregullt)?', opts:['0.0 mg/ml','0.5 mg/ml','0.8 mg/ml','0.3 mg/ml'], c:0 },
  { id:9, cat:'Rregullat', q:'Sa orë max mund të drejtojë një shofer profesionist pa pushim?', opts:['3 orë','4 orë','4.5 orë','5 orë'], c:2 },
  { id:10, cat:'Siguria', q:'Kur është i detyrueshëm rripi i sigurimit?', opts:['Vetëm autostradat','Vetëm kur shkon shpejt','Gjithmonë','Vetëm natën'], c:2 },
  { id:11, cat:'Shenjat', q:'Vija e bardhë e ndërprerë në rrugë do të thotë?', opts:['Mos kalo','Mund të kalosh','Stop i detyrueshëm','Prioritet'], c:1 },
  { id:12, cat:'Rregullat', q:'Kur duhet të ndizni dritat e pozicionit?', opts:['Natën','Kur dukshmëria është nën 200m','Të dyja','Asnjëherë'], c:2 },
  { id:13, cat:'Parkimi', q:'Ku ndalohet parkimi absolutisht?', opts:['Pranë shkollave','Mbi trotuar','Tek ura','Të gjitha'], c:3 },
  { id:14, cat:'Emergjenca', q:'Çfarë duhet të bëni menjëherë pas aksidentit?', opts:['Lëvizni mjetin','Ndaloni dhe siguroni skenën','Telefononi vetëm policinë','Vazhdoni rrugën'], c:1 },
  { id:15, cat:'Teknike', q:'Kur duhet të ndizni dritat e mjegullës?', opts:['Çdoherë natën','Vetëm në mjegull të dendur','Në shi','Gjithmonë'], c:1 },
]

function shuffle(arr) {
  const a=[...arr]; for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}; return a
}

function Quiz({ onFinish }) {
  const [qs] = useState(() => shuffle(ALL_Q).slice(0, 10))
  const [cur, setCur] = useState(0)
  const [answers, setAnswers] = useState({})
  const [time, setTime] = useState(600)
  const [done, setDone] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    ref.current = setInterval(() => setTime(t => { if(t<=1){clearInterval(ref.current);setDone(true);return 0}; return t-1 }), 1000)
    return () => clearInterval(ref.current)
  }, [])

  const pick = (qi, ai) => { if(answers[qi]!==undefined) return; setAnswers(p=>({...p,[qi]:ai})) }
  const finish = () => { clearInterval(ref.current); setDone(true) }
  const correct = qs.filter((q,i)=>answers[i]===q.c).length
  const score = Math.round(correct/qs.length*100)
  const passed = score >= 70
  const mm=String(Math.floor(time/60)).padStart(2,'0'), ss=String(time%60).padStart(2,'0')

  if (done) return (
    <div className="flex flex-col items-center gap-5 py-6">
      <div className={clsx('w-20 h-20 rounded-full flex items-center justify-center', passed?'bg-success/15':'bg-error/15')}>
        {passed?<Trophy size={36} color="#10B981"/>:<XCircle size={36} color="#EF4444"/>}
      </div>
      <div className="text-center">
        <div className={clsx('font-display text-5xl font-700 mb-1', passed?'text-success':'text-error')}>{score}%</div>
        <div className="text-white text-lg font-semibold">{passed?'🎉 Kaluat testin!':'Provoni sërish!'}</div>
        <div className="text-white/40 text-sm mt-1">{correct}/{qs.length} përgjigje të sakta</div>
      </div>
      <div className="w-full max-w-lg flex flex-col gap-2">
        {qs.map((q,i)=>{
          const ua=answers[i], ok=ua===q.c, unans=ua===undefined
          return <div key={q.id} className={clsx('flex items-start gap-3 p-3 rounded-xl text-sm',unans?'bg-white/02':ok?'bg-success/06':'bg-error/06')}>
            {ok?<CheckCircle size={15} className="text-success mt-0.5 flex-shrink-0"/>:<XCircle size={15} className="text-error mt-0.5 flex-shrink-0"/>}
            <div className="flex-1">
              <div className="text-white/80 text-xs">{q.q}</div>
              {!ok&&!unans&&<div className="text-xs text-success mt-1">✓ {q.opts[q.c]}</div>}
              {!ok&&!unans&&<div className="text-xs text-error">✗ {q.opts[ua]}</div>}
            </div>
          </div>
        })}
      </div>
      <button onClick={onFinish} className="btn-primary"><RotateCcw size={15}/>Rifillo testin</button>
    </div>
  )

  const q = qs[cur]
  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <div className={clsx('flex items-center gap-2', time<120?'text-error':'text-white/60')}><Clock size={16}/><span className="font-display text-xl font-700 text-white">{mm}:{ss}</span></div>
        <div className="text-sm text-white/40">Pyetja {cur+1}/{qs.length}</div>
        <div className="text-sm text-white/40">{Object.keys(answers).length} të përgjigjena</div>
      </div>
      <div className="progress-bar"><div className="progress-fill" style={{width:`${Object.keys(answers).length/qs.length*100}%`}}/></div>
      <div className="flex gap-1.5 flex-wrap">
        {qs.map((_,i)=><button key={i} onClick={()=>setCur(i)} className={clsx('w-8 h-8 rounded-lg text-xs font-semibold transition-all',
          i===cur?'bg-blue-600 text-white':answers[i]!==undefined?answers[i]===qs[i].c?'bg-success/20 text-success':'bg-error/20 text-error':'bg-white/05 text-white/30 hover:bg-white/10'
        )}>{i+1}</button>)}
      </div>
      <div className="card">
        <span className="badge badge-info text-xs">{q.cat}</span>
        <h3 className="font-display text-lg font-600 text-white mt-3 mb-5 leading-snug">{q.q}</h3>
        <div className="flex flex-col gap-2">
          {q.opts.map((opt,oi)=>{
            const ua=answers[cur], isSel=ua===oi, isC=oi===q.c, ans=ua!==undefined
            return <button key={oi} onClick={()=>pick(cur,oi)} disabled={ans}
              className={clsx('flex items-center gap-3 p-4 rounded-xl text-left transition-all border text-sm font-medium',
                !ans&&'hover:border-blue-600/40 hover:bg-blue-600/05 cursor-pointer',
                ans&&isC&&'bg-success/10 border-success/30 text-success',
                ans&&isSel&&!isC&&'bg-error/10 border-error/30 text-error',
                !ans?'border-white/08 text-white/70 bg-white/02':(!isSel&&!isC)?'border-white/04 text-white/20 bg-transparent':''
              )}>
              <div className={clsx('w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0',ans&&isC?'bg-success/20':ans&&isSel&&!isC?'bg-error/20':'bg-white/08')}>
                {String.fromCharCode(65+oi)}
              </div>
              <span className="flex-1">{opt}</span>
              {ans&&isC&&<CheckCircle size={15} className="text-success flex-shrink-0"/>}
              {ans&&isSel&&!isC&&<XCircle size={15} className="text-error flex-shrink-0"/>}
            </button>
          })}
        </div>
      </div>
      <div className="flex items-center justify-between">
        <button onClick={()=>setCur(c=>Math.max(0,c-1))} disabled={cur===0} className="btn-secondary disabled:opacity-30"><ChevronLeft size={16}/>Prapa</button>
        {cur<qs.length-1?<button onClick={()=>setCur(c=>c+1)} className="btn-primary">Tjetër<ChevronRight size={16}/></button>
        :<button onClick={finish} className="btn-primary"><CheckCircle size={15}/>Përfundo</button>}
      </div>
    </div>
  )
}

export default function Tests() {
  const [mode, setMode] = useState('home')
  const [history] = useState([
    {date:'2024-03-10',score:87,correct:9,total:10,passed:true},
    {date:'2024-03-05',score:60,correct:6,total:10,passed:false},
    {date:'2024-02-28',score:90,correct:9,total:10,passed:true},
  ])

  if (mode==='quiz') return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-700 text-white">Test Online</h1>
        <button onClick={()=>setMode('home')} className="btn-secondary">Braktis testin</button>
      </div>
      <Quiz onFinish={()=>setMode('home')}/>
    </div>
  )

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Testet Teorike Online</h1><p className="text-sm text-white/40 mt-0.5">Simulim i provimit real — 10 pyetje, 10 minuta</p></div>
        <button onClick={()=>setMode('quiz')} className="btn-primary"><Play size={15}/>Fillo testin tani</button>
      </div>
      <div className="stats-grid">
        {[['Teste totale',history.length,'#2563EB'],['Të kaluara',history.filter(h=>h.passed).length,'#10B981'],['Norma kalimi',`${Math.round(history.filter(h=>h.passed).length/history.length*100)}%`,'#06B6D4'],['Rezultati max',`${Math.max(...history.map(h=>h.score))}%`,'#F59E0B']].map(([l,v,c],i)=>(
          <div key={i} className="stat-card"><div className="font-display text-2xl font-700 text-white">{v}</div><div className="text-sm text-white/50">{l}</div></div>
        ))}
      </div>
      <div className="card relative overflow-hidden" style={{background:'linear-gradient(135deg,#0B1220,#1E293B)'}}>
        <div className="absolute inset-0" style={{background:'radial-gradient(circle at 70% 50%,rgba(37,99,235,0.1),transparent 60%)'}}/>
        <div className="relative flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="w-12 h-12 rounded-xl bg-blue-600/20 flex items-center justify-center mb-4"><ClipboardList size={22} color="#2563EB"/></div>
            <h3 className="font-display text-xl font-700 text-white mb-2">Simulim i Provimit Teorik</h3>
            <p className="text-white/50 text-sm max-w-sm">10 pyetje të zgjedhura rastësisht. Timer 10 minuta. Minimumi 70% për kalim (7 nga 10 pyetje).</p>
            <div className="flex gap-6 mt-4">
              {[['10','Pyetje'],['10min','Kohëzgjatja'],['70%','Minimumi']].map(([v,l])=>(
                <div key={l} className="text-center"><div className="font-display text-xl font-700 text-blue-400">{v}</div><div className="text-xs text-white/30">{l}</div></div>
              ))}
            </div>
          </div>
          <button onClick={()=>setMode('quiz')} className="btn-primary text-base px-8 py-3 flex-shrink-0"><Play size={18}/>Fillo tani</button>
        </div>
      </div>
      <div className="card">
        <h3 className="font-display font-700 text-white mb-4">Historia e testeve</h3>
        <div className="flex flex-col gap-2">
          {history.map((h,i)=>(
            <div key={i} className="flex items-center gap-4 p-3 rounded-xl" style={{background:'rgba(255,255,255,0.02)',border:'1px solid rgba(255,255,255,0.04)'}}>
              <div className={clsx('w-10 h-10 rounded-xl flex items-center justify-center',h.passed?'bg-success/15':'bg-error/15')}>
                {h.passed?<Trophy size={18} color="#10B981"/>:<XCircle size={18} color="#EF4444"/>}
              </div>
              <div className="flex-1"><div className="text-sm font-semibold text-white">{h.date}</div><div className="text-xs text-white/40">{h.correct}/{h.total} të sakta</div></div>
              <div className={clsx('font-display text-xl font-700',h.passed?'text-success':'text-error')}>{h.score}%</div>
              <span className={clsx('badge',h.passed?'badge-success':'badge-error')}>{h.passed?'Kaloi':'Nuk kaloi'}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
