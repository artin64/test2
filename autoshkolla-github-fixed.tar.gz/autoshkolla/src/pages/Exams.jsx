import React, { useState } from 'react'
import { GraduationCap, Plus, CheckCircle, XCircle, Clock, X, Trash2, Edit2 } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import clsx from 'clsx'

const RS = { passed:{badge:'badge-success',label:'Kaloi',icon:CheckCircle}, failed:{badge:'badge-error',label:'Nuk kaloi',icon:XCircle}, scheduled:{badge:'badge-info',label:'Planifikuar',icon:Clock} }

function ExamModal({ onClose, onSave, students }) {
  const [f, setF] = useState({ student:'',type:'theory',date:'',examiner:'DPKSH',result:'scheduled',score:'' })
  const [errs, setErrs] = useState({})
  const h = (k,v) => { setF(p=>({...p,[k]:v})); setErrs(e=>({...e,[k]:''})) }
  const submit = () => {
    const e = {}
    if (!f.student) e.student = 'Zgjidh kandidatin'
    if (!f.date) e.date = 'Data është e detyrueshme'
    if (Object.keys(e).length) { setErrs(e); return }
    onSave(f); onClose()
  }
  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal p-6">
        <div className="flex items-center justify-between mb-5"><h2 className="font-display text-xl font-700 text-white">Cakto Provim</h2><button onClick={onClose} className="icon-btn"><X size={16}/></button></div>
        <div className="flex flex-col gap-3">
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Kandidati *</label>
            <select className={clsx('select',errs.student&&'border-error')} value={f.student} onChange={e=>h('student',e.target.value)}>
              <option value="">Zgjidh kandidatin...</option>
              {students.map(s=><option key={s.id}>{s.name}</option>)}
            </select>
            {errs.student&&<span className="text-xs text-error">{errs.student}</span>}
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[['type','Lloji','select',[['theory','Provim teorik'],['practical','Provim praktik']]],['date','Data *','date',null],['examiner','Ekzaminuesi','text',null],['result','Rezultati','select',[['scheduled','Planifikuar'],['passed','Kaloi'],['failed','Nuk kaloi']]]].map(([k,l,t,opts])=>(
              <div key={k} className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">{l}</label>
                {t==='select'?<select className="select" value={f[k]} onChange={e=>h(k,e.target.value)}>{opts.map(([v,lb])=><option key={v} value={v}>{lb}</option>)}</select>
                :<input type={t} className={clsx('input',errs[k]&&'border-error')} value={f[k]||''} onChange={e=>h(k,e.target.value)} placeholder={k==='examiner'?'DPKSH':''}/>}
                {errs[k]&&<span className="text-xs text-error">{errs[k]}</span>}
              </div>
            ))}
            {f.result==='passed'&&f.type==='theory'&&(
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Pikët (0-100)</label>
                <input type="number" className="input" value={f.score} onChange={e=>h('score',e.target.value)} placeholder="85" min={0} max={100}/>
              </div>
            )}
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-5"><button onClick={onClose} className="btn-secondary">Anulo</button><button onClick={submit} className="btn-primary"><GraduationCap size={15}/>Cakto provimin</button></div>
      </div>
    </div>
  )
}

export default function Exams() {
  const { store } = useApp(); const toast = useToast()
  const { exams, students, addExam, updateExam, deleteExam } = store
  const [filter, setFilter] = useState('all'); const [showModal, setShowModal] = useState(false)

  const save = f => { addExam(f); toast(`Provimi u caktua për ${f.student}`,'success') }
  const del = e => { if (!confirm('Fshi provimin?')) return; deleteExam(e.id); toast('Provimi u fshi','warning') }
  const toggleResult = e => {
    const next = e.result==='passed'?'failed':e.result==='failed'?'scheduled':'passed'
    updateExam(e.id,{result:next}); toast(`Rezultati u ndryshua: ${RS[next]?.label}`,'info')
  }

  const shown = filter==='all'?exams:exams.filter(e=>e.result===filter)
  const passed=exams.filter(e=>e.result==='passed').length, failed=exams.filter(e=>e.result==='failed').length
  const rate = passed+failed>0?Math.round(passed/(passed+failed)*100):0

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Provime</h1><p className="text-sm text-white/40 mt-0.5">Norma kalimi: {rate}%</p></div>
        <button onClick={()=>setShowModal(true)} className="btn-primary"><Plus size={15}/>Cakto provim</button>
      </div>
      <div className="stats-grid">
        {[['Total',exams.length,'#2563EB'],['Kaluan',passed,'#10B981'],['Nuk kaluan',failed,'#EF4444'],['Norma kalimi',`${rate}%`,'#06B6D4']].map(([l,v,c],i)=>(
          <div key={i} className="stat-card"><div className="font-display text-2xl font-700 text-white">{v}</div><div className="text-sm text-white/50">{l}</div></div>
        ))}
      </div>
      <div className="flex gap-2 flex-wrap">
        {[['all','Të gjitha'],['scheduled','Planifikuar'],['passed','Kaluan'],['failed','Nuk kaluan']].map(([v,l])=>(
          <button key={v} onClick={()=>setFilter(v)} className={clsx('px-4 py-2 rounded-xl text-sm font-semibold transition-all',filter===v?'bg-blue-600 text-white':'btn-secondary')}>{l}</button>
        ))}
      </div>
      <div className="grid-2">
        {shown.map(e=>{
          const rs=RS[e.result]||RS.scheduled; const RIcon=rs.icon
          return (
            <div key={e.id} className="card">
              <div className="flex items-start justify-between mb-4">
                <div><div className="font-semibold text-white">{e.student}</div><div className="text-xs text-white/40 mt-0.5">{e.date} · {e.type==='theory'?'Provim teorik':'Provim praktik'}</div></div>
                <button onClick={()=>toggleResult(e)} className={`badge ${rs.badge} cursor-pointer hover:opacity-80`}><RIcon size={11} className="mr-1"/>{rs.label}</button>
              </div>
              <div className="flex gap-2 mb-3">
                <div className="flex-1 p-2.5 rounded-xl text-center" style={{background:'rgba(255,255,255,0.03)'}}>
                  {e.score!=null&&e.score!==''?<div className={clsx('text-xl font-display font-700',+e.score>=70?'text-success':'text-error')}>{e.score}/100</div>:<div className="text-white/30 text-sm">—</div>}
                  <div className="text-xs text-white/30 mt-0.5">Pikët</div>
                </div>
                <div className="flex-1 p-2.5 rounded-xl text-center" style={{background:'rgba(255,255,255,0.03)'}}>
                  <div className="text-white font-semibold text-sm">{e.examiner||'—'}</div>
                  <div className="text-xs text-white/30">Ekzaminuesi</div>
                </div>
                <div className="flex-1 p-2.5 rounded-xl text-center" style={{background:'rgba(255,255,255,0.03)'}}>
                  <div className="text-white font-semibold">{e.attempts||0}</div>
                  <div className="text-xs text-white/30">Tentativa</div>
                </div>
              </div>
              <div className="flex gap-2">
                {e.result==='failed'&&<button onClick={()=>{setShowModal(true)}} className="btn-primary flex-1 text-xs py-2"><Plus size={13}/>Ricakto provim</button>}
                <button onClick={()=>del(e)} className="btn-danger text-xs py-2 px-3"><Trash2 size={13}/></button>
              </div>
            </div>
          )
        })}
        {shown.length===0&&<div className="col-span-2 card text-center py-12 text-white/30">Nuk ka provime</div>}
      </div>
      {showModal&&<ExamModal onClose={()=>setShowModal(false)} onSave={save} students={students}/>}
    </div>
  )
}
