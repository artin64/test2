import React, { useState } from 'react'
import { Bell, CheckCheck, Trash2, AlertTriangle, Info, CheckCircle, XCircle, Filter } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import clsx from 'clsx'

const TCFG = {
  warning:{icon:AlertTriangle,dot:'bg-warning',badge:'badge-warning',lbl:'Paralajmërim'},
  error:{icon:XCircle,dot:'bg-error',badge:'badge-error',lbl:'Gabim'},
  success:{icon:CheckCircle,dot:'bg-success',badge:'badge-success',lbl:'Sukses'},
  info:{icon:Info,dot:'bg-info',badge:'badge-info',lbl:'Informacion'},
}
const CATS = {all:'Të gjitha',system:'Sistem',schedule:'Orare',payment:'Pagesa',exam:'Provime',vehicle:'Vetura',student:'Kandidatë'}

export default function Notifications() {
  const { store } = useApp(); const toast = useToast()
  const { notifications, markRead, markAllRead, deleteNotification } = store
  const [cat, setCat] = useState('all')
  const [rf, setRf] = useState('all')

  const shown = notifications.filter(n => {
    const mc = cat==='all'||n.category===cat
    const mr = rf==='all'||(rf==='unread'&&!n.read)||(rf==='read'&&n.read)
    return mc&&mr
  })
  const unread = notifications.filter(n=>!n.read).length

  const doMarkAll = () => { markAllRead(); toast('Të gjitha njoftime u shënuan si të lexuara','success') }
  const doDel = id => { deleteNotification(id); toast('Njoftimi u fshi','warning') }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Njoftime</h1><p className="text-sm text-white/40 mt-0.5">{unread} të palexuara · {notifications.length} gjithsej</p></div>
        {unread>0&&<button onClick={doMarkAll} className="btn-secondary"><CheckCheck size={15}/>Shëno të gjitha si të lexuara</button>}
      </div>

      <div className="stats-grid">
        {[['Të palexuara',unread,'#EF4444'],['Sot',notifications.filter(n=>['2 orë','3 orë','Tani'].includes(n.time)).length,'#2563EB'],['Paralajmërime',notifications.filter(n=>n.type==='warning').length,'#F59E0B'],['Gjithsej',notifications.length,'#06B6D4']].map(([l,v,c],i)=>(
          <div key={i} className="stat-card"><div className="font-display text-2xl font-700 text-white">{v}</div><div className="text-sm text-white/50">{l}</div></div>
        ))}
      </div>

      <div className="card p-4 flex flex-wrap items-center gap-3">
        <Filter size={13} className="text-white/30"/>
        <div className="flex gap-1.5 flex-wrap">
          {Object.entries(CATS).map(([v,l])=>(
            <button key={v} onClick={()=>setCat(v)} className={clsx('px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border',cat===v?'bg-blue-600 text-white border-blue-600':'text-white/40 border-white/08 hover:border-white/20')}>{l}</button>
          ))}
        </div>
        <div className="ml-auto flex gap-1.5">
          {[['all','Të gjitha'],['unread','Të palexuara'],['read','Të lexuara']].map(([v,l])=>(
            <button key={v} onClick={()=>setRf(v)} className={clsx('px-3 py-1.5 rounded-lg text-xs font-semibold transition-all',rf===v?'bg-white/10 text-white':'text-white/30 hover:text-white/60')}>{l}</button>
          ))}
        </div>
      </div>

      <div className="flex flex-col gap-2">
        {shown.length===0&&<div className="card text-center py-12"><Bell size={28} className="mx-auto text-white/20 mb-3"/><div className="text-white/40">Nuk ka njoftime</div></div>}
        {shown.map(n=>{
          const cfg=TCFG[n.type]||TCFG.info; const NIcon=cfg.icon
          return (
            <div key={n.id} onClick={()=>markRead(n.id)} className={clsx('card cursor-pointer transition-all hover:border-white/10',!n.read&&'border-white/08')}>
              <div className="flex items-start gap-4">
                <div className={clsx('w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0',`bg-${n.type}/10`)} style={{background:`rgba(${n.type==='warning'?'245,158,11':n.type==='error'?'239,68,68':n.type==='success'?'16,185,129':'59,130,246'},0.12)`}}>
                  <NIcon size={16} className={n.type==='warning'?'text-warning':n.type==='error'?'text-error':n.type==='success'?'text-success':'text-info'}/>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className={clsx('font-semibold text-sm',n.read?'text-white/60':'text-white')}>{n.title}</div>
                      <div className="text-xs text-white/45 mt-1 leading-relaxed">{n.message}</div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className="text-xs text-white/20">{n.time} më parë</span>
                      {!n.read&&<div className="w-2 h-2 rounded-full bg-blue-500"/>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <span className={`badge ${cfg.badge} text-xs`}>{cfg.lbl}</span>
                    <span className="badge badge-default text-xs">{CATS[n.category]||n.category}</span>
                    <button onClick={e=>{e.stopPropagation();doDel(n.id)}} className="ml-auto text-white/20 hover:text-error transition-colors"><Trash2 size={13}/></button>
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      <div className="card">
        <h3 className="font-display font-700 text-white mb-4">Cilësimet e njoftimeve</h3>
        <div className="flex flex-col gap-2">
          {[['Email njoftime','Merr njoftime nëpërmjet email-it',true],['SMS njoftime','Njoftime direkte në telefon',true],['Kujtesa pagese','Automatikisht pas 7 ditësh borxhi',true],['Kujtesa provimi','24 orë para provimit',true],['Skadim dokumentesh','90 ditë para skadimit',true],['WhatsApp njoftime','Njoftime nëpërmjet WhatsApp',false]].map(([l,d,active],i)=>(
            <div key={i} className="flex items-center justify-between p-3 rounded-xl" style={{background:'rgba(255,255,255,0.02)'}}>
              <div><div className="text-sm font-medium text-white">{l}</div><div className="text-xs text-white/30 mt-0.5">{d}</div></div>
              <div className={clsx('w-10 h-5 rounded-full relative transition-all',active?'bg-blue-600':'bg-white/10')}>
                <div className={clsx('absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all',active?'right-0.5':'left-0.5')}/>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
