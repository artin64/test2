import React, { useState, useRef } from 'react'
import { FileText, Upload, Download, Eye, Trash2, Search, X, File, FileImage, FilePlus } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import clsx from 'clsx'

const CATS = ['Të gjitha','Kontratë','Letërnjoftim','Mjekësor','Certifikatë','Foto']
const TICON = { contract:FileText, id:FileImage, medical:FileText, certificate:FilePlus, photo:FileImage }
const TCOL = { contract:'#2563EB', id:'#10B981', medical:'#EF4444', certificate:'#F59E0B', photo:'#8B5CF6' }
const CATMAP = { contract:'Kontratë', id:'Letërnjoftim', medical:'Mjekësor', certificate:'Certifikatë', photo:'Foto' }

export default function Documents() {
  const { store } = useApp(); const toast = useToast()
  const { documents, addDocument, deleteDocument } = store
  const [search, setSearch] = useState(''); const [cat, setCat] = useState('Të gjitha'); const [drag, setDrag] = useState(false)
  const ref = useRef()

  const shown = documents.filter(d => {
    const ms = d.name.toLowerCase().includes(search.toLowerCase())||d.student.toLowerCase().includes(search.toLowerCase())
    return ms&&(cat==='Të gjitha'||d.category===cat)
  })

  const handleFiles = files => {
    if (!files?.length) return
    Array.from(files).forEach(f => {
      const isImg = f.type.includes('image')
      addDocument({ name:f.name, student:'Jo caktuar', type:isImg?'photo':'contract', size:`${(f.size/1024).toFixed(0)} KB`, category:isImg?'Foto':'Kontratë' })
    })
    toast(`${files.length} dokument(e) u ngarkuan me sukses`, 'success')
  }

  const del = d => { if(!confirm(`Fshi "${d.name}"?`)) return; deleteDocument(d.id); toast('Dokumenti u fshi','warning') }

  const download = d => {
    toast(`"${d.name}" — shkarkimi simulohet (kërkon backend real)`,'info')
  }

  const preview = d => {
    toast(`Preview i "${d.name}" — kërkon backend për file storage`,'info')
  }

  const totalKB = documents.reduce((a,d)=>{ const n=parseFloat(d.size); return a+(d.size.includes('MB')?n*1024:n) }, 0)

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Dokumentet</h1><p className="text-sm text-white/40 mt-0.5">{documents.length} dokumente · {(totalKB/1024).toFixed(1)} MB</p></div>
        <button onClick={()=>ref.current?.click()} className="btn-primary"><Upload size={15}/>Ngarko dokument</button>
        <input ref={ref} type="file" multiple className="hidden" onChange={e=>handleFiles(e.target.files)}/>
      </div>

      <div className="stats-grid">
        {[['Gjithsej',documents.length,'#2563EB'],['Kontrata',documents.filter(d=>d.type==='contract').length,'#10B981'],['Mjekësore',documents.filter(d=>d.type==='medical').length,'#EF4444'],['Certifikata',documents.filter(d=>d.type==='certificate').length,'#F59E0B']].map(([l,v,c],i)=>(
          <div key={i} className="stat-card"><div className="font-display text-2xl font-700 text-white">{v}</div><div className="text-sm text-white/50">{l}</div></div>
        ))}
      </div>

      {/* Drop zone */}
      <div onDragOver={e=>{e.preventDefault();setDrag(true)}} onDragLeave={()=>setDrag(false)}
        onDrop={e=>{e.preventDefault();setDrag(false);handleFiles(e.dataTransfer.files)}}
        onClick={()=>ref.current?.click()}
        className={clsx('border-2 border-dashed rounded-[20px] p-8 flex flex-col items-center gap-3 cursor-pointer transition-all',
          drag?'border-blue-500 bg-blue-600/05':'border-white/10 hover:border-white/20 hover:bg-white/02'
        )}>
        <div className="w-12 h-12 rounded-xl bg-white/05 flex items-center justify-center"><Upload size={22} className="text-white/40"/></div>
        <div className="text-center"><div className="text-white/60 font-medium">Tërhiqni dokumentet këtu ose klikoni për të ngarkuar</div><div className="text-xs text-white/25 mt-1">PDF, JPG, PNG — maksimum 10MB</div></div>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-wrap items-center gap-3">
        <div className="search-input flex-1 min-w-48"><Search size={13}/><input placeholder="Kërko dokument ose kandidat..." value={search} onChange={e=>setSearch(e.target.value)}/>{search&&<button onClick={()=>setSearch('')} className="text-white/30"><X size={11}/></button>}</div>
        <div className="flex gap-1.5 flex-wrap">{CATS.map(c=><button key={c} onClick={()=>setCat(c)} className={clsx('px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border',cat===c?'bg-blue-600 text-white border-blue-600':'text-white/40 border-white/08 hover:border-white/20')}>{c}</button>)}</div>
      </div>

      {/* Grid */}
      <div className="grid-3">
        {shown.map(d=>{
          const DIcon=TICON[d.type]||File; const col=TCOL[d.type]||'#2563EB'
          return (
            <div key={d.id} className="card hover:border-white/10 transition-all">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{background:`${col}18`,color:col}}><DIcon size={18}/></div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-white truncate" title={d.name}>{d.name}</div>
                  <div className="text-xs text-white/35 mt-0.5">{d.size} · {d.date}</div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div><div className="text-xs text-white/40">{d.student}</div><span className="badge badge-default text-xs mt-1">{d.category}</span></div>
                <div className="flex gap-1">
                  <button onClick={()=>preview(d)} className="icon-btn w-7 h-7" title="Shiko"><Eye size={13}/></button>
                  <button onClick={()=>download(d)} className="icon-btn w-7 h-7" title="Shkarko"><Download size={13}/></button>
                  <button onClick={()=>del(d)} className="icon-btn w-7 h-7 hover:text-error" title="Fshi"><Trash2 size={13}/></button>
                </div>
              </div>
            </div>
          )
        })}
        {shown.length===0&&<div className="col-span-3 card text-center py-12"><FileText size={28} className="mx-auto text-white/20 mb-3"/><div className="text-white/40">Nuk u gjet asnjë dokument</div></div>}
      </div>
    </div>
  )
}
