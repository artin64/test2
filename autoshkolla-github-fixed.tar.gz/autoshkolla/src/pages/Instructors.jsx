import React, { useState } from 'react'
import { Plus, Star, Users, Clock, Edit2, Trash2, X, AlertTriangle, Download, Phone, Mail } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import { exportInstructorsExcel } from '../utils/exportUtils'
import clsx from 'clsx'

const CATS = ['A','A1','B','BE','C','CE','D']
function validate(f) {
  const e = {}
  if (!f.name?.trim()) e.name = 'Emri është i detyrueshëm'
  if (!f.phone?.trim()) e.phone = 'Telefoni është i detyrueshëm'
  if (!f.license?.trim()) e.license = 'Licensa është e detyrueshme'
  return e
}

function Modal({ ins, onClose, onSave }) {
  const [f, setF] = useState(ins || { name:'',phone:'',email:'',license:'',licenseExpiry:'',experience:1,status:'active',salary:'',categories:['B'] })
  const [errs, setErrs] = useState({})
  const h = (k,v) => { setF(p=>({...p,[k]:v})); setErrs(e=>({...e,[k]:''})) }
  const toggleCat = c => setF(p => ({ ...p, categories: p.categories?.includes(c) ? p.categories.filter(x=>x!==c) : [...(p.categories||[]),c] }))
  const submit = () => { const e=validate(f); if(Object.keys(e).length){setErrs(e);return}; onSave(f); onClose() }

  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal p-6" style={{maxHeight:'90vh',overflowY:'auto'}}>
        <div className="flex items-center justify-between mb-5"><h2 className="font-display text-xl font-700 text-white">{ins?'Edito Instruktorin':'Shto Instruktor'}</h2><button onClick={onClose} className="icon-btn"><X size={16}/></button></div>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2 flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Emri i plotë *</label>
            <input className={clsx('input',errs.name&&'border-error')} value={f.name} onChange={e=>h('name',e.target.value)} placeholder="Emri Mbiemri"/>
            {errs.name&&<span className="text-xs text-error">{errs.name}</span>}
          </div>
          {[['phone','Telefoni *','text','+383 44 000 000'],['email','Email','email','ins@email.com'],['license','Numri licencës *','text','INS-2024-001'],['licenseExpiry','Skadon licensa','date',''],['experience','Vite eksperience','number','5'],['salary','Paga mujore (€)','number','600']].map(([k,l,t,ph])=>(
            <div key={k} className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">{l}</label>
              <input type={t} className={clsx('input',errs[k]&&'border-error')} value={f[k]||''} onChange={e=>h(k,e.target.value)} placeholder={ph}/>
              {errs[k]&&<span className="text-xs text-error">{errs[k]}</span>}
            </div>
          ))}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Statusi</label>
            <select className="select" value={f.status} onChange={e=>h('status',e.target.value)}><option value="active">Aktiv</option><option value="leave">Pushim</option><option value="inactive">Joaktiv</option></select>
          </div>
          <div className="col-span-2 flex flex-col gap-2">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Kategorite e lejuara</label>
            <div className="flex gap-2 flex-wrap">{CATS.map(c=><button key={c} type="button" onClick={()=>toggleCat(c)} className={clsx('px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border',f.categories?.includes(c)?'bg-blue-600 text-white border-blue-600':'text-white/40 border-white/10 hover:border-white/20')}>Kat. {c}</button>)}</div>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-5"><button onClick={onClose} className="btn-secondary">Anulo</button><button onClick={submit} className="btn-primary">{ins?'Ruaj ndryshimet':'Shto instruktorin'}</button></div>
      </div>
    </div>
  )
}

export default function Instructors() {
  const { store } = useApp(); const toast = useToast()
  const { instructors, addInstructor, updateInstructor, deleteInstructor } = store
  const [modal, setModal] = useState(null); const [sel, setSel] = useState(null)

  const isExpiring = d => d && (new Date(d) - new Date()) / 86400000 < 90

  const save = f => {
    if (sel) { updateInstructor(sel.id, f); toast(`${f.name} u përditësua`, 'success') }
    else { addInstructor(f); toast(`${f.name} u shtua me sukses`, 'success') }
    setModal(null); setSel(null)
  }
  const del = ins => {
    if (!confirm(`Fshi ${ins.name}?`)) return
    deleteInstructor(ins.id); toast(`${ins.name} u fshi`, 'warning')
  }

  const statusMap = { active: ['Aktiv','success'], leave: ['Pushim','warning'], inactive: ['Joaktiv','error'] }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Instruktorët</h1><p className="text-sm text-white/40 mt-0.5">{instructors.filter(i=>i.status==='active').length} aktiv · {instructors.length} gjithsej</p></div>
        <div className="flex gap-2">
          <button onClick={()=>{exportInstructorsExcel(instructors);toast('Lista u eksportua','success')}} className="btn-secondary"><Download size={15}/>Excel</button>
          <button onClick={()=>{setSel(null);setModal('form')}} className="btn-primary"><Plus size={15}/>Shto instruktor</button>
        </div>
      </div>

      <div className="stats-grid">
        {[['Total',instructors.length,'#2563EB'],['Aktiv',instructors.filter(i=>i.status==='active').length,'#10B981'],['Orë ky muaj',instructors.reduce((a,i)=>a+i.hoursThisMonth,0),'#06B6D4'],['Vlerësim mesatar',(instructors.reduce((a,i)=>a+i.rating,0)/Math.max(1,instructors.length)).toFixed(1),'#F59E0B']].map(([l,v,c],i)=>(
          <div key={i} className="stat-card"><div className="font-display text-2xl font-700 text-white">{v}</div><div className="text-sm text-white/50">{l}</div></div>
        ))}
      </div>

      <div className="grid-2">
        {instructors.map(ins => {
          const [slbl, stype] = statusMap[ins.status] || ['—','default']
          return (
            <div key={ins.id} className="card">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="avatar w-11 h-11 text-sm">{ins.avatar}</div>
                  <div>
                    <div className="font-semibold text-white">{ins.name}</div>
                    <div className="text-xs text-white/40 mt-0.5">{ins.experience} vite eksperience</div>
                    <div className="flex items-center gap-1 mt-1">
                      <Star size={11} fill="#F59E0B" color="#F59E0B" />
                      <span className="text-xs text-white/60">{ins.rating}</span>
                    </div>
                  </div>
                </div>
                <span className={`badge badge-${stype}`}>{slbl}</span>
              </div>

              <div className="grid grid-cols-3 gap-2 mb-3">
                {[['Kandidatë',ins.students,'#2563EB'],['Orë/muaj',`${ins.hoursThisMonth}h`,'#06B6D4'],['Paga',`€${ins.salary}`,'#10B981']].map(([l,v,c])=>(
                  <div key={l} className="p-2 rounded-lg text-center" style={{background:'rgba(255,255,255,0.03)'}}>
                    <div className="font-semibold text-white text-sm">{v}</div>
                    <div className="text-xs text-white/30">{l}</div>
                  </div>
                ))}
              </div>

              <div className="flex flex-col gap-1.5 mb-3">
                <div className="text-xs text-white/40 flex items-center gap-1.5"><Phone size={11}/>{ins.phone}</div>
                {ins.email&&<div className="text-xs text-white/40 flex items-center gap-1.5"><Mail size={11}/>{ins.email}</div>}
                <div className="flex gap-1 flex-wrap mt-1">{ins.categories?.map(c=><span key={c} className="badge badge-info text-xs">Kat. {c}</span>)}</div>
              </div>

              {isExpiring(ins.licenseExpiry) && (
                <div className="mb-3 p-2.5 rounded-lg flex items-center gap-2 text-xs text-warning" style={{background:'rgba(245,158,11,0.08)'}}>
                  <AlertTriangle size={13}/> Licensa skadon: {ins.licenseExpiry}
                </div>
              )}

              <div className="flex gap-2">
                <button onClick={()=>{setSel(ins);setModal('form')}} className="btn-secondary flex-1 text-xs py-2"><Edit2 size={13}/>Edito</button>
                <button onClick={()=>del(ins)} className="btn-danger text-xs py-2 px-3"><Trash2 size={13}/></button>
              </div>
            </div>
          )
        })}
        {instructors.length===0&&<div className="col-span-2 card text-center py-12 text-white/30">Nuk ka instruktorë. Shto instruktorin e parë.</div>}
      </div>

      {modal==='form'&&<Modal ins={sel} onClose={()=>{setModal(null);setSel(null)}} onSave={save}/>}
    </div>
  )
}
