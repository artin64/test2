import React, { useState } from 'react'
import { Car, Plus, AlertTriangle, Edit2, Trash2, X, Download, Gauge } from 'lucide-react'
import { useApp } from '../context/AppContext'
import { useToast } from '../components/ui/Toast'
import { exportVehiclesExcel } from '../utils/exportUtils'
import clsx from 'clsx'

function Modal({ v, ins, onClose, onSave }) {
  const [f, setF] = useState(v || { brand:'',model:'',year:new Date().getFullYear(),plate:'',vin:'',category:'B',transmission:'Manual',status:'active',instructor:'',insurance:'',registration:'',lastService:'',km:0 })
  const [errs, setErrs] = useState({})
  const h = (k,val) => { setF(p=>({...p,[k]:val})); setErrs(e=>({...e,[k]:''})) }
  const submit = () => {
    const e = {}
    if (!f.brand?.trim()) e.brand = 'Marka është e detyrueshme'
    if (!f.plate?.trim()) e.plate = 'Targa është e detyrueshme'
    if (Object.keys(e).length) { setErrs(e); return }
    onSave(f); onClose()
  }
  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal p-6" style={{maxHeight:'90vh',overflowY:'auto'}}>
        <div className="flex items-center justify-between mb-5"><h2 className="font-display text-xl font-700 text-white">{v?'Edito Veturën':'Shto Veturë të Re'}</h2><button onClick={onClose} className="icon-btn"><X size={16}/></button></div>
        <div className="grid grid-cols-2 gap-3">
          {[['brand','Marka *','text','p.sh. Volkswagen'],['model','Modeli','text','p.sh. Golf 8'],['year','Viti','number',new Date().getFullYear()],['plate','Targa *','text','PRI-000-AA'],['vin','VIN','text','VIN kodi'],['km','Kilometrazha','number','0'],['insurance','Skadon sigurimi','date',''],['registration','Skadon regjistrimi','date',''],['lastService','Servisi i fundit','date','']].map(([k,l,t,ph])=>(
            <div key={k} className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">{l}</label>
              <input type={t} className={clsx('input',errs[k]&&'border-error')} value={f[k]||''} onChange={e=>h(k,e.target.value)} placeholder={String(ph)}/>
              {errs[k]&&<span className="text-xs text-error">{errs[k]}</span>}
            </div>
          ))}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Kategoria</label>
            <select className="select" value={f.category} onChange={e=>h('category',e.target.value)}>{['A','A1','B','BE','C','CE','D'].map(c=><option key={c}>{c}</option>)}</select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Transmisioni</label>
            <select className="select" value={f.transmission} onChange={e=>h('transmission',e.target.value)}><option>Manual</option><option>Automatic</option></select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Statusi</label>
            <select className="select" value={f.status} onChange={e=>h('status',e.target.value)}><option value="active">Aktiv</option><option value="maintenance">Mirëmbajtje</option><option value="inactive">Joaktiv</option></select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold text-white/40 uppercase tracking-wider">Instruktori</label>
            <select className="select" value={f.instructor||''} onChange={e=>h('instructor',e.target.value)}>
              <option value="">Pa instruktor</option>
              {ins.map(i=><option key={i.id}>{i.name}</option>)}
            </select>
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-5"><button onClick={onClose} className="btn-secondary">Anulo</button><button onClick={submit} className="btn-primary">{v?'Ruaj ndryshimet':'Shto veturën'}</button></div>
      </div>
    </div>
  )
}

export default function Vehicles() {
  const { store } = useApp(); const toast = useToast()
  const { vehicles, instructors, addVehicle, updateVehicle, deleteVehicle } = store
  const [modal, setModal] = useState(null); const [sel, setSel] = useState(null)
  const isExp = d => d && (new Date(d)-new Date())/86400000 < 90
  const statusMap = { active:['Aktiv','success'], maintenance:['Mirëmbajtje','warning'], inactive:['Joaktiv','error'] }

  const save = f => {
    if (sel) { updateVehicle(sel.id,f); toast(`${f.brand} ${f.model} u përditësua`,'success') }
    else { addVehicle(f); toast(`${f.brand} ${f.model} u shtua`,'success') }
    setModal(null); setSel(null)
  }
  const del = v => {
    if (!confirm(`Fshi ${v.brand} ${v.model}?`)) return
    deleteVehicle(v.id); toast('Vetura u fshi','warning')
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div><h1 className="font-display text-2xl font-700 text-white">Fleet — Veturat</h1><p className="text-sm text-white/40 mt-0.5">{vehicles.filter(v=>v.status==='active').length} aktive · {vehicles.length} gjithsej</p></div>
        <div className="flex gap-2">
          <button onClick={()=>{exportVehiclesExcel(vehicles);toast('Lista u eksportua','success')}} className="btn-secondary"><Download size={15}/>Excel</button>
          <button onClick={()=>{setSel(null);setModal('form')}} className="btn-primary"><Plus size={15}/>Shto veturë</button>
        </div>
      </div>

      <div className="stats-grid">
        {[['Aktive',vehicles.filter(v=>v.status==='active').length,'#10B981'],['Mirëmbajtje',vehicles.filter(v=>v.status==='maintenance').length,'#F59E0B'],['Dokumente skadues',vehicles.filter(v=>isExp(v.insurance)||isExp(v.registration)).length,'#EF4444'],['KM total',vehicles.reduce((a,v)=>a+(+v.km||0),0).toLocaleString(),'#2563EB']].map(([l,v,c],i)=>(
          <div key={i} className="stat-card"><div className="font-display text-2xl font-700 text-white">{v}</div><div className="text-sm text-white/50">{l}</div></div>
        ))}
      </div>

      <div className="grid-2">
        {vehicles.map(v => {
          const [slbl,stype]=statusMap[v.status]||['—','default']
          const colors = { B:'#2563EB', A:'#EF4444', C:'#F59E0B', CE:'#8B5CF6' }
          const col = colors[v.category] || '#06B6D4'
          return (
            <div key={v.id} className="card">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{background:`${col}18`,color:col}}><Car size={20}/></div>
                  <div>
                    <div className="font-semibold text-white">{v.brand} {v.model}</div>
                    <div className="text-xs text-white/40">{v.year} · {v.plate}</div>
                  </div>
                </div>
                <span className={`badge badge-${stype}`}>{slbl}</span>
              </div>
              <div className="grid grid-cols-3 gap-2 mb-3">
                {[['Kat.',`Kat. ${v.category}`],['Trans.',v.transmission==='Manual'?'Man.':'Auto'],['KM',`${Math.round((+v.km||0)/1000)}k`]].map(([l,val])=>(
                  <div key={l} className="p-2 rounded-lg text-center" style={{background:'rgba(255,255,255,0.03)'}}>
                    <div className="text-white text-sm font-semibold">{val}</div>
                    <div className="text-xs text-white/30">{l}</div>
                  </div>
                ))}
              </div>
              {v.instructor&&<div className="text-xs text-white/40 mb-2">Instruktori: <span className="text-white/60">{v.instructor}</span></div>}
              {(isExp(v.insurance)||isExp(v.registration))&&(
                <div className="mb-3 p-2.5 rounded-lg" style={{background:'rgba(245,158,11,0.08)'}}>
                  {isExp(v.insurance)&&<div className="text-xs text-warning flex items-center gap-1.5"><AlertTriangle size={11}/>Sigurimi skadon: {v.insurance}</div>}
                  {isExp(v.registration)&&<div className="text-xs text-warning flex items-center gap-1.5 mt-1"><AlertTriangle size={11}/>Regjistrimi skadon: {v.registration}</div>}
                </div>
              )}
              {v.lastService&&<div className="text-xs text-white/25 mb-3">Servisi i fundit: {v.lastService}</div>}
              <div className="flex gap-2">
                <button onClick={()=>{setSel(v);setModal('form')}} className="btn-secondary flex-1 text-xs py-2"><Edit2 size={13}/>Edito</button>
                <button onClick={()=>del(v)} className="btn-danger text-xs py-2 px-3"><Trash2 size={13}/></button>
              </div>
            </div>
          )
        })}
        {vehicles.length===0&&<div className="col-span-2 card text-center py-12 text-white/30">Nuk ka vetura. Shto veturën e parë.</div>}
      </div>
      {modal==='form'&&<Modal v={sel} ins={instructors} onClose={()=>{setModal(null);setSel(null)}} onSave={save}/>}
    </div>
  )
}
