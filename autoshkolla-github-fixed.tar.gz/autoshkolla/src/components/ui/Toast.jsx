import React, { createContext, useContext, useState, useCallback } from 'react'
import { CheckCircle, XCircle, AlertTriangle, Info, X } from 'lucide-react'
import clsx from 'clsx'

const ToastContext = createContext(null)

const ICONS = { success: CheckCircle, error: XCircle, warning: AlertTriangle, info: Info }
const STYLES = {
  success: { border: 'border-success/30', icon: 'text-success', bg: 'bg-success/10' },
  error: { border: 'border-error/30', icon: 'text-error', bg: 'bg-error/10' },
  warning: { border: 'border-warning/30', icon: 'text-warning', bg: 'bg-warning/10' },
  info: { border: 'border-info/30', icon: 'text-info', bg: 'bg-info/10' },
}

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([])

  const toast = useCallback((message, type = 'info', duration = 3500) => {
    const id = Date.now() + Math.random()
    setToasts(prev => [...prev, { id, message, type }])
    setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), duration)
  }, [])

  const remove = (id) => setToasts(prev => prev.filter(t => t.id !== id))

  return (
    <ToastContext.Provider value={toast}>
      {children}
      {/* Toast container */}
      <div className="fixed bottom-6 right-6 z-[9999] flex flex-col gap-2 pointer-events-none" style={{ maxWidth: 380 }}>
        {toasts.map(t => {
          const Icon = ICONS[t.type] || Info
          const style = STYLES[t.type] || STYLES.info
          return (
            <div key={t.id}
              className={clsx(
                'flex items-start gap-3 p-4 rounded-xl border pointer-events-auto',
                'shadow-2xl backdrop-blur-sm',
                style.border
              )}
              style={{ background: '#0F172A', animation: 'slideUp 0.2s ease' }}
            >
              <div className={clsx('w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0', style.bg)}>
                <Icon size={16} className={style.icon} />
              </div>
              <div className="flex-1 min-w-0 pt-0.5">
                <p className="text-sm font-medium text-white leading-snug">{t.message}</p>
              </div>
              <button onClick={() => remove(t.id)} className="text-white/30 hover:text-white/60 transition-colors flex-shrink-0">
                <X size={14} />
              </button>
            </div>
          )
        })}
      </div>
    </ToastContext.Provider>
  )
}

export const useToast = () => useContext(ToastContext)
