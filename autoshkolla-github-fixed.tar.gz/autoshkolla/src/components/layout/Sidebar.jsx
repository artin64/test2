import React, { useState } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { LayoutDashboard, Users, UserCheck, Car, Calendar, GraduationCap, CreditCard, Bell, FileText, BarChart3, Settings, Building2, ChevronDown, ChevronRight, LogOut, ClipboardList, Globe, Search, X } from 'lucide-react'
import { useApp } from '../../context/AppContext'
import clsx from 'clsx'

const NAV = [
  { label: 'Dashboard', path: '/', icon: LayoutDashboard },
  { label: 'Kandidatët', icon: Users, children: [
    { label: 'Të gjithë kandidatët', path: '/students' },
    { label: 'Regjistro të ri', path: '/students/new' },
  ]},
  { label: 'Instruktorët', icon: UserCheck, children: [
    { label: 'Të gjithë instruktorët', path: '/instructors' },
    { label: 'Shto instruktor', path: '/instructors/new' },
  ]},
  { label: 'Veturat', icon: Car, children: [
    { label: 'Fleet i veturave', path: '/vehicles' },
    { label: 'Shto veturë', path: '/vehicles/new' },
  ]},
  { label: 'Oraret', path: '/schedule', icon: Calendar },
  { label: 'Provime', icon: GraduationCap, children: [
    { label: 'Të gjitha provimet', path: '/exams' },
    { label: 'Cakto provim', path: '/exams/new' },
  ]},
  { label: 'Testet Online', path: '/tests', icon: ClipboardList },
  { label: 'Pagesat', icon: CreditCard, children: [
    { label: 'Transaksionet', path: '/payments' },
    { label: 'Borxhet', path: '/payments/debts' },
  ]},
  { label: 'Njoftime', path: '/notifications', icon: Bell },
  { label: 'Dokumentet', path: '/documents', icon: FileText },
  { label: 'Raporte', path: '/reports', icon: BarChart3 },
  { label: 'Degët', path: '/branches', icon: Building2 },
  { label: 'Webfaqja', path: '/cms', icon: Globe },
]

function NavGroup({ item }) {
  const location = useLocation()
  const isAct = item.children?.some(c => location.pathname.startsWith(c.path))
  const [open, setOpen] = useState(isAct)
  const Icon = item.icon
  return (
    <div>
      <button onClick={() => setOpen(!open)} className={clsx('nav-item w-full', isAct && 'text-white/90')}>
        <Icon size={18} />
        <span className="flex-1 text-left text-sm">{item.label}</span>
        {open ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
      </button>
      {open && (
        <div className="ml-7 mt-0.5 flex flex-col gap-0.5 mb-1">
          {item.children.map(c => (
            <NavLink key={c.path} to={c.path}
              className={({ isActive }) => clsx('text-sm py-1.5 px-3 rounded-lg transition-all cursor-pointer block',
                isActive ? 'text-white bg-white/08' : 'text-white/40 hover:text-white/70 hover:bg-white/04'
              )}>
              {c.label}
            </NavLink>
          ))}
        </div>
      )}
    </div>
  )
}

export default function Sidebar() {
  const { user, sidebarOpen, setSidebarOpen } = useApp()
  const [search, setSearch] = useState('')

  const allPaths = NAV.flatMap(n => n.children ? n.children : [n]).filter(n => n.path)
  const results = search.trim() ? allPaths.filter(n => n.label.toLowerCase().includes(search.toLowerCase())) : []

  return (
    <aside className={clsx('sidebar transition-transform duration-300 z-40', !sidebarOpen && '-translate-x-full lg:translate-x-0')}>
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-4 border-b border-white/05">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: 'linear-gradient(135deg,#2563EB,#06B6D4)' }}>
          <Car size={18} color="white" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-display font-700 text-white text-sm leading-none">AutoShkolla Pro</div>
          <div className="text-[10px] text-white/25 mt-0.5 uppercase tracking-widest">Sistem Profesional</div>
        </div>
        <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-white/30 hover:text-white/60"><X size={16} /></button>
      </div>

      {/* Search */}
      <div className="px-3 pt-3 pb-1 relative">
        <div className="search-input">
          <Search size={13} />
          <input placeholder="Kërko meny..." value={search} onChange={e => setSearch(e.target.value)} className="flex-1 text-sm" />
          {search && <button onClick={() => setSearch('')} className="text-white/30"><X size={12} /></button>}
        </div>
        {results.length > 0 && (
          <div className="absolute left-3 right-3 top-14 card p-1 z-50 shadow-2xl">
            {results.map(r => (
              <NavLink key={r.path} to={r.path} onClick={() => setSearch('')}
                className="block px-3 py-2 rounded-lg text-sm text-white/70 hover:bg-white/06 hover:text-white transition-colors">
                {r.label}
              </NavLink>
            ))}
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2 py-2 flex flex-col gap-0.5">
        {NAV.map((item, i) =>
          item.children
            ? <NavGroup key={i} item={item} />
            : <NavLink key={item.path} to={item.path} end={item.path === '/'}
                className={({ isActive }) => clsx('nav-item', isActive && 'active')}>
                <item.icon size={18} /><span className="text-sm">{item.label}</span>
              </NavLink>
        )}
      </nav>

      <div className="divider mx-3" />

      {/* Bottom */}
      <div className="px-2 pb-3 flex flex-col gap-0.5">
        <NavLink to="/settings" className={({ isActive }) => clsx('nav-item', isActive && 'active')}>
          <Settings size={18} /><span className="text-sm">Cilësimet</span>
        </NavLink>
        <div className="flex items-center gap-3 px-3 py-2.5 mt-1 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
          <div className="avatar w-8 h-8 text-xs flex-shrink-0">{user.avatar}</div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-semibold text-white truncate">{user.name}</div>
            <div className="text-xs text-white/30 truncate">{user.role}</div>
          </div>
          <button className="text-white/25 hover:text-white/60 transition-colors" title="Dil"><LogOut size={14} /></button>
        </div>
      </div>
    </aside>
  )
}
