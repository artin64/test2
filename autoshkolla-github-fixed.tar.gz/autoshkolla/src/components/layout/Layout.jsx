import React from 'react'
import Sidebar from './Sidebar'
import Topbar from './Topbar'
import { useApp } from '../../context/AppContext'

export default function Layout({ children, title, subtitle }) {
  const { sidebarOpen, setSidebarOpen } = useApp()
  return (
    <div className="flex min-h-screen" style={{ background: '#020617' }}>
      {sidebarOpen && <div className="fixed inset-0 bg-black/60 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />}
      <Sidebar />
      <div className="main-content flex-1 min-w-0">
        <Topbar title={title} subtitle={subtitle} />
        <main className="p-4 md:p-6 flex-1">{children}</main>
      </div>
    </div>
  )
}
