import React, { useState } from 'react'
import { Bell, Menu, ChevronDown, CheckCheck, X } from 'lucide-react'
import { useApp } from '../../context/AppContext'
import clsx from 'clsx'

const TYPE_DOT = { warning: 'bg-warning', error: 'bg-error', success: 'bg-success', info: 'bg-info' }
const TYPE_LABEL = { warning: 'Paralajmërim', error: 'Gabim', success: 'Sukses', info: 'Info' }
const TYPE_BADGE = { warning: 'badge-warning', error: 'badge-error', success: 'badge-success', info: 'badge-info' }

export default function Topbar({ title, subtitle }) {
  const { user, setSidebarOpen, store } = useApp()
  const { notifications, markRead, markAllRead } = store
  const [notifOpen, setNotifOpen] = useState(false)
  const [userOpen, setUserOpen] = useState(false)
  const unread = notifications.filter(n => !n.read).length

  const close = () => { setNotifOpen(false); setUserOpen(false) }

  return (
    <header className="topbar">
      {/* Left */}
      <div className="flex items-center gap-3">
        <button onClick={() => setSidebarOpen(o => !o)} className="icon-btn lg:hidden"><Menu size={18} /></button>
        <div>
          {title && <h1 className="font-display font-700 text-white text-lg leading-tight">{title}</h1>}
          {subtitle && <p className="text-xs text-white/35 mt-0.5">{subtitle}</p>}
        </div>
      </div>

      {/* Right */}
      <div className="flex items-center gap-2">
        {/* Notifications */}
        <div className="relative">
          <button className="icon-btn relative" onClick={() => { setNotifOpen(o => !o); setUserOpen(false) }}>
            <Bell size={18} />
            {unread > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-error text-white text-[9px] font-700 flex items-center justify-center">{unread}</span>
            )}
          </button>
          {notifOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={close} />
              <div className="absolute right-0 top-11 w-80 card p-0 overflow-hidden z-50" style={{ boxShadow: '0 24px 80px rgba(0,0,0,0.6)' }}>
                <div className="flex items-center justify-between px-4 py-3 border-b border-white/06">
                  <span className="text-sm font-semibold text-white">Njoftime</span>
                  <button onClick={() => { markAllRead(); close() }} className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1">
                    <CheckCheck size={12} />Lexo të gjitha
                  </button>
                </div>
                <div className="max-h-72 overflow-y-auto">
                  {notifications.slice(0, 8).map(n => (
                    <div key={n.id} onClick={() => markRead(n.id)}
                      className={clsx('px-4 py-3 border-b border-white/04 cursor-pointer transition-colors hover:bg-white/02', !n.read && 'bg-white/02')}>
                      <div className="flex items-start gap-2.5">
                        <div className={clsx('w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0', TYPE_DOT[n.type])} />
                        <div className="flex-1 min-w-0">
                          <div className={clsx('text-sm font-medium', n.read ? 'text-white/60' : 'text-white')}>{n.title}</div>
                          <div className="text-xs text-white/35 mt-0.5 line-clamp-2">{n.message}</div>
                          <div className="text-xs text-white/20 mt-1">{n.time} më parë</div>
                        </div>
                      </div>
                    </div>
                  ))}
                  {notifications.length === 0 && (
                    <div className="text-center py-8 text-white/30 text-sm">Nuk ka njoftime</div>
                  )}
                </div>
                <div className="px-4 py-2.5 border-t border-white/05 text-center">
                  <a href="/notifications" className="text-xs text-blue-400 hover:text-blue-300" onClick={close}>Shiko të gjitha njoftime →</a>
                </div>
              </div>
            </>
          )}
        </div>

        {/* User menu */}
        <div className="relative">
          <button onClick={() => { setUserOpen(o => !o); setNotifOpen(false) }}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl hover:bg-white/05 transition-all">
            <div className="avatar w-8 h-8 text-xs">{user.avatar}</div>
            <div className="hidden sm:block text-left">
              <div className="text-sm font-semibold text-white leading-none">{user.name}</div>
              <div className="text-xs text-white/30 mt-0.5">{user.role}</div>
            </div>
            <ChevronDown size={13} className="text-white/30" />
          </button>
          {userOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={close} />
              <div className="absolute right-0 top-11 w-44 card p-1.5 z-50" style={{ boxShadow: '0 24px 80px rgba(0,0,0,0.6)' }}>
                <a href="/settings" className="nav-item text-sm w-full" onClick={close}>Cilësimet</a>
                <div className="divider my-1" />
                <button className="nav-item text-sm w-full text-error/70 hover:text-error" onClick={close}>Dil</button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  )
}
