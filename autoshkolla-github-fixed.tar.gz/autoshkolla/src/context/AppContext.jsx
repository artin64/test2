import React, { createContext, useContext, useState } from 'react'
import { useStore } from '../store/dataStore'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [user] = useState({ name: 'Admin Krasniqi', role: 'Admin kryesor', avatar: 'AK', email: 'admin@autoshkolla.com' })
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const store = useStore()

  return (
    <AppContext.Provider value={{ user, sidebarOpen, setSidebarOpen, store }}>
      {children}
    </AppContext.Provider>
  )
}

export const useApp = () => useContext(AppContext)
